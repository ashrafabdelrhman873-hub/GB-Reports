#!/usr/bin/env python3
"""Render a newly generated RTF with LibreOffice and report independent checks.
This tests RTF readability/rendering, not equivalence to an Oracle render.
"""
import argparse
import json
from pathlib import Path
import re
import subprocess
import tempfile
import time
import fitz


def structure_errors(data):
    if not data.startswith(b'{\\rtf1'):
        return ['Missing RTF 1 header']
    depth = 0
    pos = 0
    while pos < len(data):
        ch = data[pos]
        if ch == 92:
            if pos + 1 >= len(data):
                return ['Trailing RTF escape']
            nxt = data[pos + 1]
            if nxt in b'{}\\':
                pos += 2
                continue
            m = re.match(rb'\\bin([0-9]+) ?', data[pos:])
            if m:
                pos += m.end() + int(m.group(1))
                continue
            pos += 1
        elif ch == 123:
            depth += 1
        elif ch == 125:
            depth -= 1
            if depth < 0:
                return ['RTF group closed before opening']
        pos += 1
    return [] if depth == 0 else [f'Unbalanced RTF groups: depth={depth}']


def render(source, dest, expected_texts=()):
    source = source.resolve()
    dest.mkdir(parents=True, exist_ok=True)
    errors = structure_errors(source.read_bytes())
    if errors:
        raise ValueError('; '.join(errors))
    with tempfile.TemporaryDirectory(prefix='rtf-validation-',dir='/tmp') as tmp:
        out = Path(tmp)/'output';out.mkdir()
        profile = Path(tmp)/'profile'
        started = time.time()
        cmd = ['soffice',f'-env:UserInstallation={profile.as_uri()}', '--headless', '--convert-to','pdf','--outdir',str(out),str(source)]
        cp = subprocess.run(cmd,capture_output=True,text=True,timeout=90)
        if cp.returncode:
            raise RuntimeError(f'LibreOffice failed: {cp.returncode}\n{cp.stdout}\n{cp.stderr}')
        pdf_path = out/(source.stem+'.pdf')
        if not pdf_path.is_file() or pdf_path.stat().st_mtime < started - 1:
            raise RuntimeError('LibreOffice did not generate a fresh PDF: '+cp.stdout+cp.stderr)
        pdf = fitz.open(pdf_path)
        pages=[];all_text=[]
        for i,page in enumerate(pdf):
            words=page.get_text('words')
            outside=[w for w in words if w[0]<-1 or w[1]<-1 or w[2]>page.rect.width+1 or w[3]>page.rect.height+1]
            text=page.get_text()
            all_text.append(text)
            pages.append({'page':i+1,'width_pt':page.rect.width,'height_pt':page.rect.height,'text':text,'text_blocks':page.get_text('blocks'),'text_outside_page':outside,'drawings':len(page.get_drawings())})
            page.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(dest/f'{source.stem}-page-{i+1}.png')
        (dest/(source.stem+'.pdf')).write_bytes(pdf_path.read_bytes())
    text='\n'.join(all_text)
    missing=[s for s in expected_texts if s not in text]
    result={'rtf':str(source),'renderer':'LibreOffice','rtf_structure':'passed','fresh_pdf':'passed','pages':pages,'expected_text_missing':missing,'render_checks_passed':bool(pages) and not missing and all(not p['text_outside_page'] for p in pages),'oracle_equivalence_tested':False}
    (dest/(source.stem+'-render-validation.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--expect',action='append',default=[])
    args=ap.parse_args();result=render(args.source,args.output,args.expect)
    print(json.dumps({'render_checks_passed':result['render_checks_passed'],'page_count':len(result['pages']),'expected_text_missing':result['expected_text_missing'],'oracle_equivalence_tested':False},indent=2))
    raise SystemExit(0 if result['render_checks_passed'] else 1)
