"""Generate BI Publisher RTF form fields without a Word/LibreOffice save step.

The legacy RTF FORMTEXT field carries the native BI tag in ffhelptext. Cached
results are a document preview only. This module does not execute Oracle XDO.
"""
from itertools import count
import re
from lxml import etree
from pathlib import Path

_sequence=count(1)

def reset_names():
    """Start a fresh document's deterministic generated field-name sequence."""
    global _sequence
    _sequence=count(1)

def escape(value):
    out=[]
    for c in str(value):
        if c in '{}\\':out.append('\\'+c)
        elif c=='\n':out.append(r'\line ')
        elif ord(c)>127:
            encoded=c.encode('utf-16-le')
            for i in range(0,len(encoded),2):
                u=int.from_bytes(encoded[i:i+2],'little')
                out.append(r'\u%d?'%(u if u<32768 else u-65536))
        else:out.append(c)
    return ''.join(out)

def field(code, cache='', name=None):
    """Return one native legacy form field, with a unique ffname by default."""
    if code.lstrip().startswith('<fo:'):
        parse_image(code)
    elif not code.startswith('<?') or not code.endswith('?>'):
        raise ValueError('BI Publisher code must be a native tag or validated raw FO image')
    name=name or f'BIP_{next(_sequence):05d}'
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,39}',name):
        raise ValueError('Invalid legacy Word form-field name: '+name)
    return (r'{\field{\*\fldinst FORMTEXT {\*\formfield{\fftype0\ffownhelp\fftypetxt0'
            r'{\*\ffname '+name+r'}{\*\ffhelptext '+escape(code)+r'}'
            r'{\*\ffdeftext '+escape(cache)+r'}}}}{\fldrslt '+escape(cache)+'}}')

def _destination_groups(rtf, destination):
    """Find a destination's balanced contents, respecting escaped RTF braces."""
    marker='{\\*\\'+destination
    pos=0
    while True:
        start=rtf.find(marker,pos)
        if start<0:return
        cursor=start+len(marker)
        if cursor<len(rtf) and rtf[cursor]==' ':cursor+=1
        content=cursor;depth=1
        while cursor<len(rtf) and depth:
            if rtf[cursor]=='\\':
                if cursor+1<len(rtf) and rtf[cursor+1] in '{}\\':cursor+=2;continue
            elif rtf[cursor]=='{':depth+=1
            elif rtf[cursor]=='}':depth-=1
            cursor+=1
        if depth:raise ValueError('Unterminated '+destination+' destination')
        yield rtf[content:cursor-1]
        pos=cursor

def _plain(value):
    out=[];i=0
    while i<len(value):
        if value[i]!='\\':
            if value[i] not in '{}':out.append(value[i])
            i+=1;continue
        if i+1<len(value) and value[i+1] in '{}\\':out.append(value[i+1]);i+=2;continue
        if value[i:i+2]=="\\'":
            out.append(bytes.fromhex(value[i+2:i+4]).decode('cp1256'));i+=4;continue
        match=re.match(r'\\([A-Za-z]+)(-?\d+)? ?',value[i:])
        if not match:i+=2;continue
        word,num=match.groups();i+=match.end()
        if word=='u':
            out.append(chr(int(num)%65536))
            if i<len(value) and value[i]=='?':i+=1
        elif word in ('line','par'):out.append('\n')
    # Join RTF UTF-16 surrogate pairs without altering ordinary Unicode strings.
    return ''.join(out).encode('utf-16-le','surrogatepass').decode('utf-16-le')

def extract(rtf):
    return [{'name':_plain(name),'code':_plain(code)}
            for name,code in zip(_destination_groups(rtf,'ffname'),
                                 _destination_groups(rtf,'ffhelptext'))]

FO='http://www.w3.org/1999/XSL/Format'
XSL='http://www.w3.org/1999/XSL/Transform'


def parse_image(code):
    """Validate the limited rawFO image form supported by this generator.

    This is structural validation only. It does not claim XDO compatibility.
    """
    if '<!' in code:raise ValueError('DTD/entity declarations are not permitted in image help text')
    wrapper='<root xmlns:fo="'+FO+'" xmlns:xsl="'+XSL+'">'+code+'</root>'
    root=etree.fromstring(wrapper.encode('utf-8'),etree.XMLParser(resolve_entities=False,no_network=True))
    if len(root)!=1 or root[0].tag!='{'+FO+'}instream-foreign-object':
        raise ValueError('Only one raw fo:instream-foreign-object is accepted')
    node=root[0]
    if set(node.attrib)-{'content-type','width','height'}:raise ValueError('Unsupported image FO attributes')
    mime=node.get('content-type','image/png')
    if mime not in ['image/png','image/jpeg','image/gif','image/bmp','{$QR_MIME}']:
        raise ValueError('Image MIME must be explicit or use QR_MIME parameter')
    for dim in ['width','height']:
        value=node.get(dim,'')
        if not re.fullmatch(r'[0-9]+(?:\.[0-9]+)?(?:in|cm|mm|pt)',value):
            raise ValueError('Explicit physical image '+dim+' required')
    if len(node)!=1 or node[0].tag!='{'+XSL+'}value-of' or set(node[0].attrib)!={'select'}:
        raise ValueError('Image must contain exactly one xsl:value-of select')
    path=node[0].get('select');etree.XPath(path)
    return {'xpath':path,'mime':mime,'width':node.get('width'),'height':node.get('height'),'oracle_xdo_executed':False}


def lint(rtf):
    """Validate form metadata, tag nesting, standard XPath and raw image XML.

    This is not Oracle RTF/XSL-FO compilation. Native layout remains unverified.
    """
    fields=extract(rtf);errors=[];warnings=[];stack=[];names=set();images=[];params={}
    name_count=len(list(_destination_groups(rtf,'ffname')))
    help_count=len(list(_destination_groups(rtf,'ffhelptext')))
    if name_count!=help_count:errors.append(f'Form-field metadata mismatch: {name_count} names, {help_count} help tags')
    def xpath(expression,code):
        try:etree.XPath(expression)
        except etree.XPathSyntaxError as exc:errors.append(f'Invalid standard XPath in {code}: {exc}')
    for item in fields:
        name,code=item['name'],item['code']
        if name in names:errors.append('Duplicate form-field name: '+name)
        names.add(name)
        if len(code.encode('utf-16-le'))//2>255:
            warnings.append('Help text exceeds255UTF16 units; check target Word/XDO version: '+name)
        if code.lstrip().startswith('<fo:'):
            try:images.append({'name':name,**parse_image(code)})
            except (ValueError,etree.Error) as exc:errors.append('Invalid raw FO image '+name+': '+str(exc))
            warnings.append('RawFO image requires native XDO validation: '+name)
            continue
        if not(code.startswith('<?') and code.endswith('?>')):
            errors.append('Malformed BI tag: '+code);continue
        body=code[2:-2].strip()
        if body.startswith('param@begin:'):
            try:
                key,default=body.split(':',1)[1].split(';',1)
                if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]*',key):raise ValueError('Invalid parameter name')
                if key in params:errors.append('Duplicate parameter declaration: '+key)
                params[key]=default;xpath(default,code)
            except ValueError as exc:errors.append('Invalid parameter declaration '+code+': '+str(exc))
        elif body.startswith(('if:','if@')):
            kind,expr=body.split(':',1);stack.append(('if',name));xpath(expr,code)
            if kind not in ['if','if@row','if@inlines','if@block']:
                warnings.append('Unverified BI conditional context: '+kind)
        elif body.startswith(('for-each:','for-each@')):
            kind,expr=body.split(':',1);stack.append(('for-each',name));xpath(expr,code)
            if kind not in ['for-each','for-each@section']:
                warnings.append('Unverified BI loop context: '+kind)
        elif body in ['end if','end for-each']:
            kind=body[4:]
            if not stack or stack[-1][0]!=kind:errors.append('Unmatched '+code)
            else:stack.pop()
        elif body=='else':
            if not stack or stack[-1][0]!='if':errors.append('Unmatched '+code)
        elif body.startswith('format-number:'):
            try:
                expr,mask=body.split(':',1)[1].split(';',1);xpath(expr,code);xpath(mask,code)
            except ValueError:errors.append('Invalid number-format instruction: '+code)
            warnings.append('Native number formatting needs XDO validation: '+name)
        elif body.startswith('format-date:'):
            try:
                expr,mask=body.split(':',1)[1].split(';',1);xpath(expr,code);xpath(mask,code)
            except ValueError:errors.append('Invalid date-format instruction: '+code)
            warnings.append('Native date formatting is not emulated by standard trace: '+name)
        elif body.startswith(('xdofx:','xdoxslt:','variable:','assign:','choose','when:','end choose','end when','otherwise','split-by-','page-number','total-page-count')):
            errors.append('Instruction is outside supported standard-XPath trace subset: '+code)
        else:xpath(body,code)
    if stack:errors.append('Unclosed BI tags: '+', '.join(kind+' ('+name+')' for kind,name in stack))
    return {'field_count':len(fields),'fields':fields,'parameters':params,'raw_fo_images':images,
            'errors':errors,'warnings':warnings,'passed':not errors,'oracle_xdo_executed':False}
