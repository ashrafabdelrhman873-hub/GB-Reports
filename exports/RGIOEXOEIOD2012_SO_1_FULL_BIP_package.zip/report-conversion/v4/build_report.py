#!/usr/bin/env python3
"""Complete source-object migration for RGIOEXOEIOD2012_SO_1 1.rdf.
Native BI fields are inserted after layout serialization. No SQL is executed.
"""
from pathlib import Path
import sys,json,re,subprocess,tempfile,base64,copy
from decimal import Decimal,ROUND_HALF_UP
from io import BytesIO
from docx import Document
from docx.shared import Inches,Pt
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT,WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'conditions'),str(ROOT/'runtime')]
import template_fields as fields
import visibility as rules
from layout_core import table,paragraph,gap,prop,W
from blob_image import inspect_base64
REPORT='/RGIOEXOEIOD2012_SO_1'
INVOICES=REPORT+'/LIST_G_CUSTOMER_TRX_ID/G_CUSTOMER_TRX_ID'
LINES='LIST_G_CUSTOMER_TRX_ID1/G_CUSTOMER_TRX_ID1'
TAXES='LIST_G_VAT_TAX_ID/G_VAT_TAX_ID'
RECEIPTS='LIST_G_APPLIED_CUSTOMER_TRX_ID/G_APPLIED_CUSTOMER_TRX_ID'
IMAGE='LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3/LIST_G_ID/G_ID/IMAGE'
SPEC=json.loads((ROOT/'layout/source-layout.json').read_text())
OBJECTS={x['name']:x for x in SPEC['objects']}
CONTRACT=json.loads((ROOT/'data/source-data-contract.json').read_text())
BINDINGS={x['object']:x for x in CONTRACT['field_bindings']}
PARAMS={'P_ORG_ID':'','P_FLAG':'1','DATE_CENTURY':'20','QR_MIME':'image/png'}

# Keep source families and masks. The following point sizes adapt narrow RTF
# cells to the source screenshot and Linux preview metrics; originals remain in
# source-layout.json and are reported per object, rather than silently lost.
def presentation(spec):
    name=spec['name'];region=spec['region'];family=spec['display_font']['family'] or 'Traditional Arabic'
    source_size=spec['display_font']['size_pt'] or 11
    if name=='B_25':size=30
    elif name in ['F_22','F_23']:size=15
    elif name=='F_21':size=7.2
    elif name=='F_20':size=9
    elif name in ['B_6','B_19']:size=13
    elif name=='B_29':size=10
    elif region.startswith('page_margin_footer'):size=8.3
    elif region=='R_4_receipt_row':size=8.2 if name=='F_36' else 9.2
    elif region in ['M_2_receipt_header','receipt_heading']:size=9.8
    elif region=='R_2_line_row':size=7.6 if name=='F_14' else 8 if name in ['F_5','F_10','F_15'] else 9
    elif region=='M_1_line_header':size=9 if name=='B_3' else 10.5
    elif region=='R_3_tax_row' or region=='invoice_totals':size=10 if name=='F_16' else 10.5
    elif region=='M_3_delivery_consumer_notice':size=9.5
    elif name=='F_1':size=11
    elif name.startswith('F_'):size=9
    else:size=11.5
    # Source Traditional Arabic Latin names are compact; use a proportional
    # Latin face for the receipt name so actual long names fit without fragments.
    effective_family='Times New Roman' if name=='F_36' else family
    return {'family':effective_family,'size':size,'source_family':family,'source_size':source_size}


def style_run(run,style,bold=False,rtl=False):
    run.font.name=style['family'];run.font.size=Pt(style['size']);run.bold=bold
    pr=run._element.get_or_add_rPr()
    prop(pr,'rFonts',ascii=style['family'],hAnsi=style['family'],cs=style['family'])
    prop(pr,'szCs',val=round(style['size']*2));prop(pr,'rtl',val=1 if rtl else 0)
    prop(pr,'lang',val='ar-EG' if rtl else 'en-US',bidi='ar-EG' if rtl else 'en-US')
    if bold:prop(pr,'bCs',val=1)


def raw_value(data,inv,key,row=None):
    key=key.upper()
    if key in data['root']:return data['root'][key]
    if row is not None and key in {k.upper():v for k,v in row.items()}:return {k.upper():v for k,v in row.items()}[key]
    return inv['header'].get(key)


class Builder:
    def __init__(self,data,template):
        self.data=data;self.template=template;self.inv=data['invoices'][0]
        self.params={**PARAMS,**(data.get('parameters') or {})}
        self.markers={};self.counter=0;self.used={};self.frames=set();self.trigger_sites={};self.fields=[]
    def text(self,p,text,style=None,bold=False,rtl=None):
        style=style or {'family':'Traditional Arabic','size':10}
        if rtl is None:rtl=bool(re.search('[\u0600-\u06ff]',str(text)))
        run=p.add_run(str(text));style_run(run,style,bold,rtl)
        return run
    def tag(self,p,code,cache='',obj='CODE',style=None,bold=False,rtl=False):
        if not self.template:
            if cache:self.text(p,cache,style,bold,rtl)
            return
        self.counter+=1;token=f'NATIVETAG{self.counter:05d}END';name=f'{obj}_{self.counter:05d}'
        self.markers[token]={'code':code,'cache':str(cache),'name':name}
        self.fields.append({'name':name,'code':code,'object':obj})
        self.text(p,token,style,bold,rtl)
    def register(self,name):
        spec=OBJECTS[name];self.used[name]={'source_field':spec.get('source_field'),'text':spec.get('text'),'region':spec['region'],'presentation':presentation(spec),'source_offset':spec['source_offset']}
    def visible(self,name,row=None):
        return not rules.has_trigger(name) or rules.visibility(name,header=self.inv['header'],row=row,params=self.params,root=self.data['root'])
    def begin(self,p,name,row=None,scope='inlines'):
        if not rules.has_trigger(name):return True
        expression=rules.xpath(name);self.trigger_sites[name]={'expression':expression,'scope':scope}
        if self.template:self.tag(p,('<?if:' if scope=='block' else f'<?if@{scope}:')+expression+'?>',obj=name+'_IF')
        return self.template or self.visible(name,row)
    def end(self,p,name):
        if self.template and rules.has_trigger(name):self.tag(p,'<?end if?>',obj=name+'_END')
    def scalar(self,p,expr,value,obj,style,bold=False,date_mask=False,mask=None):
        value='' if value is None else str(value);rtl=bool(re.search('[\u0600-\u06ff]',value))
        if not rtl:self.text(p,'\u200e',style,rtl=False)
        if date_mask:
            short=len(value)==9;century=str(self.params.get('DATE_CENTURY','20'))
            shown=value[:7]+century+value[7:] if short else value
            if self.template:
                self.tag(p,f'<?if@inlines:string-length({expr})=9?>',obj=obj+'_DATE')
                code=f'<?concat(substring({expr},1,7),$DATE_CENTURY,substring({expr},8,2))?>'
                self.tag(p,code,shown if short else '',obj,style,bold,rtl)
                self.tag(p,'<?end if?>',obj=obj+'_DATEEND')
                self.tag(p,f'<?if@inlines:string-length({expr})!=9?>',obj=obj+'_DATE')
                self.tag(p,f'<?{expr}?>',shown if not short else '',obj,style,bold,rtl)
                self.tag(p,'<?end if?>',obj=obj+'_DATEEND')
            elif shown:self.text(p,shown,style,bold,rtl)
        elif mask:
            digits=2 if '.00' in mask else 0
            shown='' if value=='' else format(Decimal(value).quantize(Decimal('.01') if digits else Decimal('1'),rounding=ROUND_HALF_UP),',.2f' if digits else ',.0f')
            if self.template:
                self.tag(p,f'<?if@inlines:string-length(string({expr}))>0?>',obj=obj+'_NUM')
                self.tag(p,f'<?format-number:{expr};"'+('#,##0.00' if digits else '#,##0')+'"?>',shown,obj,style,bold,rtl)
                self.tag(p,'<?end if?>',obj=obj+'_NUMEND')
            elif shown:self.text(p,shown,style,bold,rtl)
        else:self.tag(p,f'<?{expr}?>',value,obj,style,bold,rtl)
        if not rtl:self.text(p,'\u200e',style,rtl=False)
    def obj(self,p,name,row=None,bold=False):
        self.register(name);spec=OBJECTS[name];style=presentation(spec)
        if not self.begin(p,name,row):return
        if spec['class']=='field':
            bind=BINDINGS[name];expr=bind['native_expression'];key=bind['xml_element'];val=raw_value(self.data,self.inv,key,row)
            date=spec.get('format_mask')=='DD-MON-YYYY' and name in ['F_2','F_13']
            mask=spec.get('format_mask') if name in ['F_7','F_8','F_9','F_16'] else None
            self.scalar(p,expr,val,name,style,bold,date,mask)
        else:
            # Boilerplate text and lexical spelling are recovered from source.
            text=spec.get('text','')
            if isinstance(text,list):text=''.join(x['text'] for x in text)
            text=text.strip() # design padding, not the dynamic data itself
            if name in ['B_6','B_19','B_39'] and text.startswith(':'):
                text=text[1:].strip()+' :' # RTF logicalRTL punctuation order
            self.used[name]['display_text']=text
            pos=0
            for match in re.finditer(r'&([A-Za-z_][A-Za-z0-9_]*)',text):
                self.text(p,text[pos:match.start()],style,bold)
                key=match[1].upper();expr=REPORT+'/'+key if key in self.data['root'] else key
                self.scalar(p,expr,raw_value(self.data,self.inv,key,row),name,style,bold)
                pos=match.end()
            self.text(p,text[pos:],style,bold)
        self.end(p,name)
    def loop(self,p,path,name):self.tag(p,'<?for-each:'+path+'?>',obj=name+'_LOOP')
    def loop_end(self,p,name):self.tag(p,'<?end for-each?>',obj=name+'_LOOPEND')
    def image(self,p):
        self.register('F_37');self.frames.add('R_5')
        records=self.inv.get('qr_records',[]);value=next((r.get('IMAGE') for r in records if r.get('IMAGE')),None)
        if self.template:
            self.tag(p,'<?if@inlines:string-length(normalize-space('+IMAGE+'))>0?>',obj='F_37_PRESENT')
            code='<fo:instream-foreign-object content-type="{$QR_MIME}" width="1.5442in" height="0.7508in"><xsl:value-of select="'+IMAGE+'"/></fo:instream-foreign-object>'
            self.tag(p,code,obj='F_37_IMAGE')
            self.tag(p,'<?end if?>',obj='F_37_END')
        elif value:
            info=inspect_base64(value)
            if not info['mime']:raise ValueError('Unknown IMAGE content type')
            data=base64.b64decode(''.join(value.split()),validate=True)
            run=p.add_run();run.add_picture(BytesIO(data),height=Inches(.7508))


def row_para(cell,align='right',rtl=True):
    p=paragraph(cell,align=align,rtl=rtl);p.paragraph_format.line_spacing=Pt(13)
    return p


def invoice_body(doc,b):
    data=b.data;template=b.template;inv=b.inv
    outer=table(doc,[W],borders=True,height=9.2);c=outer.cell(0,0);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP;b.frames.add('R_1')
    cb=prop(c._tc.get_or_add_tcPr(),'tcBorders')
    for side in ['top','left','bottom','right']:prop(cb,side,val='single',sz=14,color='000000')
    lead=c.paragraphs[0];lead.paragraph_format.line_spacing=Pt(1)
    gap(c,.25)
    header=table(c,[W/2-.04,W/2-.04],height=.39)
    p=row_para(header.cell(0,0),'left',True);b.obj(p,'F_23',bold=True)
    p=header.cell(0,0).add_paragraph();p.paragraph_format.line_spacing=Pt(10);b.obj(p,'F_21')
    p=row_para(header.cell(0,1));b.obj(p,'F_22',bold=True)
    p=header.cell(0,1).add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.paragraph_format.line_spacing=Pt(11);b.obj(p,'F_20')
    # Margin company title has its source parameter gate.
    if template or b.visible('B_33'):
        p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;b.obj(p,'B_33')
    else:b.register('B_33')
    title=table(c,[1.25,W-1.33],height=.32)
    p=row_para(title.cell(0,0),'left',False);p.paragraph_format.line_spacing=Pt(31);b.obj(p,'B_25')
    p=row_para(title.cell(0,1),'center');b.obj(p,'B_6',bold=True);b.text(p,' ');b.obj(p,'B_19',bold=True);b.text(p,' ');b.obj(p,'F_1',bold=True)
    p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.line_spacing=Pt(1);b.obj(p,'B_26')
    gap(c,.08)
    meta=table(c,[2.01,1.0,2.56,.97],rows=6,height=.185)
    left=[('F_3','B_8'),('F_13','B_11'),('F_19','B_31'),('F_31','B_34'),('F_25','B_27'),('F_26','B_28')]
    right=[('F_2','B_7'),('F_12','B_10'),('F_11','B_9'),('F_29','F_30'),('F_24','B_23'),('F_17','B_15')]
    for i in range(6):
        for start,(value,label) in [(0,left[i]),(2,right[i])]:
            b.obj(row_para(meta.cell(i,start),'right',False),value)
            b.obj(row_para(meta.cell(i,start+1)),label,bold=True)
    # Ancillary rows have independent object gates, not generic inferred filters.
    if template or b.visible('B_32'):
        aux=table(c,[W-1.05,.97],height=.18);b.obj(row_para(aux.cell(0,0)),'F_28');b.obj(row_para(aux.cell(0,1)),'B_32')
    else:b.register('F_28');b.register('B_32')
    if template or inv['header'].get('INVOICE2') not in [None,'']:
        aux=table(c,[W-1.05,.97],height=.18);b.obj(row_para(aux.cell(0,0)),'F_27');b.obj(row_para(aux.cell(0,1)),'B_29')
    else:b.register('F_27');b.register('B_29')
    gap(c,.16)
    visible_lines=[inv['lines'][0] if inv['lines'] else {}] if template else [x for x in inv['lines'] if b.visible('R_2',x)]
    widths=[v*.974 for v in [.88,.36,.98,1.31,1.65,1.18,.20]]
    items=table(c,widths,rows=1+len(visible_lines),borders=True,height=.20);b.frames.add('M_1');b.frames.add('R_2')
    label_objects=['B_4','B_3','B_13','B_12','B_5','B_2','B_1'];field_objects=['F_7','F_6','F_15','F_14','F_10','F_5','F_4']
    for i,name in enumerate(label_objects):b.obj(row_para(items.cell(0,i),'center'),name,bold=True)
    prop(items.rows[0]._tr.get_or_add_trPr(),'tblHeader',val=1)
    for n,row in enumerate(visible_lines,1):
        for i,name in enumerate(field_objects):
            p=row_para(items.cell(n,i),'center',False)
            if template and i==0:b.loop(p,LINES,'R_2');b.begin(p,'R_2',row,'row')
            b.obj(p,name,row)
            if template and i==len(field_objects)-1:b.end(p,'R_2');b.loop_end(p,'R_2')
    if not visible_lines:
        for name in field_objects:b.register(name)
    gap(c,.17)
    # Side-by-side tax/total and QR. A1ptemptyfirst nestedrow works around the
    # LibreOffice RTF exporter dropping the first inner row's border properties.
    below=table(c,[2.85,W-2.93],height=.82)
    leftcell,rightcell=below.rows[0].cells
    leftcell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP;rightcell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP
    p=row_para(rightcell);b.obj(p,'B_16')
    p=rightcell.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;b.image(p)
    shown_taxes=[inv['taxes'][0] if inv['taxes'] else {}] if template else [x for x in inv['taxes'] if b.visible('R_3',x)]
    war=template or b.visible('F_8')
    totalrows=1+int(war)+len(shown_taxes)+1
    total=table(leftcell,[1.08,1.65],rows=totalrows,borders=True,height=.18)
    dummy=total.rows[0];dummy.height=Pt(1);dummy.height_rule=WD_ROW_HEIGHT_RULE.EXACTLY
    for cell in dummy.cells:
        edges=prop(cell._tc.get_or_add_tcPr(),'tcBorders')
        for side in ['top','left','right','bottom']:prop(edges,side,val='nil')
        cell.paragraphs[0].paragraph_format.line_spacing=Pt(1)
    idx=1
    if war:
        p=row_para(total.cell(idx,0),'right',False);b.obj(p,'F_8');b.obj(row_para(total.cell(idx,1)),'B_14',bold=True);idx+=1
    else:b.register('F_8');b.register('B_14')
    b.frames.add('R_3')
    for row in shown_taxes:
        p=row_para(total.cell(idx,0),'right',False)
        if template:b.loop(p,TAXES,'R_3');b.begin(p,'R_3',row,'row')
        b.obj(p,'F_16',row);p=row_para(total.cell(idx,1));b.obj(p,'F_18',row,bold=True)
        if template:b.end(p,'R_3');b.loop_end(p,'R_3')
        idx+=1
    if not shown_taxes:b.register('F_16');b.register('F_18')
    b.obj(row_para(total.cell(idx,0),'right',False),'F_9',bold=True);b.obj(row_para(total.cell(idx,1)),'B_24',bold=True)
    gap(c,.40)
    p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.paragraph_format.line_spacing=Pt(13);b.obj(p,'B_39')
    show_table=template or bool(inv['receipts']) or b.visible('B_36')
    b.frames.add('M_2');b.frames.add('R_4')
    if show_table:
        if template:b.tag(p,'<?if:count('+RECEIPTS+')>0 or number('+REPORT+'/CF_REC_COUNT)>0?>',obj='RECEIPT_FRAME')
        recs=[inv['receipts'][0] if inv['receipts'] else {}] if template else inv['receipts']
        receipts=table(c,[1.45,.91,.71,.94,.69],rows=1+len(recs),borders=True,height=.239)
        for i,name in enumerate(['B_41','B_40','B_38','B_36','B_37']):b.obj(row_para(receipts.cell(0,i),'center'),name,bold=True)
        prop(receipts.rows[0]._tr.get_or_add_trPr(),'tblHeader',val=1)
        for n,row in enumerate(recs,1):
            for i,name in enumerate(['F_36','F_35','F_34','F_33','F_32']):
                p=row_para(receipts.cell(n,i),'center',False)
                if template and i==0:b.loop(p,RECEIPTS,'R_4')
                b.obj(p,name,row)
                if template and i==4:b.loop_end(p,'R_4')
        if template:b.tag(c.add_paragraph(),'<?end if?>',obj='RECEIPT_FRAME_END')
    else:
        for name in ['B_41','B_40','B_38','B_36','B_37','F_36','F_35','F_34','F_33','F_32']:b.register(name)
    # Source M3 gates consumer information and delivery date together. B46 has
    # an additional non-nullCP_CAR gate; B44 has no independenttrigger.
    b.frames.add('M_3')
    if template or b.visible('M_3'):
        gap(c,.08);p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.paragraph_format.line_spacing=Pt(13)
        if template:b.begin(p,'M_3',scope='block')
        b.obj(p,'B_46')
        p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.paragraph_format.line_spacing=Pt(13);b.obj(p,'B_44')
        if template:b.end(p,'M_3')
    else:b.register('B_46');b.register('B_44')
    gap(c,.30)
    footer=table(c,[1.35,3.48,1.73],rows=2,height=.17)
    p=row_para(footer.cell(0,0),'left');b.obj(p,'B_17');b.text(p,'   ');b.obj(p,'B_30',bold=True)
    b.obj(row_para(footer.cell(1,0),'left'),'B_20');b.obj(row_para(footer.cell(1,1),'center'),'B_21');b.obj(row_para(footer.cell(1,2)),'B_22')
    p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.line_spacing=Pt(11);b.obj(p,'B_18')
    p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.line_spacing=Pt(11);b.obj(p,'B_35')


def make_docx(data,path,template=False):
    b=Builder(data,template);inv=b.inv;doc=Document();section=doc.sections[0]
    section.page_width=Inches(8.2677);section.page_height=Inches(11.6929)
    section.left_margin=Inches(.8);section.right_margin=Inches(.8);section.top_margin=Inches(.7);section.bottom_margin=Inches(.7)
    normal=doc.styles['Normal'];normal.font.name='Traditional Arabic';normal.font.size=Pt(10)
    normal.paragraph_format.space_before=Pt(0);normal.paragraph_format.space_after=Pt(0)
    top=doc.add_paragraph();top.paragraph_format.line_spacing=Pt(1)
    for key,value in PARAMS.items():b.tag(top,"<?param@begin:"+key+";'"+str(value)+"'?>",obj='PARAM_'+key)
    b.tag(top,'<?for-each@section:'+INVOICES+'?>',obj='R_1_SECTION')
    for index,invoice in enumerate(data['invoices'][:1] if template else data['invoices']):
        if index:doc.add_page_break()
        b.inv=invoice
        invoice_body(doc,b)
    end=doc.add_paragraph();end.paragraph_format.line_spacing=Pt(1);b.tag(end,'<?end for-each?>',obj='R_1_SECTION_END')
    # Collapse mandatory structural empty paragraphs, keeping exact spacerrows.
    for node in doc.element.body.iter(qn('w:p')):
        if not ''.join(node.itertext()).strip():prop(prop(node,'pPr'),'spacing',before=0,after=0,line=20,lineRule='exact')
    # Preserve physical alignment lost by LibreOffice's nestedtableRTF exporter.
    align_index=0
    for node in doc.element.body.iter(qn('w:p')):
        pr=node.find(qn('w:pPr'));jc=pr.find(qn('w:jc')) if pr is not None else None
        if jc is None or not ''.join(node.itertext()).strip():continue
        align_index+=1;token=f'RTFALIGN{align_index:05d}END';r=OxmlElement('w:r');text=OxmlElement('w:t');text.text=token;r.append(text);node.insert(1 if pr is not None else 0,r)
        b.markers[token]={'code':'RTF:'+{'left':r'\ql ','right':r'\qr ','center':r'\qc '}.get(jc.get(qn('w:val')),r'\ql '),'cache':'','name':token}
    doc.save(path)
    return b


def convert_docx(source,out):
    with tempfile.TemporaryDirectory(prefix='new-report-',dir='/tmp') as tmp:
        cp=subprocess.run(['soffice',f'-env:UserInstallation={Path(tmp).as_uri()}','--headless','--convert-to','rtf','--outdir',str(out),str(source)],capture_output=True,text=True,timeout=90)
    result=out/(source.stem+'.rtf')
    if cp.returncode or not result.exists():raise RuntimeError(cp.stdout+cp.stderr)
    return result


def build(data=None,stem='RGIOEXOEIOD2012_SO_1_FULL_BIP',template=True):
    if data is None:data=json.loads((ROOT/'data/actual-fixture.json').read_text())
    out=ROOT/'output';out.mkdir(exist_ok=True)
    source=out/(stem+'.docx');b=make_docx(data,source,template);rtf=convert_docx(source,out)
    text=rtf.read_text('latin1');fields.reset_names()
    for token,marker in sorted(b.markers.items(),key=lambda item:not item[1]['code'].startswith('RTF:')):
        if text.count(token)!=1:raise ValueError('Serializationchangedmarker '+token+' count='+str(text.count(token)))
        if marker['code'].startswith('RTF:'):
            at=text.index(token);start=text.rfind(r'\pard',0,at);brace=text.find('{',start,at)
            if brace<0:raise ValueError('No paragraphscope '+token)
            text=text[:brace]+marker['code'][4:]+text[brace:];text=text.replace(token,'')
        else:text=text.replace(token,fields.field(marker['code'],marker['cache'],marker['name']))
    rtf.write_text(text,encoding='latin1')
    report={'source_sha256':SPEC['source_sha256'],'template':template,'objects_migrated':len(b.used),'object_names':sorted(b.used),'missing_objects':sorted(set(OBJECTS)-set(b.used)),'frames_migrated':sorted(b.frames),'source_trigger_owners':sorted(rules.RULES),'native_trigger_sites':b.trigger_sites,'presentation':b.used,'data_is_actual':not data.get('test_only',False),'oracle_xdo_executed':False}
    if template:
        lint=fields.lint(text);report['native_fields']=lint
        if not lint['passed']:raise ValueError(lint['errors'])
        if report['missing_objects']:raise ValueError('Unmigratedsourceobjects '+str(report['missing_objects']))
        if set(rules.RULES)-set(b.trigger_sites):raise ValueError('Unmigratedsourceconditions '+str(set(rules.RULES)-set(b.trigger_sites)))
    (out/(stem+'-migration.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2))
    return rtf

if __name__=='__main__':
    build();build(stem='actual-new-source-preview',template=False)
