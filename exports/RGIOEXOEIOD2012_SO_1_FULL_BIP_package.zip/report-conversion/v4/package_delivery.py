from pathlib import Path
from importlib.metadata import version
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent;WORKSPACE=PROJECT.parent
(ROOT/'requirements.txt').write_text('\n'.join(name+'=='+version(name) for name in ['python-docx','lxml','PyMuPDF','Pillow','reportlab'])+'\n')
v=json.loads((ROOT/'output/validation.json').read_text());text=(ROOT/'README.md').read_text();text=text.replace('78 اختبار وحدة',str(v['unit_tests_run'])+' اختبار وحدة');(ROOT/'README.md').write_text(text)
status={'selected_source':'RGIOEXOEIOD2012_SO_1 1.rdf','source_sha256':v['source_rdf_sha256'],'template':'RGIOEXOEIOD2012_SO_1_FULL_BIP.rtf','template_sha256':hashlib.sha256((ROOT/'output/RGIOEXOEIOD2012_SO_1_FULL_BIP.rtf').read_bytes()).hexdigest(),'source_fields_and_text_objects_migrated':80,'frames':8,'format_triggers_implemented':27,'callback_owners_verified':27,'unit_tests_passed':v['unit_tests_run'],'local_binding_and_render_cases_passed':len(v['local_render_cases']),'actual_preview_pages':1,'oracle_xdo_executed':False,'actual_qr_available':False,'actual_missing_xml_field':'IMAGE','required_runtime_parameter':'P_ORG_ID original global value; no per-invoice ORG_ID fallback','source_parameter_default_P_FLAG':'1','pixel_equivalence_certified':False,'production_certified':False}
(ROOT/'output/delivery-status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
files=[]
for f in ROOT.rglob('*'):
 if not f.is_file() or '__pycache__' in f.parts or f.suffix in ['.docx','.zip'] or f.name=='package-manifest.json':continue
 if 'output' in f.parts and f.name not in ['RGIOEXOEIOD2012_SO_1_FULL_BIP.rtf','RGIOEXOEIOD2012_SO_1_FULL_BIP-migration.json','validation.json','native-binding-validation.json','delivery-status.json','preview-actual.pdf','preview-actual-page-1.png','preview-actual-render-validation.json'] and f.suffix!='.pdf':continue
 files.append(f)
files+=[PROJECT/'comparison/new/RGIOEXOEIOD2012_SO_1 1.rdf',PROJECT/'comparison/layout/new-layout.json',PROJECT/'comparison/layout/new-records.json',PROJECT/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml',PROJECT/'tool-research/render_rtf.py',PROJECT/'tool-research/fontconfig-naskh.conf']
files+=[f for f in (PROJECT/'comparison/logic/new').glob('*') if f.is_file() and f.suffix in ['.json','.sql','.py']]
files=sorted(set(files));manifest={str(f.relative_to(WORKSPACE)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(ROOT/'output/package-manifest.json').write_text(json.dumps(manifest,indent=2));files.append(ROOT/'output/package-manifest.json')
p=ROOT/'RGIOEXOEIOD2012_SO_1_FULL_BIP_package.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,str(f.relative_to(WORKSPACE)))
with zipfile.ZipFile(p) as z:assert z.testzip() is None;print('Package checksum-tested:',len(z.namelist()),'files;',p.stat().st_size,'bytes')
print('Validated unit tests:',status['unit_tests_passed'])
