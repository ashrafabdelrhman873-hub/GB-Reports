#!/usr/bin/env python3
"""Verify the complete selected RDF migration; no Oracle engine is invoked."""
from pathlib import Path
import sys,json,subprocess,re,os,hashlib
from concurrent.futures import ThreadPoolExecutor
import fitz
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'qa'),str(ROOT/'data'),str(ROOT.parent/'tool-research')]
from scenarios import generate
from source_contract import load_actual
from build_report import build
from tag_trace import validate
from render_rtf import render
ACTUAL=ROOT.parent/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml'

def suite(folder):
    p=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(folder),'-p','test_*.py','-v'],capture_output=True,text=True)
    m=re.search(r'Ran (\d+) tests?',p.stderr)
    return {'name':folder.name,'tests_run':int(m[1]) if m else 0,'passed':p.returncode==0 and bool(m),'output':p.stderr}

def preview(item):
    name,case=item;data=load_actual(case['xml'],case.get('parameters'));data['test_only']=name!='actual'
    path=build(data,'preview-'+name,False)
    dest=ROOT/'output/previews'
    for old in dest.glob(path.stem+'-page-*.png'):old.unlink()
    result=render(path,dest,[])
    pdf=fitz.open(dest/(path.stem+'.pdf'));text=''.join(x.get_text() for x in pdf)
    extra={}
    if name=='actual':
        extra['single_page']=len(pdf)==1
        extra['integer_grouped_total']='990,000' in text and '990,000.00' not in text
        extra['all_receipt_ids_present']=all(x['RECEIPT_NUMBER'] in text for x in data['invoices'][0]['receipts'])
    if name=='suppressed-data-rows':extra['hidden_rows_absent']='HIDDEN_WARRANTY_ITEM' not in text and 'HIDDEN_ZERO_TAX' not in text
    if name=='two-invoices':extra['second_invoice_not_dropped']='SECOND_INVOICE_TEST' in text;extra['multiple_pages']=len(pdf)>=2
    if name=='oracle-null-inputs':extra['no_nan_printed']='NaN' not in text
    if name=='no-receipts':extra['no_receipt_values']=not any(x in text for x in ['1300000925','1300004297'])
    return {'case':name,'pages':len(pdf),'renderer_passed':result['render_checks_passed'],'checks':extra,'passed':result['render_checks_passed'] and all(extra.values()),'data_is_synthetic':name!='actual','oracle_xdo_executed':False}

def main():
    os.environ['FONTCONFIG_FILE']=str(ROOT.parent/'tool-research/fontconfig-naskh.conf')
    # Build the single native template once. Preview data expansion is separate.
    build()
    suites=[ROOT/'conditions',ROOT/'data',ROOT/'runtime',ROOT/'qa']
    with ThreadPoolExecutor(max_workers=4) as pool:units=list(pool.map(suite,suites))
    if not all(x['passed'] for x in units):
        print(json.dumps(units,indent=2));raise SystemExit(1)
    cases={'actual':{'xml':str(ACTUAL),'parameters':{}},**generate()}
    native=[]
    for name,case in cases.items():
        report,trace,sheet=validate(case['xml'],ROOT/'output/RGIOEXOEIOD2012_SO_1_FULL_BIP.rtf',case['parameters'])
        native.append({'case':name,'passed':report['binding_checks_passed'],'scalar_occurrences':report['evaluated_scalar_occurrences'],'missing':report['missing_or_ambiguous_bindings'],'loops':report['loop_checks'],'images':report['optional_image_bindings']})
        if name=='actual':
            (ROOT/'output/native-binding-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
            (ROOT/'output/actual-data-trace.xml').write_bytes(__import__('lxml.etree',fromlist=['etree']).tostring(trace,encoding='UTF-8',xml_declaration=True,pretty_print=True))
    with ThreadPoolExecutor(max_workers=2) as pool:renders=list(pool.map(preview,cases.items()))
    migration=json.loads((ROOT/'output/RGIOEXOEIOD2012_SO_1_FULL_BIP-migration.json').read_text())
    summary={'source_rdf_sha256':migration['source_sha256'],'source_xml_sha256':hashlib.sha256(ACTUAL.read_bytes()).hexdigest(),'source_objects_migrated':migration['objects_migrated'],'source_frames_migrated':len(migration['frames_migrated']),'source_format_triggers_implemented':len(migration['native_trigger_sites']),'missing_source_objects':migration['missing_objects'],'unit_suites':units,'unit_tests_run':sum(x['tests_run'] for x in units),'unit_tests_passed':all(x['passed'] for x in units),'native_xpath_cases':native,'native_xpath_cases_passed':all(x['passed'] for x in native),'local_render_cases':renders,'local_render_cases_passed':all(x['passed'] for x in renders),'oracle_xdo_executed':False,'native_xdo_pagination_verified':False,'actual_source_qr_available':False,'synthetic_qr_test_is_not_actual_invoice_qr':True,'source_fonts_exact_metrics_verified':False}
    (ROOT/'output/validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ['unit_suites','native_xpath_cases']},ensure_ascii=False,indent=2))
    raise SystemExit(0 if summary['unit_tests_passed'] and summary['native_xpath_cases_passed'] and summary['local_render_cases_passed'] else 1)
if __name__=='__main__':main()
