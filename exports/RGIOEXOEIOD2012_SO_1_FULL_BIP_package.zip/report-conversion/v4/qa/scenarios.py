from pathlib import Path
import sys,copy,json
from lxml import etree as E
ROOT=Path(__file__).resolve().parents[1]
ACTUAL=ROOT.parent/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml'

def generate():
    base=E.parse(str(ACTUAL));cases={}
    def add(name,mutate=lambda x:None,params=None,visible=(),hidden=(),note='Synthetic visibility branch; not production data'):
        x=copy.deepcopy(base);mutate(x)
        p=ROOT/'qa/fixtures'/(name+'.xml');p.write_bytes(E.tostring(x,encoding='UTF-8',xml_declaration=True,pretty_print=True))
        cases[name]={'xml':str(p),'parameters':params or {},'visible':list(visible),'hidden':list(hidden),'note':note}
    def put(x,key,value,root=False):
        n=x.find(key) if root else x.find('.//G_CUSTOMER_TRX_ID/'+key)
        if n is None:raise ValueError(key)
        n.text=value
    add('org-3361',params={'P_ORG_ID':'3361'},visible=['B_33'],hidden=['M_3','B_46'])
    add('return-order',lambda x:put(x,'CP_ORDER_CATOGERY','RETURN',True),hidden=['M_3','B_46'])
    def identity(x):
        for key,val in [('ORG_ID','2434'),('CUSTOMER_NUMBER','254890'),('CUSTOMER_NAME2','SECOND_CUSTOMER_TEST'),('CUSTOMER_TYPE','ORGANIZATION'),('ORGANIZATION_NAME_PHONETIC','OFFICE_TEST'),('CF_TOTAL_CEIL','149999.99'),('INVOICE_CURRENCY_CODE','EGP')]:put(x,key,val)
    add('organization-low-egp',identity,visible=['B_32','F_28','B_34','F_31'],hidden=['F_11','F_12','F_29','F_30'])
    def discount(x):
        for key,val in [('CAT','PC Sales Discount Items'),('INVOICE2','ANNEX_TEST'),('ATTRIBUTE_NEW','DISCOUNT_NOTE_TEST'),('CS_WAR','250')]:put(x,key,val)
    add('discount-copy-warranty',discount,params={'P_FLAG':'0'},visible=['B_19','F_17','B_25','B_29','F_8','B_14'],hidden=['B_6'])
    def suppressed(x):
        h=x.find('.//G_CUSTOMER_TRX_ID');line=h.find('LIST_G_CUSTOMER_TRX_ID1');row=copy.deepcopy(line[0]);row.find('CF_ITEM_DESC').text='WARRANTY';row.find('CF_ITEM').text='HIDDEN_WARRANTY_ITEM';row.find('CF_NET_AMOUNT').text='0';row.find('CF_WARRANTY').text='0';row.find('CS_1').text='2';line.append(row)
        tax=h.find('LIST_G_VAT_TAX_ID');row=copy.deepcopy(tax[0]);row.find('TAX_AMOUNT').text='0';row.find('TAX_CODE').text='HIDDEN_ZERO_TAX';tax.append(row)
    add('suppressed-data-rows',suppressed)
    def nulls(x):
        for key in ['ORG_ID','CUSTOMER_TYPE','CF_TOTAL_CEIL','CS_WAR','INTERFACE_HEADER_ATTRIBUTE15']:put(x,key,None)
        for key in ['CF_REC_COUNT','CP_CAR','CP_ORDER_CATOGERY']:put(x,key,None,True)
        x.find('.//G_CUSTOMER_TRX_ID/LIST_G_VAT_TAX_ID/G_VAT_TAX_ID/TAX_AMOUNT').text=None
    add('oracle-null-inputs',nulls,params={'P_FLAG':None,'P_ORG_ID':None},visible=['B_25','B_14','F_8','B_34','F_31','F_29','F_30','M_3'],hidden=['B_33','B_46','B_36','B_39'])
    def empty(x):
        x.find('.//G_CUSTOMER_TRX_ID/LIST_G_APPLIED_CUSTOMER_TRX_ID').clear();put(x,'CF_REC_COUNT','0',True)
    add('no-receipts',empty,hidden=['B_36','B_37','B_38','B_39','B_40','B_41'])
    def multi(x):
        container=x.find('LIST_G_CUSTOMER_TRX_ID');h=copy.deepcopy(container[0]);h.find('TRX_NUMBER').text='SECOND_INVOICE_TEST';h.find('ORG_ID').text='3361';container.append(h)
    add('two-invoices',multi,params={'P_ORG_ID':'101'},hidden=['B_33'])
    qr=ROOT/'data/synthetic-qr-TEST-ONLY.xml'
    cases['synthetic-qr-TEST-ONLY']={'xml':str(qr),'parameters':{},'visible':[],'hidden':[],'note':'SYNTHETIC QR ONLY, not original invoice QR'}
    (ROOT/'qa/scenarios.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2))
    return cases
if __name__=='__main__':print('Created',len(generate()),'clearly synthetic integration cases')
