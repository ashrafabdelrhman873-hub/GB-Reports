from pathlib import Path
import unittest,sys,json,hashlib,tempfile,copy
from lxml import etree as E
from docx import Document
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'conditions'),str(ROOT/'data'),str(ROOT/'qa')]
from tag_trace import validate
from build_report import make_docx,OBJECTS
from source_contract import load_actual
from scenarios import generate
import visibility
RTF=ROOT/'output/RGIOEXOEIOD2012_SO_1_FULL_BIP.rtf'

class FullMigrationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.cases=generate()
 def branch(self,t,obj):return bool(t.xpath('//branch[starts-with(@prototype,$prefix)]',prefix=obj+'_IF_'))
 def test_all80_sourceobjects_and8frames_migrated(self):
  m=json.loads((ROOT/'output/RGIOEXOEIOD2012_SO_1_FULL_BIP-migration.json').read_text())
  self.assertEqual(set(m['object_names']),set(OBJECTS));self.assertEqual(m['missing_objects'],[]);self.assertEqual(len(m['frames_migrated']),8)
 def test_all27_callback_predicates_are_present(self):
  m=json.loads((ROOT/'output/RGIOEXOEIOD2012_SO_1_FULL_BIP-migration.json').read_text())
  self.assertEqual(set(m['native_trigger_sites']),set(visibility.RULES))
  for obj,p in m['native_trigger_sites'].items():self.assertEqual(p['expression'],visibility.xpath(obj))
 def test_multiline_frame_uses_block_condition_not_inline(self):
  m=json.loads((ROOT/'output/RGIOEXOEIOD2012_SO_1_FULL_BIP-migration.json').read_text())
  self.assertEqual(m['native_trigger_sites']['M_3']['scope'],'block')
  self.assertEqual(m['native_trigger_sites']['R_2']['scope'],'row');self.assertEqual(m['native_trigger_sites']['R_3']['scope'],'row')
 def test_actual_bindings_no_missing_paths(self):
  r,t,_=validate(ROOT.parent/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml',RTF)
  self.assertTrue(r['binding_checks_passed'],r['missing_or_ambiguous_bindings'])
  self.assertFalse(t.xpath('//image'))
 def test_mapped_source_fields_are_exact(self):
  rtf=RTF.read_text('latin1')
  for expected in ['<?CS_1?>','<?RECEIPT_NUMBER?>','<?CUSTOMER_IDENTITY_PROMPET?>','<?ATTRIBUTE_NEW?>']:self.assertIn(expected,rtf)
  for wrong in ['<?LINE_NUMBER?>','<?DOC_SEQUENCE_VALUE?>','<?CF_FIELD_NAME?>','<?COMMENT?>']:self.assertNotIn(wrong,rtf)
 def test_source_integer_total_mask_and_date_mask(self):
  _,t,_=validate(ROOT.parent/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml',RTF)
  total=t.xpath('//field[starts-with(@prototype,"F_9_")]')[0]
  self.assertEqual(total.text,'990,000');self.assertEqual(t.xpath('string(//field[starts-with(@prototype,"F_2_")])'),'20-JAN-2026')
 def test_branch_matrix_matches_source_callbacks(self):
  for name,c in self.cases.items():
   with self.subTest(case=name):
    report,t,_=validate(c['xml'],RTF,c['parameters']);self.assertTrue(report['binding_checks_passed'],report['missing_or_ambiguous_bindings'])
    for obj in c['visible']:self.assertTrue(self.branch(t,obj),obj)
    for obj in c['hidden']:self.assertFalse(self.branch(t,obj),obj)
 def test_hidden_warranty_and_zero_tax_data_not_emitted(self):
  _,t,_=validate(self.cases['suppressed-data-rows']['xml'],RTF)
  text=''.join(t.xpath('//field/text()'));self.assertNotIn('HIDDEN_WARRANTY_ITEM',text);self.assertNotIn('HIDDEN_ZERO_TAX',text)
  groups=t.xpath('//group[contains(@prototype,"R_2_LOOP_")]');self.assertEqual(len(groups),2)
  self.assertEqual(sum(bool(g.xpath('.//field')) for g in groups),1)
 def test_null_numbers_do_not_print_nan(self):
  c=self.cases['oracle-null-inputs'];_,t,_=validate(c['xml'],RTF,c['parameters'])
  self.assertNotIn('NaN',''.join(t.xpath('//field/text()')))
 def test_zero_root_receipt_count_hides_headers_not_actual_rows(self):
  c=self.cases['oracle-null-inputs'];_,t,_=validate(c['xml'],RTF,c['parameters'])
  self.assertFalse(self.branch(t,'B_36'));self.assertEqual(len(t.xpath('//field[starts-with(@prototype,"F_33_")]')),6)
 def test_no_receipt_rows_are_not_replaced_with_sample_data(self):
  c=self.cases['no-receipts'];_,t,_=validate(c['xml'],RTF)
  self.assertFalse(t.xpath('//field[starts-with(@prototype,"F_33_")]'))
 def test_synthetic_qr_is_separate_and_optional(self):
  c=self.cases['synthetic-qr-TEST-ONLY'];r,t,_=validate(c['xml'],RTF)
  self.assertEqual(len(t.xpath('//image')),1);self.assertEqual(t.xpath('string(//image/@found)'),'1')
  self.assertTrue('TEST-ONLY' in c['xml'])
 def test_multiple_invoices_keep_global_source_parameter(self):
  c=self.cases['two-invoices'];_,t,_=validate(c['xml'],RTF,c['parameters'])
  values=t.xpath('//field[starts-with(@prototype,"F_1_")]/text()');self.assertEqual(len(values),2);self.assertIn('SECOND_INVOICE_TEST',values);self.assertFalse(self.branch(t,'B_33'))
 def test_local_multiinvoice_preview_does_not_drop_second_invoice(self):
  c=self.cases['two-invoices'];data=load_actual(c['xml'],c['parameters'])
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'preview.docx';make_docx(data,p,False);d=Document(p);text=''.join(n.text or '' for n in d.element.body.iter(qn('w:t')))
   self.assertIn('SECOND_INVOICE_TEST',text)
 def test_original_source_files_unchanged(self):
  self.assertEqual(hashlib.sha256((ROOT.parent/'comparison/new/RGIOEXOEIOD2012_SO_1 1.rdf').read_bytes()).hexdigest(),'50444cbd5947261ac3c9ba37a83c21bad59e07151beb6bb432900f06e957514b')
  self.assertEqual(hashlib.sha256((ROOT.parent/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml').read_bytes()).hexdigest(),'299fb3492ce3446ede9ad6e97760a44c189a8b90d8c74ae5d6b56f35134bcfdb')
if __name__=='__main__':unittest.main(verbosity=2)
