from pathlib import Path
import unittest,tempfile,copy,json,hashlib,base64,io
from lxml import etree as ET
from PIL import Image
import source_contract as c

class NewSourceDataTests(unittest.TestCase):
 def setUp(self):self.raw=c.load_actual()
 def temporary_xml(self,doc,callback):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'case.xml';p.write_bytes(ET.tostring(doc,encoding='UTF-8',xml_declaration=True));return callback(p)
 def test_all_actual_rows_read_without_omission(self):
  self.assertEqual(len(self.raw['invoices']),1);inv=self.raw['invoices'][0]
  self.assertEqual({k:len(inv[k]) for k in ['lines','taxes','receipts','qr_records']},{'lines':1,'taxes':3,'receipts':6,'qr_records':1})
 def test_raw_leaf_values_and_nulls_preserved(self):
  doc=c.xml_from(c.ACTUAL);h=doc.find('.//G_CUSTOMER_TRX_ID')
  self.assertEqual(self.raw['root'],c.leaves(doc.getroot()));self.assertEqual(self.raw['invoices'][0]['header'],c.leaves(h))
  self.assertIsNone(self.raw['invoices'][0]['header']['CHAS_NO'])
  self.assertEqual(self.raw['invoices'][0]['header']['TRX_DATE'],h.findtext('TRX_DATE'))
 def test_parameters_not_inferred_from_invoice(self):
  self.assertEqual(self.raw['parameters'],{'P_FLAG':'1','P_ORG_ID':None})
  inv=self.raw['invoices'][0];self.assertNotIn('P_ORG_ID',inv['header']);self.assertNotIn('P_FLAG',self.raw['root'])
 def test_explicit_null_parameter_not_replaced_by_default(self):
  f=c.load_actual(parameters={'P_FLAG':None,'P_ORG_ID':'3361'})
  self.assertIsNone(f['parameters']['P_FLAG']);self.assertEqual(f['parameters']['P_ORG_ID'],'3361')
 def test_actual_financial_checks_and_all6_links(self):
  a=c.financial_audit(self.raw);self.assertTrue(a['all_financial_checks_passed']);self.assertTrue(a['all_data_links_passed'])
 def test_cent_precision_difference_is_detected(self):
  f=copy.deepcopy(self.raw);f['invoices'][0]['lines'][0]['CF_NET_AMOUNT']=str(c.money(f['invoices'][0]['lines'][0]['CF_NET_AMOUNT'])+c.Decimal('.01'))
  a=c.financial_audit(f);self.assertFalse(a['all_financial_checks_passed']);self.assertTrue(a['all_data_links_passed'])
 def test_wrong_header_link_detected_independently(self):
  f=copy.deepcopy(self.raw);f['invoices'][0]['lines'][0]['HEADER_ID1']='WRONG'
  a=c.financial_audit(f);self.assertTrue(a['all_financial_checks_passed']);self.assertFalse(a['all_data_links_passed'])
 def test_two_invoice_groups_do_not_leak_rows(self):
  doc=c.xml_from(c.ACTUAL);container=doc.find('LIST_G_CUSTOMER_TRX_ID');second=copy.deepcopy(container[0]);container.append(second)
  second.find('CUSTOMER_NAME').text='SECOND-CUSTOMER';second.find('CUSTOMER_TRX_ID').text='999999';second.find('HEADER_ID').text='888888'
  for e in second.findall('LIST_G_CUSTOMER_TRX_ID1/G_CUSTOMER_TRX_ID1'):
   e.find('CUSTOMER_TRX_ID1').text='999999';e.find('HEADER_ID1').text='888888';e.find('CF_ITEM').text='SECOND-ITEM'
  for e in second.findall('LIST_G_VAT_TAX_ID/G_VAT_TAX_ID'):e.find('CUSTOMER_TRX_ID2').text='999999'
  for e in second.findall('LIST_G_APPLIED_CUSTOMER_TRX_ID/G_APPLIED_CUSTOMER_TRX_ID'):e.find('APPLIED_CUSTOMER_TRX_ID').text='999999'
  for g in second.findall('LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3'):
   g.find('CUSTOMER_TRX_ID3').text='999999'
   for e in g.findall('LIST_G_ID/G_ID'):e.find('ID').text='999999'
  f=self.temporary_xml(doc,c.load_actual);self.assertEqual(len(f['invoices']),2)
  self.assertNotEqual(f['invoices'][0]['lines'][0]['CF_ITEM'],'SECOND-ITEM');self.assertEqual(f['invoices'][1]['lines'][0]['CF_ITEM'],'SECOND-ITEM')
  self.assertTrue(c.financial_audit(f)['all_data_links_passed'])
 def test_all37_field_bindings_only_missing_image(self):
  contract=c.contract();self.assertEqual(contract['field_count'],37);self.assertEqual(contract['missing_actual_field_objects'],['F_37'])
  aliases={x['object']:x for x in contract['field_bindings']};self.assertEqual(aliases['F_14']['xml_element'],'LOT_NUMBER')
  self.assertEqual(aliases['F_33']['xml_element'],'RECEIPT_NUMBER');self.assertEqual(aliases['F_30']['xml_element'],'CUSTOMER_IDENTITY_PROMPET')
 def test_source_parameter_defaults_from_records(self):
  ps={x['name']:x for x in c.contract()['parameters']}
  self.assertEqual(ps['P_FLAG']['source_default'],'1');self.assertIsNone(ps['P_ORG_ID']['source_default'])
  self.assertFalse(ps['P_FLAG']['exported_in_actual_xml']);self.assertFalse(ps['P_ORG_ID']['exported_in_actual_xml'])
 def test_boilerplate_references_present_without_fabrication(self):
  self.assertTrue(all(x['actual_xml_present'] for x in c.contract()['boilerplate_dynamic_references']))
  self.assertIsNone(self.raw['invoices'][0]['header']['CF_2'])
 def test_synthetic_qr_cannot_be_confused_with_original(self):
  before=c.ACTUAL.read_bytes();manifest=c.synthetic_qr_fixture();doc=c.xml_from(c.BASE/manifest['xml'])
  self.assertEqual(c.ACTUAL.read_bytes(),before);self.assertEqual(len(c.xml_from(c.ACTUAL).xpath('//IMAGE')),0)
  nodes=doc.xpath('//IMAGE');self.assertTrue(nodes)
  for node in nodes:
   self.assertEqual(node.get('synthetic'),'true');payload=base64.b64decode(node.text,validate=True)
   self.assertEqual(hashlib.sha256(payload).hexdigest(),manifest['png_sha256'])
   with Image.open(io.BytesIO(payload)) as im:self.assertEqual(im.format,'PNG');im.verify()
  self.assertTrue(manifest['not_production_QR']);self.assertFalse(manifest['decoded_by_independent_QR_decoder'])

if __name__=='__main__':unittest.main(verbosity=2)
