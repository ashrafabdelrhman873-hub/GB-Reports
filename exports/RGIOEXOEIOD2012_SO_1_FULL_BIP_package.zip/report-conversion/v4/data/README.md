# New RDF data contract and actual XML fixtures

`source-data-contract.json` maps every one of the new RDF's37 fields, source parameter definitions, and dynamic boilerplate references to the actual XML. All36 text/number/date field bindings exist; onlyF_37 (IMAGE) is missing from the old XML. `actual-fixture.json` preserves original XML leaf text, empty elements as `null`, separate root and invoice contexts, and original date strings. It does not silently merge root values into invoice data, calculate missing source outputs, or infer P_ORG_ID.

The actual data has1 invoice,1 line,3 taxes,6 receipts and1 QR ID record. Financial totals and all six original data links pass. `actual-data-checks.json` contains these results without copying personal values into console output.

## Parameters

The new RDF source P_FLAG parameter at physical offset412484 has a stored default of1 (attribute10). Its parameter datatype is raw code1 (NUMBER). P_ORG_ID has an empty source default. Both are absent from actual XML. Defaults are exposed as `P_FLAG="1"`, `P_ORG_ID=null`; an explicitly supplied null P_FLAG is preserved as null. The new AfterPForm keeps LOW/HIGH distinct and determines P_ORG_ID using LOW. It is not safe to derive P_ORG_ID separately from every invoice ORG_ID.

The layout directly uses P_FLAG/P_ORG_ID. Data-query/source parameters P_ORDER_NUMBER_LOW, P_ORDER_NUMBER_HIGH, P_TRX and P_TYPE_ID are recorded too; no SQL is executed here. P_TYPE_ID appears only in commented header SQL filtering, so its declaration is not evidence that the active query uses it.

## Field scopes

Invoice loop: `/RGIOEXOEIOD2012_SO_1/LIST_G_CUSTOMER_TRX_ID/G_CUSTOMER_TRX_ID`.

Within each invoice:

- Lines: `LIST_G_CUSTOMER_TRX_ID1/G_CUSTOMER_TRX_ID1`.
- Taxes: `LIST_G_VAT_TAX_ID/G_VAT_TAX_ID`.
- Receipts: `LIST_G_APPLIED_CUSTOMER_TRX_ID/G_APPLIED_CUSTOMER_TRX_ID`.
- QR records: `LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3/LIST_G_ID/G_ID`.

Root CP_* values and CF_REC_COUNT use absolute root paths. Aliases supported by the supplied XML evidence: source Lot_number1→LOT_NUMBER, COMMENT_→COMMENT. F33 uses RECEIPT_NUMBER; F30 uses CUSTOMER_IDENTITY_PROMPET. Their earlier replacements happen to share values in this sample, but should not replace the source bindings.

## Image test boundary

The new Q_3 selects IMAGE and F37 is an image field. Its column has source raw datatype code6. The supplied XML generated from the old query has ID only. Binary encoding in an actual new Oracle Reports XML IMAGE export has not been verified and is not inferred from this enum.

`synthetic-qr-TEST-ONLY.xml` adds base64PNG IMAGE data to the existing G_ID solely to exercise the image branch. `synthetic-qr-TEST-ONLY.png` is generated from the explicit payload `GB-Reports synthetic QR branch TEST ONLY - not invoice data`. Attributes and XML comment mark the data synthetic. The manifest records generation, dimensions, hash, and that no independent QR decoder was used. This is not the original invoice's QR and not an implementation of the proprietary RGI_GET_LONG_RAW function.

Production must supply the original IMAGE bytes in the encoding required by the chosen native BI image instruction. Do not put a synthetic QR into the actual invoice preview or label that image path as source-verified.

## Reproduce

```sh
python3 report-conversion/v4/data/source_contract.py
python3 -m unittest discover -s report-conversion/v4/data -p 'test_*.py' -v
```

Twelve tests cover raw/null preservation, source defaults, all source field/ref paths, missing IMAGE, exact financial reconciliation, mismatched data links, multiple-invoice isolation and synthetic image provenance. No database/network access occurs.
