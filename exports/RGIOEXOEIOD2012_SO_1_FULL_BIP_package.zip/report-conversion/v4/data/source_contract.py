#!/usr/bin/env python3
"""New RDF/actual XML data contract. Read-only data extraction, no database.

All original XML leaf values are preserved (including explicit NULL and leading
zeroes). A separate augmented fixture contains a clearly synthetic QR payload.
"""
from pathlib import Path
import json,re,hashlib,base64,io
from decimal import Decimal
from collections import Counter
from lxml import etree as ET
BASE=Path(__file__).resolve().parent
PROJECT=BASE.parents[1]
ACTUAL=PROJECT/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml'
NEW=PROJECT/'comparison/logic/new'
LAYOUT=PROJECT/'comparison/layout/new-layout.json'
SOURCE=PROJECT/'comparison/new/RGIOEXOEIOD2012_SO_1 1.rdf'
REPORT='/RGIOEXOEIOD2012_SO_1'
HEADER=REPORT+'/LIST_G_CUSTOMER_TRX_ID/G_CUSTOMER_TRX_ID'
SCOPES={
 'G_CUSTOMER_TRX_ID':HEADER,
 'G_CUSTOMER_TRX_ID1':HEADER+'/LIST_G_CUSTOMER_TRX_ID1/G_CUSTOMER_TRX_ID1',
 'G_VAT_TAX_ID':HEADER+'/LIST_G_VAT_TAX_ID/G_VAT_TAX_ID',
 'G_APPLIED_CUSTOMER_TRX_ID':HEADER+'/LIST_G_APPLIED_CUSTOMER_TRX_ID/G_APPLIED_CUSTOMER_TRX_ID',
 'G_CUSTOMER_TRX_ID3':HEADER+'/LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3',
 'G_ID':HEADER+'/LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3/LIST_G_ID/G_ID',
 'ROOT':REPORT,
}
ALIASES={'LOT_NUMBER1':'LOT_NUMBER','COMMENT_':'COMMENT','BRANCH1':'BRANCH'}
LAYOUT_PARAM_NAMES=('P_FLAG','P_ORG_ID')

def parser():return ET.XMLParser(resolve_entities=False,no_network=True)
def leaves(node):return {ET.QName(e).localname.upper():e.text for e in node if isinstance(e.tag,str) and len(e)==0}
def xml_from(path):return ET.parse(str(path),parser())
def node_name(node):return ET.QName(node).localname.upper()
def scalar_equal(a,b):return a not in [None,''] and b not in [None,''] and str(a)==str(b)
def money(value):return Decimal(str(value or '0'))

def load_actual(path=ACTUAL,parameters=None):
    doc=xml_from(path);root=doc.getroot()
    if root.tag!='RGIOEXOEIOD2012_SO_1':raise ValueError('Unexpected report root '+str(root.tag))
    header_nodes=root.findall('LIST_G_CUSTOMER_TRX_ID/G_CUSTOMER_TRX_ID')
    if not header_nodes:raise ValueError('No invoice group')
    invoices=[]
    for h in header_nodes:
        row={'header':leaves(h),
             'lines':[leaves(e) for e in h.findall('LIST_G_CUSTOMER_TRX_ID1/G_CUSTOMER_TRX_ID1')],
             'taxes':[leaves(e) for e in h.findall('LIST_G_VAT_TAX_ID/G_VAT_TAX_ID')],
             'receipts':[leaves(e) for e in h.findall('LIST_G_APPLIED_CUSTOMER_TRX_ID/G_APPLIED_CUSTOMER_TRX_ID')],
             'qr_groups':[],'qr_records':[]}
        for g in h.findall('LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3'):
            record={'header':leaves(g),'images':[leaves(x) for x in g.findall('LIST_G_ID/G_ID')]}
            row['qr_groups'].append(record);row['qr_records'].extend(record['images'])
        invoices.append(row)
    defaults={'P_FLAG':'1','P_ORG_ID':None}
    if parameters is not None:defaults.update(parameters)
    return {'source':{'xml_path':str(path),'xml_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                     'rdf_path':str(SOURCE),'rdf_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                     'values':'Unmodified XML leaf text; None means an explicitly empty XML element.'},
            'root':leaves(root),'parameters':defaults,'invoices':invoices,
            'parameter_policy':{'P_FLAG':'Source default1; explicit None remains Oracle NULL.',
                                'P_ORG_ID':'Not exported. No per-invoice ORG fallback; pass the original report parameter.'}}

def financial_audit(fixture):
    audits=[]
    for i,invoice in enumerate(fixture['invoices']):
        h=invoice['header'];lines=invoice['lines'];taxes=invoice['taxes'];receipts=invoice['receipts']
        financial={
          'line_sum_matches_CS_AMOUNT':sum(money(x.get('CF_NET_AMOUNT')) for x in lines)==money(h.get('CS_AMOUNT')),
          'tax_sum_matches_CS_TAX':sum(money(x.get('TAX_AMOUNT')) for x in taxes)==money(h.get('CS_TAX')),
          'amount_plus_tax_matches_CF_TOTAL_CEIL':money(h.get('CS_AMOUNT'))+money(h.get('CS_TAX'))==money(h.get('CF_TOTAL_CEIL')),
          'receipts_sum_matches_total':sum(money(x.get('REC_AMOUNT')) for x in receipts)==money(h.get('CF_TOTAL_CEIL'))}
        links={
          'line_customer_trx':all(scalar_equal(x.get('CUSTOMER_TRX_ID1'),h.get('CUSTOMER_TRX_ID')) for x in lines),
          'line_header':all(scalar_equal(x.get('HEADER_ID1'),h.get('HEADER_ID')) for x in lines),
          'tax_customer_trx':all(scalar_equal(x.get('CUSTOMER_TRX_ID2'),h.get('CUSTOMER_TRX_ID')) for x in taxes),
          'receipt_customer_trx':all(scalar_equal(x.get('APPLIED_CUSTOMER_TRX_ID'),h.get('CUSTOMER_TRX_ID')) for x in receipts),
          'qr_parent_customer_trx':all(scalar_equal(x['header'].get('CUSTOMER_TRX_ID3'),h.get('CUSTOMER_TRX_ID')) for x in invoice['qr_groups']),
          'qr_image_id':all(scalar_equal(x.get('ID'),g['header'].get('CUSTOMER_TRX_ID3')) for g in invoice['qr_groups'] for x in g['images'])}
        audits.append({'invoice_index':i,'row_counts':{k:len(invoice[k]) for k in ['lines','taxes','receipts','qr_records']},
                       'financial_checks':financial,'data_link_checks':links,
                       'receipt_number_equals_doc_sequence_in_this_sample':all(x.get('RECEIPT_NUMBER')==x.get('DOC_SEQUENCE_VALUE') for x in receipts)})
    return {'invoices':audits,'all_financial_checks_passed':all(all(x['financial_checks'].values()) for x in audits),
            'all_data_links_passed':all(all(x['data_link_checks'].values()) for x in audits)}

def contract():
    groups=json.loads((NEW/'groups.json').read_text());rootcols=json.loads((NEW/'root-and-parameter-columns.json').read_text())
    columns={}
    for group in groups:
        for col in group['columns']:columns[col['object_id']]={**col,'group_name':group['name'].upper()}
    for col in rootcols:columns[col['object_id']]={**col,'group_name':'ROOT'}
    layout=json.loads(LAYOUT.read_text());doc=xml_from(ACTUAL)
    fields=[]
    for obj in layout['layout_objects']:
        if obj['class']!='field':continue
        column=columns[obj['data_source_id']];key=ALIASES.get(column['name'].upper(),column['name'].upper())
        scope=SCOPES[column['group_name']];path=scope+'/'+key;nodes=doc.xpath(path)
        fields.append({'object':obj['name'],'source_column':column['name'],'column_id':column['object_id'],
                       'source_group':column['group_name'],'xml_scope':scope,'xml_element':key,'xml_xpath':path,
                       'native_expression':path if column['group_name']=='ROOT' else key,
                       'present_count':len(nodes),'empty_count':sum(x.text is None or x.text=='' for x in nodes),
                       'actual_xml_present':bool(nodes),'source_offset':obj['offset']})
    refs=[]
    for obj in layout['layout_objects']:
        if obj['class']!='boilerplate':continue
        text=''.join(x['text'] for x in obj.get('text',[]))
        for ref in re.findall(r'&([A-Za-z_][A-Za-z0-9_]*)',text):
            key=ALIASES.get(ref.upper(),ref.upper())
            candidates=[x for x in columns.values() if x['name'].upper()==ref.upper()]
            scopes={SCOPES[c['group_name']] for c in candidates}
            if key.startswith('CP_'):scopes={REPORT}
            locations=[scope+'/'+key for scope in scopes];counts=[len(doc.xpath(path)) for path in locations]
            refs.append({'object':obj['name'],'source_variable':ref,'candidate_xml_paths':locations,'present_count':sum(counts),'actual_xml_present':any(counts)})
    records=json.loads((NEW/'all-records.json').read_text());params=[]
    for column in rootcols:
        if column['source_kind_raw']!=3:continue
        record=next(r for r in records if r['offset']==column['physical_offset'])
        attr={x['i']:x for x in record['attrs']};default=attr[10]['string'] or None
        params.append({'name':column['name'],'source_default':default,'datatype_raw':attr[13]['int'],
                       'default_attribute':10,'physical_offset':column['physical_offset'],
                       'exported_in_actual_xml':bool(doc.xpath(REPORT+'/'+column['name'].upper())),
                       'used_by_format_triggers':column['name'] in LAYOUT_PARAM_NAMES})
    image_record=next(r for r in records if r['offset']==583456)
    image_attrs={x['i']:x for x in image_record['attrs']}
    return {'source_rdf_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_xml_sha256':hashlib.sha256(ACTUAL.read_bytes()).hexdigest(),
            'report_root':REPORT,'group_scopes':SCOPES,'field_bindings':fields,'boilerplate_dynamic_references':refs,
            'field_count':len(fields),'missing_actual_field_objects':[x['object'] for x in fields if not x['actual_xml_present']],
            'missing_actual_xml_elements':[x['xml_xpath'] for x in fields if not x['actual_xml_present']],
            'parameters':params,'parameter_policy':'P_FLAG source default1. P_ORG_ID must be original report parameter; do not derive per invoice.',
            'image_contract':{'source_column':'G_ID.IMAGE','source_field':'F_37','source_datatype_raw':image_attrs[13]['int'],
                              'source_datatype_record_offset':583456,'actual_xml_contains_IMAGE':bool(doc.xpath('//IMAGE')),
                              'source_XML_binary_encoding_verified':False,
                              'supported_augmented_fixture_encoding':'base64 PNG in IMAGE, @mimeType=image/png, @encoding=base64',
                              'note':'The old XML has ID only. Binary encoding of a new Oracle Reports IMAGE export cannot be proved without such an export. No production QR is fabricated.'}}

def synthetic_qr_fixture():
    from reportlab.graphics.barcode import qrencoder
    from PIL import Image,ImageDraw
    payload='GB-Reports synthetic QR branch TEST ONLY - not invoice data'
    code=qrencoder.QRCode(None,qrencoder.QRErrorCorrectLevel.M);code.addData(payload);code.make()
    count=code.getModuleCount();quiet=4;scale=8
    image=Image.new('RGB',((count+quiet*2)*scale,)*2,'white');draw=ImageDraw.Draw(image)
    for y in range(count):
        for x in range(count):
            if code.isDark(y,x):draw.rectangle(((x+quiet)*scale,(y+quiet)*scale,(x+quiet+1)*scale-1,(y+quiet+1)*scale-1),fill='black')
    stream=io.BytesIO();image.save(stream,format='PNG');png=stream.getvalue()
    (BASE/'synthetic-qr-TEST-ONLY.png').write_bytes(png)
    doc=xml_from(ACTUAL);doc.getroot().insert(0,ET.Comment(' SYNTHETIC QR BRANCH FIXTURE ONLY. Original production XML has no IMAGE. '))
    nodes=doc.xpath(SCOPES['G_ID'])
    if not nodes:raise ValueError('No G_ID slot in actual XML')
    for node in nodes:
        element=ET.SubElement(node,'IMAGE',mimeType='image/png',encoding='base64',synthetic='true')
        element.text=base64.b64encode(png).decode('ascii')
    target=BASE/'synthetic-qr-TEST-ONLY.xml';target.write_bytes(ET.tostring(doc,encoding='UTF-8',xml_declaration=True,pretty_print=True))
    return {'xml':target.name,'png':'synthetic-qr-TEST-ONLY.png','payload':payload,'synthetic':True,'not_production_QR':True,
            'png_sha256':hashlib.sha256(png).hexdigest(),'modules':count,'encoded_bytes':len(png),
            'generation_engine':'ReportLab qrencoder with explicit quiet zone; no source-specific RGI_GET_LONG_RAW behavior emulated',
            'decoded_by_independent_QR_decoder':False}

def write():
    fixture=load_actual();(BASE/'actual-fixture.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2))
    c=contract();(BASE/'source-data-contract.json').write_text(json.dumps(c,ensure_ascii=False,indent=2))
    a=financial_audit(fixture);(BASE/'actual-data-checks.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
    q=synthetic_qr_fixture();(BASE/'synthetic-qr-manifest.json').write_text(json.dumps(q,ensure_ascii=False,indent=2))
    print(json.dumps({'fields':c['field_count'],'missing_field_objects':c['missing_actual_field_objects'],
                      'missing_xml_elements':c['missing_actual_xml_elements'],'invoices':len(fixture['invoices']),
                      'financial_checks_passed':a['all_financial_checks_passed'],'data_links_passed':a['all_data_links_passed'],
                      'synthetic_qr_fixture':q['xml']},indent=2))
if __name__=='__main__':write()
