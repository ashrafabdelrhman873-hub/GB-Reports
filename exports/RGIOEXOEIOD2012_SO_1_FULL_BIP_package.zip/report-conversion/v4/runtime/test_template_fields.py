from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import template_fields as t
from tag_trace import validate,compile_trace

class NativeFieldHelperTests(unittest.TestCase):
 def setUp(self):t.reset_names()
 def doc(self,*codes):return r'{\rtf1 '+''.join(t.field(c,'cache') for c in codes)+'}'
 def test_unicode_metadata_round_trip(self):
  code="<?concat('العربية 😀 {x}',NAME)?>";s=t.field(code,'عرض')
  self.assertEqual(t.extract(s)[0]['code'],code)
 def test_scoped_tags_and_parameter_defaults(self):
  s=self.doc("<?param@begin:P_FLAG;'1'?>","<?param@begin:P_ORG_ID;''?>","<?for-each@section:/R/H?>","<?if@row:$P_FLAG='1'?>",'<?NAME?>','<?end if?>','<?end for-each?>')
  self.assertTrue(t.lint(s)['passed'])
  report,trace,_=validate(b'<R><H><NAME>OK</NAME></H></R>',s)
  self.assertTrue(report['binding_checks_passed']);self.assertEqual(trace.xpath('string(//field)'),'OK')
  report,trace,_=validate(b'<R><H><NAME>OK</NAME></H></R>',s,{'P_FLAG':'0'})
  self.assertFalse(trace.xpath('//field'));self.assertEqual(report['loop_checks'][0]['iterations_with_emitted_data'],0)
 def test_optional_missing_image_is_not_required_binding_failure(self):
  code='<fo:instream-foreign-object content-type="{$QR_MIME}" width="0.6in" height="0.6in"><xsl:value-of select="IMAGE"/></fo:instream-foreign-object>'
  s=self.doc('<?for-each@section:/R/H?>','<?NAME?>',code,'<?end for-each?>')
  r,trace,_=validate(b'<R><H><NAME>OK</NAME></H></R>',s)
  self.assertTrue(r['binding_checks_passed']);self.assertEqual(r['optional_image_bindings'][0]['found_counts'],[0]);self.assertEqual(trace.xpath('string(//image/@mime)'),'image/png')
 def test_raw_fo_rejects_external_object_or_extra_instruction(self):
  with self.assertRaises(ValueError):t.field('<fo:external-graphic src="http://example.com/image"/>')
  with self.assertRaises(ValueError):t.field('<fo:instream-foreign-object content-type="image/png" width="1in" height="1in"><xsl:copy-of select="IMAGE"/></fo:instream-foreign-object>')
 def test_missing_required_field_and_zero_outer_loop_fail(self):
  s=self.doc('<?for-each@section:/R/H?>','<?NAME?>','<?end for-each?>')
  self.assertFalse(validate(b'<R><H/></R>',s)[0]['binding_checks_passed'])
  self.assertFalse(validate(b'<R/>',s)[0]['binding_checks_passed'])
 def test_duplicate_names_and_unbalanced_tags_fail(self):
  s=t.field('<?NAME?>',name='F_1')+t.field('<?AMOUNT?>',name='F_1')
  self.assertFalse(t.lint(s)['passed']);self.assertFalse(t.lint(t.field('<?end if?>'))['passed'])
 def test_number_format_is_standard_xslt_only(self):
  s=self.doc('<?for-each@section:/R/H?>',"<?format-number:AMOUNT;'#,##0.00'?>",'<?end for-each?>')
  r,trace,_=validate(b'<R><H><AMOUNT>1234.5</AMOUNT></H></R>',s)
  self.assertTrue(r['binding_checks_passed']);self.assertEqual(trace.xpath('string(//field)'),'1,234.50');self.assertFalse(r['oracle_xdo_executed'])
 def test_native_date_instruction_is_accepted_but_not_falsely_executed(self):
  s=self.doc('<?for-each@section:/R/H?>',"<?format-date:DATE;'DD-MON-YYYY'?>",'<?end for-each?>')
  self.assertTrue(t.lint(s)['passed']);r,_,_=validate(b'<R><H><DATE>2026-01-01</DATE></H></R>',s)
  self.assertFalse(r['binding_checks_passed']);self.assertEqual(len(r['unexecuted_native_instructions']),1)
 def test_inline_if_else_preserves_predicates(self):
  s=self.doc('<?for-each@section:/R/H?>',"<?if@inlines:FLAG='Y'?>",'<?YES?>','<?else?>','<?NO?>','<?end if?>','<?end for-each?>')
  r,tr,_=validate(b'<R><H><FLAG>N</FLAG><NO>NOVALUE</NO></H></R>',s)
  self.assertTrue(r['binding_checks_passed']);self.assertEqual(tr.xpath('string(//field)'),'NOVALUE')
if __name__=='__main__':unittest.main(verbosity=2)
