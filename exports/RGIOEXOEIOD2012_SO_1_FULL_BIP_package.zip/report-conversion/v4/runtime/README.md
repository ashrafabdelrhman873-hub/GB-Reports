# Oracle XDO availability and native image notes

No Oracle BI Publisher/XDO or Template Builder runtime jars were found in the relevant local installation/workspace paths. Java21 and LibreOffice are installed. The environment permits official `download.oracle.com`, but does not permit `docs.oracle.com`; there is no known authoritative, ungated installer URL or supplied Oracle runtime/license package for this task. No proprietary jars were downloaded from third-party copies or guessed URLs.

Consequently **native Oracle RTF-to-XSL-FO compilation, dynamic-image rendering and XDO pagination cannot be executed here**. LibreOffice rendering and standard XSLT condition tests must be described by their actual engines, never as Oracle Publisher tests.

## Parameters and conditions

- Declare global BI parameters before the outer `for-each@section` using native `param@begin` fields. The new RDF preserves LOW/HIGH and obtains P_ORG_ID from LOW. A per-invoice ORG_ID fallback is not equivalent for a range that spans organizations.
- Field/label suppression within a metadata paragraph should use inline context so a false field condition does not inadvertently remove the entire row. Whole repeated-row conditions, such as the source R_2 WARRANTY and R_3 zero-tax suppression, should be row-scoped.
- Section grouping, conditional paragraph spacing, repeating headers/footers, and page breaks remain native-XDO checks even when XPath predicates match the original PL/SQL.

## Base64 BLOB image

The known BI Publisher RTF technique for a BLOB image is raw XSL-FO in a legacy Word form field's Help Text:

```xml
<fo:instream-foreign-object content-type="image/png" width="0.6in" height="0.6in"><xsl:value-of select="LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3/LIST_G_ID/G_ID/IMAGE"/></fo:instream-foreign-object>
```

This is **raw XML**, not a `<?...?>` expression. The source image format/MIME must match actual IMAGE bytes. The PNG string is an example, not proof that the source custom QR function produces PNG. Prefixes are supplied by the Publisher-generated stylesheet. Do not re-save production RTF with LibreOffice, which can drop form-field Help Text.

`blob_image.py` validates the XPath/raw XML/physical dimensions and can inspect actual base64 data with Pillow to establish MIME. `test_blob_image.py` has four passing structural/integrity tests. They do not exercise XDO or prove QR semantics.

The provided actual XML from the old report exports **no IMAGE element**. An actual QR image therefore cannot be recovered or verified from that XML, and no QR containing guessed invoice payload should be substituted. A blank/optional source image area plus a separately labeled synthetic image fixture is the truthful test approach until real IMAGE output is available.

Official documentation was not retrieved live because its domain is outside the enforced allowlist. The image syntax above is a known Publisher technique and still needs validation with the user's Oracle runtime/version.
