import base64,unittest
from io import BytesIO
from PIL import Image
from blob_image import image_fo,inspect_base64

class BlobImageStructuralTests(unittest.TestCase):
 def test_source_xpath_and_raw_fo(self):
  xpath='LIST_G_CUSTOMER_TRX_ID3/G_CUSTOMER_TRX_ID3/LIST_G_ID/G_ID/IMAGE'
  code=image_fo(xpath)
  self.assertIn('select="'+xpath+'"',code);self.assertTrue(code.startswith('<fo:'));self.assertNotIn('<?',code)
  self.assertLessEqual(len(code),255)
 def test_synthetic_image_integrity_only(self):
  out=BytesIO();Image.new('RGB',(25,25),'white').save(out,format='PNG')
  r=inspect_base64(base64.b64encode(out.getvalue()).decode())
  self.assertEqual(r['format'],'PNG');self.assertEqual(r['size'],[25,25])
 def test_invalid_image_is_not_passing_qr(self):
  with self.assertRaises(Exception):inspect_base64(base64.b64encode(b'not an image').decode())
 def test_content_type_is_not_guessed_from_field_name(self):
  with self.assertRaises(ValueError):image_fo('IMAGE',mime='image/qr')
if __name__=='__main__':unittest.main(verbosity=2)
