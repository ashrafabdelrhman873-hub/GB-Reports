"""Build the raw XSL-FO help text used for a BI Publisher BLOB image.

This checks syntax and source image integrity. It does not execute Oracle XDO.
The caller must put the returned XML directly in legacy form-field ffhelptext;
wrapping it in <? ... ?> changes its meaning and is not supported here.
"""
import base64
from io import BytesIO
from lxml import etree
from PIL import Image

NS={'fo':'http://www.w3.org/1999/XSL/Format','xsl':'http://www.w3.org/1999/XSL/Transform'}


def image_fo(xpath, mime='image/png', width='0.6in', height='0.6in'):
    etree.XPath(xpath)
    if mime not in ['image/png','image/jpeg','image/gif','image/bmp']:
        raise ValueError('Unsupported declared image content type')
    import re
    if not all(re.fullmatch(r'[0-9]+(?:\.[0-9]+)?(?:in|cm|mm|pt)',x) for x in [width,height]):
        raise ValueError('Explicit physical dimensions required')
    if '"' in xpath or '<' in xpath or '>' in xpath:
        raise ValueError('XPath attribute must be encoded safely')
    code=(f'<fo:instream-foreign-object content-type="{mime}" width="{width}" height="{height}">'
          f'<xsl:value-of select="{xpath}"/></fo:instream-foreign-object>')
    # Prefixes are supplied by the BI Publisher-generated stylesheet. Supply
    # explicit namespaces only in our standalone structural check.
    etree.fromstring(('<root xmlns:fo="'+NS['fo']+'" xmlns:xsl="'+NS['xsl']+'">'+code+'</root>').encode())
    return code


def inspect_base64(value):
    data=base64.b64decode(''.join(str(value).split()),validate=True)
    with Image.open(BytesIO(data)) as im:
        im.verify()
    with Image.open(BytesIO(data)) as im:
        kind=im.format;size=im.size
    return {'bytes':len(data),'format':kind,'size':list(size),'mime':{'PNG':'image/png','JPEG':'image/jpeg','GIF':'image/gif','BMP':'image/bmp'}.get(kind)}
