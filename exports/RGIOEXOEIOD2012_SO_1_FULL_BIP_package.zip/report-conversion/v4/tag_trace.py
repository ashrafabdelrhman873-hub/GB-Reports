#!/usr/bin/env python3
"""Execute native field XPath with libxslt, NOT Oracle Publisher/XDO.

Row and inline scopes are retained in trace metadata. This validates predicates
and field selection but does not implement XDO's RTF layout or pagination.
"""
from pathlib import Path
from collections import Counter
import hashlib,re
from lxml import etree as E
import template_fields as fields
XSL='http://www.w3.org/1999/XSL/Transform'
DEFAULT_PARAMETERS={'P_FLAG':"'1'",'P_ORG_ID':"''",'DATE_CENTURY':"'20'",'QR_MIME':"'image/png'"}


def compile_trace(rtf):
    """Return (lxml XSLT transform,stylesheet element,native-tag lint report)."""
    lint=fields.lint(rtf)
    if not lint['passed']:raise ValueError(lint['errors'])
    sheet=E.Element('{'+XSL+'}stylesheet',nsmap={'xsl':XSL},version='1.0')
    E.SubElement(sheet,'{'+XSL+'}output',method='xml',indent='yes')
    params={**DEFAULT_PARAMETERS,**lint['parameters']}
    for key,default in params.items():E.SubElement(sheet,'{'+XSL+'}param',name=key,select=default)
    template=E.SubElement(sheet,'{'+XSL+'}template',match='/')
    root=E.SubElement(template,'trace',engine='libxslt',oracle_xdo_executed='false')
    stack=[{'kind':'root','node':root}];unexecuted=[];loops=[]
    for item in lint['fields']:
        code=item['code'];name=item['name'];parent=stack[-1]['node']
        if code.lstrip().startswith('<fo:'):
            image=fields.parse_image(code);path=image['xpath']
            attrs={'prototype':name,'source':path,'optional':'true','mime':image['mime']}
            node=E.SubElement(parent,'image',**attrs)
            found=E.SubElement(node,'{'+XSL+'}attribute',name='found');E.SubElement(found,'{'+XSL+'}value-of',select='count('+path+')')
            size=E.SubElement(node,'{'+XSL+'}attribute',name='characters');E.SubElement(size,'{'+XSL+'}value-of',select='string-length(normalize-space('+path+'))')
            continue
        body=code[2:-2].strip()
        if body.startswith('param@begin:'):continue
        if body.startswith(('for-each:','for-each@')):
            scope,expr=body.split(':',1)
            loop=E.SubElement(parent,'{'+XSL+'}for-each',select=expr)
            group=E.SubElement(loop,'group',source=expr,prototype=name,scope=scope)
            loops.append({'prototype':name,'source':expr,'scope':scope})
            stack.append({'kind':'for-each','node':group});continue
        if body.startswith(('if:','if@')):
            scope,expr=body.split(':',1)
            choose=E.SubElement(parent,'{'+XSL+'}choose')
            when=E.SubElement(choose,'{'+XSL+'}when',test=expr)
            branch=E.SubElement(when,'branch',source=expr,prototype=name,scope=scope)
            stack.append({'kind':'if','node':branch,'choose':choose,'source':expr,'prototype':name,'scope':scope,'has_else':False});continue
        if body=='else':
            current=stack[-1]
            if current['kind']!='if' or current['has_else']:raise ValueError('Invalid native else')
            otherwise=E.SubElement(current['choose'],'{'+XSL+'}otherwise')
            branch=E.SubElement(otherwise,'branch',source='not('+current['source']+')',prototype=current['prototype'],scope=current['scope'],otherwise='true')
            current['node']=branch;current['has_else']=True;continue
        if body in ['end if','end for-each']:
            if stack[-1]['kind']!=body[4:]:raise ValueError('Mismatched native tags')
            stack.pop();continue
        if body.startswith('format-date:'):
            # XPath1.0 has no standard date-format function. Do not make up a
            # non-Oracle date implementation and claim native equivalence.
            E.SubElement(parent,'unexecuted',prototype=name,instruction=code,reason='Native date formatting requires XDO')
            unexecuted.append({'prototype':name,'instruction':code});continue
        if body.startswith('format-number:'):
            expr,mask=body.split(':',1)[1].split(';',1);select=f'format-number({expr}, {mask})'
        else:expr=select=body
        node=E.SubElement(parent,'field',prototype=name,source=expr)
        if re.fullmatch(r'/?[A-Za-z_][A-Za-z0-9_/]*',expr):
            found=E.SubElement(node,'{'+XSL+'}attribute',name='found');E.SubElement(found,'{'+XSL+'}value-of',select='count('+expr+')')
        E.SubElement(node,'{'+XSL+'}value-of',select=select)
    if len(stack)!=1:raise ValueError('Unclosed native tags')
    lint={**lint,'trace_parameters':params,'implicit_trace_parameters':{k:v for k,v in DEFAULT_PARAMETERS.items() if k not in lint['parameters']},'trace_loops':loops,'unexecuted_native_instructions':unexecuted}
    return E.XSLT(sheet,access_control=E.XSLTAccessControl.DENY_ALL),sheet,lint


def _input_tree(value):
    if isinstance(value,E._ElementTree):return value
    if isinstance(value,E._Element):return E.ElementTree(value)
    if isinstance(value,bytes):return E.ElementTree(E.fromstring(value,E.XMLParser(resolve_entities=False,no_network=True)))
    return E.parse(str(value),E.XMLParser(resolve_entities=False,no_network=True))


def validate(xml_path,rtf_path,params=None,parameters=None):
    """Return (report,trace,stylesheet), matching the previous v3 helper API.

    XML may be a path,bytes orlxmltree. RTF may be a path or its full string.
    Optional IMAGE bindings are reported separately from required scalar paths.
    """
    if params is not None and parameters is not None:raise ValueError('Pass params orparameters, notboth')
    params=params if params is not None else parameters or {}
    xml=_input_tree(xml_path)
    is_text=isinstance(rtf_path,str) and rtf_path.lstrip().startswith('{\\rtf')
    rtf=rtf_path if is_text else Path(rtf_path).read_text('latin1')
    transform,sheet,lint=compile_trace(rtf)
    values={key:E.XSLT.strparam('' if value is None else str(value)) for key,value in params.items()}
    trace=transform(xml,**values)
    missing=[{'prototype':n.get('prototype'),'xpath':n.get('source'),'found':int(n.get('found'))} for n in trace.xpath('//field[@found and @found!="1"]')]
    group_counts=Counter(n.get('prototype') for n in trace.xpath('//group'))
    loops=[];empty_outer=[]
    for loop in lint['trace_loops']:
        occurrences=trace.xpath('//group[@prototype=$key]',key=loop['prototype'])
        visible=sum(bool(n.xpath('.//field | .//image[@found!="0"]')) for n in occurrences)
        row={**loop,'selected_iterations':len(occurrences),'iterations_with_emitted_data':visible}
        loops.append(row)
        if loop['scope']=='for-each@section' and not occurrences:empty_outer.append(loop['prototype'])
    image_reports=[]
    for image in lint['raw_fo_images']:
        occurrences=trace.xpath('//image[@prototype=$key]',key=image['name'])
        image_reports.append({'prototype':image['name'],'xpath':image['xpath'],'optional':True,'trace_occurrences':len(occurrences),'found_counts':[int(n.get('found')) for n in occurrences],'data_characters':[int(n.get('characters')) for n in occurrences]})
    unexecuted=[dict(n.attrib) for n in trace.xpath('//unexecuted')]
    binding_passed=not missing and not empty_outer and not unexecuted
    xml_bytes=E.tostring(xml,encoding='UTF-8')
    xml_hash=hashlib.sha256(Path(xml_path).read_bytes()).hexdigest() if isinstance(xml_path,(Path,str)) else hashlib.sha256(xml_bytes).hexdigest()
    report={
      'xml_sha256':xml_hash,'rtf_sha256':hashlib.sha256(rtf.encode('latin1')).hexdigest(),
      'native_field_count':lint['field_count'],'evaluated_scalar_occurrences':len(trace.xpath('//field')),
      'missing_or_ambiguous_bindings':missing,'loop_checks':loops,'required_outer_loops_with_zero_rows':empty_outer,
      'optional_image_bindings':image_reports,'unexecuted_native_instructions':unexecuted,
      'binding_checks_passed':binding_passed,'parameters':{'defaults':lint['trace_parameters'],'overrides':{k:str(v) for k,v in params.items()}},
      'implicit_trace_parameters':lint['implicit_trace_parameters'],
      'execution_engine':'libxslt XPath/XSLT1.0 validation of embedded native tags; NOT Oracle XDO',
      'oracle_xdo_executed':False,'native_rtf_layout_compiled_by_xdo':False,
      'row_and_inline_predicates_evaluated':True,'xdo_row_suppression_and_pagination_verified':False,
      'image_mime_or_qr_semantics_verified':False}
    return report,trace,sheet


def validate_report(xml_path,rtf_path,params=None):return validate(xml_path,rtf_path,params)[0]
