# Source layout inventory

Recovered37fields,43boilerplates,8frames. All27FormatTriggercallbacks have explicit function-map ownerID evidence. Rawcoordinates are not certifiedabsolute runtimepositions becauseOracle anchoring/elasticity/bodyregions remain undecoded.

## Table widths and masks

- Items left->right: F7net(.8792in),F6qty(.3727),F15engine(1.0242),F14chassis(1.3307),F10description(1.6286),F5item(1.1179),F4serial(.1967). F4source=CS_1.
- Receipts left->right: NAME1.4591in,date.9259,amount.7508,RECEIPT_NUMBER.8405,TYPE.8363. Headerlabels exactly خزينة / تاريخ / المبلغ / رقم الايصال / طريقة الدفع.
- F2/F13date masksDD-MON-YYYY. F35receiptdate noexplicitmask. F7/F16 grouped2decimals. F8/F9 groupedintegers. F4/F6/F34 noexplicitmask.

## All source objects

|Object|Region|Source/text|x,y,w,h inches|Font|Trigger|
|---|---|---|---|---|---|
|F_1|invoice_header|TRX_NUMBER|1.7546,0.1338,1.3517,0.1638|Courier New inherited|—|
|F_2|invoice_header|TRX_DATE|4.3682,0.6287,1.3517,0.1638|Courier New 11.0|—|
|F_3|invoice_header|CT_REFERENCE|0.6668,0.6127,1.3715,0.1638|Courier New 11.0|—|
|F_4|R_2_line_row|CS_1|6.4081,3.2,0.1967,0.2714|Arabic Transparent 10.0|—|
|F_5|R_2_line_row|CF_ITEM|5.2896,3.2,1.1179,0.2714|Arabic Transparent 8.0|—|
|F_6|R_2_line_row|QUANTITY_INVOICED|0.9362,3.2,0.3727,0.2714|Arabic Transparent 10.0|—|
|F_7|R_2_line_row|CF_NET_AMOUNT|0.0597,3.2,0.8792,0.2714|Arabic Transparent 10.0|—|
|F_11|invoice_header|CUSTOMER_NAME|0.128,1.1932,5.6084,0.3007|Courier New 11.0|F_11FormatTrigger|
|F_12|invoice_header|CUSTOMER_NUMBER|3.9155,0.9272,1.7981,0.1638|Courier New 11.0|F_12FormatTrigger|
|F_13|invoice_header|ORDERED_DATE|0.689,0.8068,1.3517,0.1638|Courier New 11.0|—|
|F_10|R_2_line_row|CF_ITEM_DESC|3.6649,3.2,1.6286,0.2714|Arabic Transparent 9.0|—|
|F_16|R_3_tax_row|TAX_AMOUNT|0.1844,3.7599,1.1152,0.2048|Arabic Transparent 12.0|—|
|F_18|R_3_tax_row|TAX_CODE|1.3034,3.7599,1.7158,0.2046|Arabic Transparent 12.0|—|
|F_19|invoice_header|CUST_PO_NUMBER|0.6921,1.0004,1.3517,0.1638|Courier New 11.0|—|
|F_28|invoice_header|CUSTOMER_NAME2|0.7769,2.2307,4.8972,0.1558|Courier New 11.0|F_28FormatTrigger|
|F_29|invoice_header|CUSTOMER_IDENTITY_ID|3.762,1.5469,1.5016,0.1558|Courier New 11.0|F_29FormatTrigger|
|F_30|invoice_header|CUSTOMER_IDENTITY_PROMPET|5.3248,1.5459,1.236,0.1693|Arial 12.0|F_30FormatTrigger|
|F_31|invoice_header|ORGANIZATION_NAME_PHONETIC|0.6869,1.525,1.3502,0.1558|Courier New 11.0|F_31FormatTrigger|
|F_33|R_4_receipt_row|RECEIPT_NUMBER|4.1388,5.2646,0.8405,0.2389|Traditional Arabic 10.5|—|
|F_35|R_4_receipt_row|receipt_date|2.4618,5.2647,0.9259,0.2388|Traditional Arabic 10.5|—|
|F_36|R_4_receipt_row|NAME|0.9985,5.2646,1.4591,0.2389|Traditional Arabic 10.5|—|
|F_34|R_4_receipt_row|rec_amount|3.388,5.2646,0.7508,0.2389|Traditional Arabic 10.5|—|
|F_32|R_4_receipt_row|TYPE|4.9751,5.2646,0.8363,0.239|Traditional Arabic 10.5|F_32FormatTrigger|
|F_37|R_5_QR_image|IMAGE|4.6849,3.9516,1.5442,0.7508|Courier New 24.0|—|
|F_14|R_2_line_row|Lot_number1|2.3321,3.2,1.3307,0.2714|Arabic Transparent 10.0|—|
|F_15|R_2_line_row|CF_SERIAL|1.3097,3.2,1.0242,0.2714|Arabic Transparent 8.0|—|
|F_17|invoice_header|ATTRIBUTE_new|0.6887,2.7439,4.9784,0.1638|Courier New 11.0|F_17FormatTrigger|
|F_20|page_margin_header|CP_Arabic_Full_name|3.4906,0.7373,2.8074,0.1702|Traditional Arabic 10.5|—|
|F_21|page_margin_header|CP_English_Full_Name|0.077,0.74,3.072,0.1702|Traditional Arabic 10.5|—|
|F_22|page_margin_header|CP_Arabic_Short_Name|4.0537,0.456,2.2436,0.2638|Traditional Arabic 18.0|—|
|F_23|page_margin_header|CP_Arabic_Short_Name|0.086,0.474,2.6282,0.2638|Traditional Arabic 18.0|—|
|F_24|invoice_header|LOCATION|3.3523,1.7965,2.3124,0.1638|Courier New 11.0|—|
|F_25|invoice_header|ORDER_TYPE|1.0069,1.7466,1.0274,0.1871|Arabic Transparent 12.0|—|
|F_26|invoice_header|TRANSACTION_TYPE|0.6484,1.9947,1.3775,0.171|Arabic Transparent 12.0|—|
|F_27|invoice_header|INVOICE2|0.4265,2.4921,5.06,0.171|Arabic Transparent 12.0|—|
|F_8|invoice_totals|CS_WAR|0.1812,3.5934,1.1222,0.1706|Arabic Transparent 12.0|F_8FormatTrigger|
|F_9|invoice_totals|CF_TOTAL_CEIL|0.1809,3.9702,1.1306,0.1706|Arabic Transparent 12.0|—|
|B_13|M_1_line_header|الموتور|1.3097,3.0454,1.0161,0.1536|Arabic Transparent 12.0|—|
|B_26|invoice_header|&CF_2|2.6028,0.3562,1.4761,0.2041|Courier New 14.0|—|
|B_27|invoice_header|نوع امر البيع|2.3726,1.7131,0.7057,0.1527|Arabic Transparent 12.0|—|
|B_28|invoice_header|نوع الحركة|2.4482,1.9674,0.676,0.1891|Arabic Transparent 12.0|—|
|B_29|invoice_header|ملحق فاتورة رقم|5.5444,2.4813,0.9477,0.1891|Arabic Transparent 14.0|B_29FormatTrigger|
|B_1|M_1_line_header|م|6.4081,3.0453,0.1947,0.1544|Arabic Transparent 12.0|—|
|B_2|M_1_line_header|الصنف|5.2896,3.0453,1.1179,0.1544|Arabic Transparent 12.0|—|
|B_5|M_1_line_header|إسم الصنف|3.6649,3.0472,1.6289,0.152|Arabic Transparent 12.0|—|
|B_12|M_1_line_header|الشاسيه|2.3342,3.0454,1.3225,0.1541|Arabic Transparent 12.0|—|
|B_10|invoice_header|كود العميل|5.7614,0.9041,0.7765,0.1878|Arabic Transparent 14.0|—|
|B_11|invoice_header|تاريخ أمر البيع|1.681,0.7841,1.3649,0.1878|Arabic Transparent 14.0|—|
|B_18|page_margin_footer|        &CP_Tel :تليفون  &CP_ADD :العنوان                                           |1.2907,8.0115,4.9233,0.1536|Traditional Arabic 10.5|—|
|B_20|page_margin_footer|&CP_Commercial_Record :سجل تجارى|0.067,8.1969,1.3311,0.1459|Traditional Arabic 10.5|—|
|B_21|page_margin_footer|&CP_Post : صندوق بريد |2.4198,8.2187,1.6152,0.1568|Traditional Arabic 10.5|—|
|B_22|page_margin_footer|&CP_Fax :فاكس|5.5507,8.1908,1.0497,0.1439|Traditional Arabic 10.5|—|
|B_3|M_1_line_header|الكمية|0.9354,3.0453,0.3735,0.1544|Arabic Transparent 12.0|—|
|B_4|M_1_line_header|السعر|0.0599,3.0453,0.879,0.1544|Arabic Transparent 12.0|—|
|B_17|page_margin_footer|الخط الساخن |0.7602,8.004,0.5292,0.1792|Traditional Arabic 10.5|—|
|B_30|page_margin_footer|16661|0.2252,7.9956,0.4693,0.1624|Traditional Arabic 10.5|—|
|B_14|invoice_totals|الضمان|1.3034,3.5916,1.7165,0.1706|Arabic Transparent 12.0|B_14FormatTrigger|
|B_16|invoice_totals|&CF_FAQAT|3.1232,3.6878,3.234,0.1621|Arabic Transparent 10.0|—|
|B_24|invoice_totals|إجمالي الفاتورة|1.3147,3.9681,1.7084,0.1706|Arabic Transparent 12.0|—|
|B_31|invoice_header| رقم المتابعة |1.7007,0.9777,1.3696,0.1878|Arabic Transparent 14.0|—|
|B_32|invoice_header|حيازة |5.9288,2.2268,0.5887,0.1592|Arabic Transparent 14.0|B_32FormatTrigger|
|B_33|page_margin_header|سوق مصر للسيارات المستعملة ش.م.م |3.5591,0.2203,2.7563,0.1944|Arabic Transparent 12.0|B_33FormatTrigger|
|B_19|invoice_header|: اشعار خصم رقم|3.1772,0.1296,1.3131,0.2699|Traditional Arabic 16.0|B_19FormatTrigger|
|B_34|invoice_header|اسم المأموريه التابع لها|2.192,1.517,1.2286,0.1878|Arial 12.0|B_34FormatTrigger|
|B_23|invoice_header|الفـــرع|5.7562,1.7951,0.7766,0.1707|Arial 12.0|—|
|B_15|invoice_header|الملاحظات|5.7428,2.7375,0.8154,0.1707|Arial 12.0|—|
|B_39|receipt_heading|: الفاتوره اعلاه مسدده بالايصالات التالية|0.2749,4.8317,6.144,0.149|Traditional Arabic 10.5|B_39FormatTrigger|
|B_36|M_2_receipt_header|رقم الايصال|4.1388,5.0257,0.8358,0.2389|Traditional Arabic 10.5|B_36FormatTrigger|
|B_37|M_2_receipt_header|طريقة الدفع|4.9751,5.0257,0.8363,0.2389|Traditional Arabic 10.5|B_37FormatTrigger|
|B_38|M_2_receipt_header|المبلغ|3.388,5.0257,0.7508,0.2389|Traditional Arabic 10.5|B_38FormatTrigger|
|B_40|M_2_receipt_header|تاريخ|2.4579,5.0256,0.9296,0.239|Traditional Arabic 10.5|B_40FormatTrigger|
|B_41|M_2_receipt_header|خزينة|0.9985,5.0256,1.455,0.2348|Traditional Arabic 10.5|B_41FormatTrigger|
|B_44|M_3_delivery_consumer_notice|الخط الساخن بجهاز حماية المستهلك 19588 والواتساب 01577779999 -  |1.7016,5.8098,4.9067,0.1707|Arabic Transparent 12.0|—|
|B_46|M_3_delivery_consumer_notice| &cp_car  تسليم السيارة فى موعد أقصاه -  |3.7721,5.588,2.8362,0.1707|Arabic Transparent 12.0|B_46FormatTrigger|
|B_6|invoice_header|: فـاتـورة بيع سيارة رقم|3.2075,0.1211,1.4687,0.2699|Traditional Arabic 16.0|B_6FormatTrigger|
|B_7|invoice_header|تاريخ الفاتورة|5.7761,0.6227,0.8029,0.1878|Arabic Transparent 14.0|—|
|B_8|invoice_header|رقم أمر البيع|1.8574,0.59,1.2068,0.1878|Arabic Transparent 14.0|—|
|B_9|invoice_header|إسم العميل|5.8638,1.2188,0.6825,0.1878|Arabic Transparent 14.0|—|
|B_25|invoice_header|COPY|0.2219,0.0953,1.263,0.4184|Courier New 36.0|B_25FormatTrigger|
|B_35|page_margin_footer|&CP_NN|0.0513,8.4394,6.1953,0.1792|Traditional Arabic 10.5|—|

## Frames

- R_1: {'x': 0.0597, 'y': 0.084, 'width': 6.5451, 'height': 5.4541};sourcegroup=G_CUSTOMER_TRX_ID;geometricallyenclosed=F_1,F_2,F_3,F_4,F_5,F_6,F_7,F_11,F_12,F_13,F_10,F_16,F_18,F_19,F_28,F_29,F_30,F_31,F_33,F_35,F_36,F_34,F_32,F_37,F_14,F_15,F_17,F_20,F_21,F_22,F_23,F_24,F_25,F_26,F_27,F_8,F_9,B_13,B_26,B_27,B_28,B_29,B_1,B_2,B_5,B_12,B_10,B_11,B_3,B_4,B_14,B_16,B_24,B_31,B_32,B_33,B_19,B_34,B_23,B_15,B_39,B_36,B_37,B_38,B_40,B_41,B_6,B_7,B_8,B_9,B_25
- R_2: {'x': 0.0597, 'y': 3.2, 'width': 6.5451, 'height': 0.2714};sourcegroup=G_CUSTOMER_TRX_ID1;geometricallyenclosed=F_4,F_5,F_6,F_7,F_10,F_14,F_15
- M_1: {'x': 0.0599, 'y': 3.0453, 'width': 6.5429, 'height': 0.1544};sourcegroup=None;geometricallyenclosed=B_13,B_1,B_2,B_5,B_12,B_3,B_4
- R_3: {'x': 0.1844, 'y': 3.7599, 'width': 2.8348, 'height': 0.2048};sourcegroup=G_VAT_TAX_ID;geometricallyenclosed=F_16,F_18
- R_4: {'x': 0.9985, 'y': 5.2646, 'width': 4.8129, 'height': 0.239};sourcegroup=G_applied_customer_trx_id;geometricallyenclosed=F_33,F_35,F_36,F_34,F_32
- M_2: {'x': 0.9985, 'y': 5.0256, 'width': 4.8129, 'height': 0.239};sourcegroup=None;geometricallyenclosed=B_36,B_37,B_38,B_40,B_41
- R_5: {'x': 4.5311, 'y': 3.8919, 'width': 1.8177, 'height': 0.8789};sourcegroup=G_ID;geometricallyenclosed=F_37
- M_3: {'x': 0.0632, 'y': 5.5625, 'width': 6.5451, 'height': 0.6327};sourcegroup=None;geometricallyenclosed=B_44,B_46

## Confidence boundaries

- All80 recovered field/boilerplate definitions mapped into explicit source roles; no recovered object is unplaced in this inventory. Role assignment is not absolute runtime placement.
- R_4 is receipt repeating row. R_5 is IMAGE QR repeating area.
- Source region/elasticity/anchors are not fully decoded. Use native flow rows for repetition and condition collapse; do not render every rawy coordinate as an absolute page position.
- F_2/F_13 dates use DD-MON-YYYY. F_35 has no explicit date mask.
- F_7/F_16 use grouped2decimals; F_8/F_9 use groupedinteger masks. F_4 CS_1, F_6 quantity and F_34 receiptamount have no explicit masks.
- B_46 embeds CP_CAR only. No active recoveredtext contains CP_YEAR or CP_KM interpolation; those outputs still exist in data model.
- Orphan raw format-exception records are preserved for audit but must not be silently promoted to current visibility rules.
- All27 FormatTrigger callback owners are explicitly verified by function-map class0x12 attr3 owner-ID equality, not merely inferred from function naming.
- P_FLAG declared textual default is1. P_ORG_ID has no declared textdefault and sourceAfterPForm assigns it from orderLOW.
