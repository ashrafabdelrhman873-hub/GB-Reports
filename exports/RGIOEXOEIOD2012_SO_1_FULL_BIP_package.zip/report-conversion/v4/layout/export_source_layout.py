#!/usr/bin/env python3
"""Compact recovered source definitions, retaining confidence boundaries.
No Oracle execution; geometric containment is not an asserted Oracle parentlink.
"""
from pathlib import Path
import json,hashlib,re
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parents[1]/'comparison/layout/new-layout.json'
RECORDS=ROOT.parents[1]/'comparison/layout/new-records.json'
LOGIC=ROOT.parents[1]/'comparison/logic/new'
j=json.loads(SOURCE.read_text());records=json.loads(RECORDS.read_text())
widths={3:1,4:2,5:4,6:1,7:2,8:4}
def num(a,endian='big'):
 raw=bytes.fromhex(a['hex']);return int.from_bytes(raw[:widths.get(a['type'],len(raw))],endian)
def font(f):
 if not f:return None
 return {'family':f.get('family'),'size_pt':f.get('size_pt') or None,'size_inherited_or_unspecified':not bool(f.get('size_pt')),'raw_flags':f.get('flags',{}),'source_font_id':f.get('id'),'source_offset':f.get('offset')}
def geom(g):return {k:round(v/10000,4) for k,v in g.items()}
def source_trigger(name):
 p=LOGIC/(name+'FormatTrigger.sql')
 if not p.exists():return None
 return {'function':name+'FormatTrigger','file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'code':p.read_text()}
group_data=json.loads((LOGIC/'groups.json').read_text());groups={g['object_id']:g['name'] for g in group_data};column_group={c['object_id']:g['name'] for g in group_data for c in g['columns']}
frames={}
for r in records:
 if r['class']!=28:continue
 a=r['attrs'];n=lambda x:num(x,r['endian']);name=a[1]['string']
 raw=dict(zip(['x','y','width','height'],[n(a[i]) for i in [7,8,9,10]]))
 frames[name]={'name':name,'object_id':n(a[0]),'class':'frame','source_offset':r['offset'],'geometry_raw':raw,'geometry_inches':geom(raw),'group_id':n(a[12]),'group':groups.get(n(a[12])),'raw_flags':a[4]['hex'],'trigger':source_trigger(name)}
regions={}
for name in ['F_20','F_21','F_22','F_23','B_33']:regions[name]='page_margin_header'
for name in ['B_18','B_20','B_21','B_22','B_17','B_30','B_35']:regions[name]='page_margin_footer'
for name in ['F_4','F_5','F_6','F_7','F_10','F_14','F_15']:regions[name]='R_2_line_row'
for name in ['B_1','B_2','B_3','B_4','B_5','B_12','B_13']:regions[name]='M_1_line_header'
for name in ['F_16','F_18']:regions[name]='R_3_tax_row'
for name in ['F_8','F_9','B_14','B_16','B_24']:regions[name]='invoice_totals'
for name in ['F_32','F_33','F_34','F_35','F_36']:regions[name]='R_4_receipt_row'
for name in ['B_36','B_37','B_38','B_40','B_41']:regions[name]='M_2_receipt_header'
regions['B_39']='receipt_heading'
regions['F_37']='R_5_QR_image'
for name in ['B_44','B_46']:regions[name]='M_3_delivery_consumer_notice'
objects=[]
for o in j['layout_objects']:
 name=o['name'];a=o['attrs'];texts=o.get('text',[])
 obj={'name':name,'object_id':o['object_id'],'class':o['class'],'source_offset':o['offset'],'geometry_raw':o['geometry_raw'],'geometry_inches':geom(o['geometry_raw']),'region':regions.get(name,'invoice_header'),'region_confidence':'source-role/group plus geometry; not decoded Oracle parentlink','display_font':font(o.get('display_tag')),'raw_region_flags':a[4]['hex'],'trigger':source_trigger(name)}
 if o['class']=='field':
  obj.update(source_field=o.get('data_source'),source_column_id=o.get('data_source_id'),source_group=column_group.get(o.get('data_source_id')),format_mask=a[23]['string'] or None)
  obj['format_mask_note']='Raw mask may be ignored by Oracle for non-date/non-numeric source types; do not reinterpret customer IDs/order numbers as dates.'
 else:
  obj['text']=''.join(x['text'] for x in texts)
  obj['segments']=[{'index':x['segment'],'text':x['text'],'font':font(x.get('font')),'source_offset':x.get('offset')} for x in texts]
 objects.append(obj)
byid={x['object_id']:x['name'] for x in objects+list(frames.values())}
seen=set();exceptions=[]
for x in j['format_exceptions']:
 key=(x['id'],x['expression'],x.get('input'),x.get('output_ref_11'),x.get('output_ref_16'))
 if key in seen:continue
 seen.add(key)
 exceptions.append({'owner_id':x['id'],'owner_name':byid.get(x['id']),'owner_mapping_confidence':'Exact owner-id equality with recovered current object' if x['id'] in byid else 'No recovered current owner; potentially stale/deleted metadata','expression':x['expression'],'input_field':x.get('input'),'value_ref_11':x.get('output_ref_11'),'value_ref_16':x.get('output_ref_16'),'font':font(x.get('font')),'source_offset':x['offset'],'raw_attributes':x['attrs']})
for f in frames.values():
 g=f['geometry_raw'];f['geometrically_enclosed_objects']=[x['name'] for x in objects if x['geometry_raw']['x']>=g['x']-60 and x['geometry_raw']['y']>=g['y']-60 and x['geometry_raw']['x']+x['geometry_raw']['width']<=g['x']+g['width']+60 and x['geometry_raw']['y']+x['geometry_raw']['height']<=g['y']+g['height']+60]
 f['containment_note']='Geometric bounds check only; margin/body coordinate regions and anchors can differ.'
spec={'source':'RGIOEXOEIOD2012_SO_1 1.rdf','source_sha256':'50444cbd5947261ac3c9ba37a83c21bad59e07151beb6bb432900f06e957514b','units':'raw coordinates /10000 inch inferred from footer geometry and source text sizes','object_count':len(objects),'field_count':sum(o['class']=='field' for o in objects),'boilerplate_count':sum(o['class']=='boilerplate' for o in objects),'frame_count':len(frames),'objects':objects,'frames':list(frames.values()),'format_exceptions':exceptions,'notes':['All80 recovered field/boilerplate definitions mapped into explicit source roles; no recovered object is unplaced in this inventory. Role assignment is not absolute runtime placement.','R_4 is receipt repeating row. R_5 is IMAGE QR repeating area.','Source region/elasticity/anchors are not fully decoded. Use native flow rows for repetition and condition collapse; do not render every rawy coordinate as an absolute page position.','F_2/F_13 dates use DD-MON-YYYY. F_35 has no explicit date mask.','F_7/F_16 use grouped2decimals; F_8/F_9 use groupedinteger masks. F_4 CS_1, F_6 quantity and F_34 receiptamount have no explicit masks.','B_46 embeds CP_CAR only. No active recoveredtext contains CP_YEAR or CP_KM interpolation; those outputs still exist in data model.','Orphan raw format-exception records are preserved for audit but must not be silently promoted to current visibility rules.']}
# Function-map ownership is stronger evidence than matching function prefixes.
callbacks={}
for r in records:
    a=r['attrs']
    if r['class']!=0x12 or len(a)<4 or 'formattrigger' not in a[1]['string'].lower():continue
    oid=num(a[3],r['endian']);key=(a[1]['string'].lower(),oid)
    callbacks[key]={'function':a[1]['string'],'owner_id':oid,'owner_name':byid.get(oid),'source_function_map_offset':r['offset'],'owner_attribute_index':3,'owner_attribute_raw':a[3]['hex'],'name_prefix_matches_owner':a[1]['string'].lower().removesuffix('formattrigger')==(byid.get(oid) or '').lower()}
parameters={}
for r in records:
    a=r['attrs']
    if r['class']!=0x16 or len(a)<11 or not a[1]['string'].startswith('P_') or num(a[5],r['endian'])!=3:continue
    parameters[a[1]['string']]={'name':a[1]['string'],'object_id':num(a[0],r['endian']),'default_text':a[10]['string'] or None,'default_attribute_index':10,'default_raw':a[10]['hex'],'source_offset':r['offset']}
spec['callback_owner_evidence']=list(callbacks.values())
spec['parameter_definitions']=list(parameters.values())
spec['notes'].append('All27 FormatTrigger callback owners are explicitly verified by function-map class0x12 attr3 owner-ID equality, not merely inferred from function naming.')
spec['notes'].append('P_FLAG declared textual default is1. P_ORG_ID has no declared textdefault and sourceAfterPForm assigns it from orderLOW.')
(ROOT/'callback-owner-evidence.json').write_text(json.dumps(list(callbacks.values()),ensure_ascii=False,indent=2))
(ROOT/'parameter-defaults.json').write_text(json.dumps(list(parameters.values()),ensure_ascii=False,indent=2))
(ROOT/'source-layout.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in spec.items() if k.endswith('_count')},indent=2))
