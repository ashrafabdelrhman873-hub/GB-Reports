import unittest,itertools,json,sys
from pathlib import Path
from lxml import etree as E
sys.path.insert(0,str(Path(__file__).parent))
import visibility as v

# Independently specified branches read from the original PL/SQL. A case is
# header,row,params,root,expected; every case checks local and nativeXPath.
def C(expected,header=None,row=None,params=None,root=None):
 return header or {},row or {},params or {},root or {},expected

CASES={
 'B_14':[C(False,{'CS_WAR':0}),C(True,{'CS_WAR':1}),C(True,{'CS_WAR':None}),C(True,{'CS_WAR':''}),C(False,{'CS_WAR':'0.00'})],
 'B_19':[C(True,{'CAT':'PC Sales Discount Items'}),C(False,{'CAT':None}),C(False,{'CAT':'pc sales discount items'}),C(False,{'CAT':'PC Sales Discount Items '})],
 'B_6':[C(False,{'CAT':'PC Sales Discount Items'}),C(True,{'CAT':None}),C(True,{'CAT':'OTHER'})],
 'B_25':[
 C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'1'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'10'}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'2'}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'20'}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'3'}),
 C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'-2'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'+10'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':' 10'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'\t10'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'\n10'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'\r10'}),
 C(True,{'INTERFACE_HEADER_ATTRIBUTE15':None}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':''}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'1'},params={'P_FLAG':None}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'1'},params={'P_FLAG':''}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'1'},params={'P_FLAG':'2'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'1'},params={'P_FLAG':'01'}),C(False,{'INTERFACE_HEADER_ATTRIBUTE15':'1'},params={'P_FLAG':1}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'١'}),C(True,{'INTERFACE_HEADER_ATTRIBUTE15':'\u00a0'})],
 'B_29':[C(False,{'INVOICE2':None}),C(False,{'INVOICE2':''}),C(True,{'INVOICE2':' '}),C(True,{'INVOICE2':'ABC'})],
 'B_32':[C(True,{'CUSTOMER_NUMBER':'254890'}),C(False,{'CUSTOMER_NUMBER':'0254890'}),C(False,{'CUSTOMER_NUMBER':'254890 '}),C(False,{'CUSTOMER_NUMBER':None})],
 'B_33':[C(False),C(False,{'ORG_ID':3361}),C(True,params={'P_ORG_ID':3361}),C(True,params={'P_ORG_ID':'03361'}),C(False,params={'P_ORG_ID':None}),C(False,params={'P_ORG_ID':''}),C(False,params={'P_ORG_ID':101}),C(False,params={'P_ORG_ID':0})],
 'B_34':[C(False,{'CUSTOMER_TYPE':'PERSON'}),C(True,{'CUSTOMER_TYPE':'ORGANIZATION'}),C(True,{'CUSTOMER_TYPE':'person'}),C(True,{'CUSTOMER_TYPE':None})],
 'B_36':[C(True,root={'CF_REC_COUNT':1}),C(True,root={'CF_REC_COUNT':6}),C(False,root={'CF_REC_COUNT':0}),C(False,root={'CF_REC_COUNT':-1}),C(False,root={'CF_REC_COUNT':None}),C(False,root={'CF_REC_COUNT':''})],
 'B_46':[C(False,root={'CP_CAR':None}),C(False,root={'CP_CAR':''}),C(True,root={'CP_CAR':'09-MAY-26'})],
 'F_11':[C(False,{'ORG_ID':2434}),C(False,{'ORG_ID':'02434'}),C(True,{'ORG_ID':101}),C(True,{'ORG_ID':None})],
 'F_29':[C(False,{'CF_TOTAL_CEIL':149999.99,'INVOICE_CURRENCY_CODE':'EGP'}),C(True,{'CF_TOTAL_CEIL':150000,'INVOICE_CURRENCY_CODE':'EGP'}),C(True,{'CF_TOTAL_CEIL':150000.01,'INVOICE_CURRENCY_CODE':'EGP'}),C(True,{'CF_TOTAL_CEIL':100,'INVOICE_CURRENCY_CODE':'USD'}),C(True,{'CF_TOTAL_CEIL':100,'INVOICE_CURRENCY_CODE':'egp'}),C(True,{'CF_TOTAL_CEIL':None,'INVOICE_CURRENCY_CODE':'EGP'}),C(True,{'CF_TOTAL_CEIL':100,'INVOICE_CURRENCY_CODE':None}),C(False,{'CF_TOTAL_CEIL':-1,'INVOICE_CURRENCY_CODE':'EGP'})],
 'F_32':[C(True),C(True,{'CF_3':0,'CF_5':2}),C(True,{'CF_3':None,'CF_5':None})],
 'M_3':[C(True),C(False,params={'P_ORG_ID':3361}),C(False,root={'CP_ORDER_CATOGERY':'RETURN'}),C(False,params={'P_ORG_ID':3361},root={'CP_ORDER_CATOGERY':'RETURN'}),C(True,params={'P_ORG_ID':101},root={'CP_ORDER_CATOGERY':'ORDER'}),C(True,params={'P_ORG_ID':None},root={'CP_ORDER_CATOGERY':'ORDER'}),C(True,params={'P_ORG_ID':101},root={'CP_ORDER_CATOGERY':None}),C(True,root={'CP_ORDER_CATOGERY':'return'})],
 'R_2':[C(False,row={'CF_ITEM_DESC':'WARRANTY'}),C(True,row={'CF_ITEM_DESC':'warranty'}),C(True,row={'CF_ITEM_DESC':None}),C(True,row={'CF_ITEM_DESC':'CAR'})],
 'R_3':[C(False,row={'TAX_AMOUNT':0}),C(False,row={'TAX_AMOUNT':'0.00'}),C(True,row={'TAX_AMOUNT':1}),C(True,row={'TAX_AMOUNT':-1}),C(True,row={'TAX_AMOUNT':None})]
}
for dst,src in {'F_8':'B_14','F_17':'B_19','F_28':'B_32','F_31':'B_34','F_12':'F_11','F_30':'F_29',**{f'B_{i}':'B_36' for i in range(37,42)}}.items():CASES[dst]=CASES[src]


def context(header,row,params,root):
 report=E.Element('RGIOEXOEIOD2012_SO_1');headernode=E.SubElement(E.SubElement(report,'LIST_G_CUSTOMER_TRX_ID'),'G_CUSTOMER_TRX_ID')
 rownode=E.SubElement(headernode,'ROW')
 for target,values in [(headernode,header),(rownode,row),(report,root)]:
  for key,value in values.items():
   child=E.SubElement(target,str(key).upper());child.text=None if value is None else str(value)
 # API permits merged rootvalues in header as a convenience; explicitroot wins.
 for key,scope in v.SCOPES.items():
  if scope=='root' and key not in v.upper(root) and key in v.upper(header):
   E.SubElement(report,key).text=str(v.upper(header)[key]) if v.upper(header)[key] is not None else None
 variables={key:('' if value is None else str(value)) for key,value in {**v.PARAMETER_DEFAULTS,**v.upper(params)}.items()}
 return headernode,rownode,variables

class VisibilityTests(unittest.TestCase):
 def check_source_cases(self,obj):
  for h,r,p,top,expected in CASES[obj]:
   with self.subTest(object=obj,header=h,row=r,params=p,root=top):
    self.assertIs(v.visibility(obj,h,r,p,top),expected)
    hn,rn,vars=context(h,r,p,top)
    native=E.XPath(v.xpath(obj))(rn if obj in ['R_2','R_3'] else hn,**vars)
    self.assertIs(bool(native),expected)
 def test_source_inventory_is_exactly27(self):
  source=json.loads((Path(__file__).resolve().parents[2]/'comparison/logic/new/source-records.json').read_text())
  expected={v.object_name(x['name']) for x in source if x['name'].lower().endswith('formattrigger')}
  self.assertEqual(set(v.RULES),expected);self.assertEqual(len(v.RULES),27);self.assertEqual(set(CASES),expected)
 def test_source_if_only_enters_true_not_unknown(self):
  self.assertIs(v.evaluate(v.atom('eq','CS_WAR',0),header={'CS_WAR':None}),None)
  self.assertIs(v.visibility('B_14',header={'CS_WAR':None}),True)
  self.assertIs(v.visibility('B_33',params={'P_ORG_ID':None}),False)
 def test_three_valued_boolean_truth_tables(self):
  for a,b in itertools.product([True,False,None],repeat=2):
   expected_and=False if a is False or b is False else True if a is True and b is True else None
   expected_or=True if a is True or b is True else False if a is False and b is False else None
   self.assertIs(v.tri_and([a,b]),expected_and);self.assertIs(v.tri_or([a,b]),expected_or)
 def test_lexical_attribute_differs_from_numeric(self):
  self.assertTrue(v.evaluate(v.atom('lt','INTERFACE_HEADER_ATTRIBUTE15','2'),header={'INTERFACE_HEADER_ATTRIBUTE15':'10'}))
  self.assertFalse(v.visibility('B_25',header={'INTERFACE_HEADER_ATTRIBUTE15':'10'}))
 def test_every_ascii_first_character_lexical_predicate(self):
  # XML permitsTAB,LF,CR plusallprintables; test every suchASCII firstchar.
  for ch in '\t\n\r'+''.join(chr(i) for i in range(32,127)):
   for suffix in ['', '0', 'ABC']:
    value=ch+suffix;expected=not(value<'2')
    with self.subTest(value=repr(value)):
     self.assertIs(v.visibility('B_25',header={'INTERFACE_HEADER_ATTRIBUTE15':value}),expected)
     hn,rn,variables=context({'INTERFACE_HEADER_ATTRIBUTE15':value},{},{},{})
     self.assertIs(bool(E.XPath(v.xpath('B_25'))(hn,**variables)),expected)
 def test_parameter_default_and_explicit_null_are_distinct(self):
  self.assertEqual(v.resolve('P_FLAG'), '1');self.assertIsNone(v.resolve('P_FLAG',params={'P_FLAG':None}));self.assertEqual(v.resolve('P_FLAG',params={'P_FLAG':''}),'')
  self.assertIsNone(v.resolve('P_ORG_ID',header={'ORG_ID':3361},root={'P_ORG_ID':3361}))
 def test_invalid_number_is_a_validation_error(self):
  for value in ['not-a-number','NaN','Infinity']:
   with self.assertRaises(ValueError):v.visibility('B_33',params={'P_ORG_ID':value})
 def test_unknown_objects_are_not_silently_visible(self):
  self.assertFalse(v.has_trigger('B_999'))
  with self.assertRaises(KeyError):v.visibility('B_999')
  self.assertTrue(v.has_trigger('b33formattrigger'))
 def test_case_insensitive_input_keys_do_not_change_case_sensitive_values(self):
  self.assertTrue(v.visibility('B_19',header={'cat':'PC Sales Discount Items'}));self.assertFalse(v.visibility('B_19',header={'cat':'pc sales discount items'}))
 def test_native_metadata_length_and_xpath_syntax(self):
  for obj in v.RULES:
   code='<?if:'+v.xpath(obj)+'?>';self.assertLessEqual(len(code.encode('utf-16-le'))//2,255,obj);E.XPath(v.xpath(obj))
 def test_custom_header_references_inside_line_context(self):
  refs={'ORG_ID':'ancestor::G_CUSTOMER_TRX_ID/ORG_ID'};hn,rn,variables=context({'ORG_ID':2434},{},{},{})
  self.assertFalse(E.XPath(v.xpath('F_11',refs))(rn,**variables))
 def test_actual_xml_rules_have_expected_base_branches(self):
  xml=E.parse(str(Path(__file__).resolve().parents[2]/'v3/input/RGIOEXOEIOD2012_SO_1_test.xml'));header=xml.find('.//G_CUSTOMER_TRX_ID')
  h={x.tag:x.text for x in header if len(x)==0};root={x.tag:x.text for x in xml.getroot() if len(x)==0}
  line=header.find('LIST_G_CUSTOMER_TRX_ID1/G_CUSTOMER_TRX_ID1');row={x.tag:x.text for x in line if len(x)==0}
  expected={'B_14':False,'F_8':False,'B_33':False,'B_34':False,'F_31':False,'F_29':True,'F_30':True,'B_36':True,'B_46':True,'M_3':True,'R_2':True,'F_11':True,'F_12':True}
  for obj,want in expected.items():self.assertIs(v.visibility(obj,h,row,{},root),want,obj)

for _obj in sorted(CASES):
 def _method(self,obj=_obj):self.check_source_cases(obj)
 setattr(VisibilityTests,'test_source_branches_'+_obj,_method)

if __name__=='__main__':unittest.main(verbosity=2)
