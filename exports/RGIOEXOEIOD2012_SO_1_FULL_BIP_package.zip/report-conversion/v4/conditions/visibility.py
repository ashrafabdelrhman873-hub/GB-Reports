"""Visibility rules from all27 FormatTriggers in the selected new RDF.

PL/SQL IF enters its THEN branch only for TRUE, not UNKNOWN/NULL. These rules
preserve that difference. No database is queried and P_ORG_ID is never inferred
from an invoice's ORG_ID. P_FLAG's omitted-parameter default1 is recovered from
its report-column default; an explicit None/empty-string override is OracleNULL.
"""
from decimal import Decimal,InvalidOperation
from pathlib import Path
import re,json

REPORT_ROOT='/RGIOEXOEIOD2012_SO_1'
PARAMETER_DEFAULTS={'P_FLAG':'1','P_ORG_ID':None}
SCOPES={
 'P_FLAG':'params','P_ORG_ID':'params','CP_CAR':'root',
 'CP_ORDER_CATOGERY':'root','CF_REC_COUNT':'root',
 'CF_ITEM_DESC':'row','TAX_AMOUNT':'row',
 'CS_WAR':'header','CAT':'header','INTERFACE_HEADER_ATTRIBUTE15':'header',
 'INVOICE2':'header','CUSTOMER_NUMBER':'header','CUSTOMER_TYPE':'header',
 'ORG_ID':'header','CF_TOTAL_CEIL':'header','INVOICE_CURRENCY_CODE':'header'}
# NUMBER metadata: report-column attr13=1. Character DB columns use attr13=7,
# explicit CHAR formulas use0, dates2. SQLsource independently establishes
# RA_CUSTOMER_TRX_ALL.INTERFACE_HEADER_ATTRIBUTE15 as VARCHAR2.
TYPES={key:'string' for key in SCOPES}
for key in ['P_FLAG','P_ORG_ID','CF_REC_COUNT','CS_WAR','ORG_ID','CF_TOTAL_CEIL','TAX_AMOUNT']:TYPES[key]='number'


def atom(op,key,value=None):return {'op':op,'field':key,'value':value}
def both(*children):return {'op':'and','children':list(children)}
def either(*children):return {'op':'or','children':list(children)}
DISCOUNT='PC Sales Discount Items'
_RULES={}
def add(objects,condition,when_true):
 for obj in objects.split():_RULES[obj]={'condition':condition,'visible_when_condition_true':when_true}
add('B_14 F_8',atom('eq','CS_WAR',0),False)
add('B_19 F_17',atom('eq','CAT',DISCOUNT),True)
add('B_6',atom('eq','CAT',DISCOUNT),False)
add('B_25',both(atom('lt','INTERFACE_HEADER_ATTRIBUTE15','2'),atom('eq','P_FLAG',1)),False)
add('B_29',atom('is_null','INVOICE2'),False)
add('B_32 F_28',atom('eq','CUSTOMER_NUMBER','254890'),True)
add('B_33',atom('eq','P_ORG_ID',3361),True)
add('B_34 F_31',atom('eq','CUSTOMER_TYPE','PERSON'),False)
add('B_36 B_37 B_38 B_39 B_40 B_41',atom('gt','CF_REC_COUNT',0),True)
add('B_46',atom('not_null','CP_CAR'),True)
add('F_11 F_12',atom('eq','ORG_ID',2434),False)
add('F_29 F_30',both(atom('lt','CF_TOTAL_CEIL',150000),atom('eq','INVOICE_CURRENCY_CODE','EGP')),False)
add('M_3',either(atom('eq','P_ORG_ID',3361),atom('eq','CP_ORDER_CATOGERY','RETURN')),False)
add('R_2',atom('eq','CF_ITEM_DESC','WARRANTY'),False)
add('R_3',atom('eq','TAX_AMOUNT',0),False)
_RULES['F_32']={'condition':{'op':'true'},'visible_when_condition_true':True,'active_code':'NULL; RETURN(TRUE);','commented_code_not_executed':'CF_5 > 1 OR CF_3 = 0'}
RULES=dict(sorted(_RULES.items()))
assert len(RULES)==27


def object_name(value):
 value=re.sub('FORMATTRIGGER$','',str(value).upper())
 match=re.fullmatch(r'([BFRM])_?(\d+)',value)
 if not match:raise KeyError('Unknown report object: '+value)
 return match[1]+'_'+match[2]
def has_trigger(value):
 try:return object_name(value) in RULES
 except KeyError:return False

def upper(value):return {str(k).upper():v for k,v in (value or {}).items()}
def is_null(value):return value is None or value==''
def number(value):
 if is_null(value):return None
 try:
  result=Decimal(str(value).strip())
 except (InvalidOperation,ValueError):raise ValueError('Invalid source NUMBER value: '+str(value))
 if not result.is_finite():raise ValueError('Non-finite source NUMBER value')
 return result

def tri_and(values):
 values=list(values)
 return False if False in values else None if None in values else True

def tri_or(values):
 values=list(values)
 return True if True in values else None if None in values else False

def resolve(key,header=None,row=None,params=None,root=None):
 h,r,p,top=upper(header),upper(row),upper(params),upper(root)
 scope=SCOPES[key]
 if scope=='params':return p[key] if key in p else PARAMETER_DEFAULTS[key]
 if scope=='root':return top[key] if key in top else h.get(key)
 return (r if scope=='row' else h).get(key)

def evaluate(condition,header=None,row=None,params=None,root=None):
 op=condition['op']
 if op=='true':return True
 if op in ['and','or']:
  values=[evaluate(x,header,row,params,root) for x in condition['children']]
  return tri_and(values) if op=='and' else tri_or(values)
 key=condition['field'];left=resolve(key,header,row,params,root)
 if op=='is_null':return is_null(left)
 if op=='not_null':return not is_null(left)
 if is_null(left):return None
 right=condition['value']
 if TYPES[key]=='number':left,right=number(left),number(right)
 else:left,right=str(left),str(right)
 if op=='eq':return left==right
 if op=='lt':return left<right
 if op=='gt':return left>right
 raise ValueError('Unknown condition operator: '+op)

def visibility(obj,header=None,row=None,params=None,root=None):
 """Return actual boolean visibility for an object with a sourceFormatTrigger.

 Unknown objects raise KeyError; use has_trigger() before applying this API to
 objects without a trigger (those use their ordinary report visibility).
 """
 rule=RULES[object_name(obj)]
 result=evaluate(rule['condition'],header,row,params,root)
 return result is True if rule['visible_when_condition_true'] else result is not True


def xpath_literal(value):
 text=str(value)
 if "'" not in text:return "'"+text+"'"
 if '"' not in text:return '"'+text+'"'
 pieces=text.split("'")
 args=[]
 for i,piece in enumerate(pieces):
  if i:args.append('"\'"')
  if piece:args.append("'"+piece+"'")
 return 'concat('+','.join(args)+')'

def references(overrides=None):
 refs={}
 for key,scope in SCOPES.items():refs[key]=('$'+key if scope=='params' else REPORT_ROOT+'/'+key if scope=='root' else key)
 refs.update(overrides or {})
 return refs

def _condition_xpath(condition,refs):
 op=condition['op']
 if op=='true':return 'true()'
 if op in ['and','or']:return '('+(' '+op+' ').join(_condition_xpath(x,refs) for x in condition['children'])+')'
 key=condition['field'];ref=refs[key];value=condition['value']
 if op=='is_null':return 'string-length(string('+ref+'))=0'
 if op=='not_null':return 'string-length(string('+ref+'))>0'
 if TYPES[key]=='number':
  return 'number('+ref+')'+{'eq':'=','lt':'<','gt':'>'}[op]+str(value)
 if op=='eq':return ref+'='+xpath_literal(value)
 if op=='lt' and value=='2':
  # XPath1.0 relationaloperators alwayscoerce to NUMBER. Source VARCHAR2<'2'
  # instead compares lexically. All XML-valid chars belowASCII'2' are XML
  # whitespace or ASCIIpunctuation/digits0,1; one firstcharacter suffices because
  # the right operand has length1. Prefix'2' or longer'20' is never<'2'.
  chars='!"#$%&\'()*+,-./01'
  lexical="not(normalize-space(substring(.,1,1))) or contains("+xpath_literal(chars)+",substring(.,1,1))"
  return ref+'[string-length()>0 and ('+lexical+')]'
 raise ValueError('No source-accurate XPath translation for '+str(condition))

def xpath(obj,refs=None):
 """Native BIP if predicate; refs may override per-field XPath locations.

 Predicates assume source NUMBER fields contain valid finite Oracle XML numbers.
 XPath1.0 usesdoubleprecision, while the localvalidator usesDecimal. Original
 Oracle/XDO execution remains a separate validation step.
 """
 rule=RULES[object_name(obj)];expression=_condition_xpath(rule['condition'],references(refs))
 return expression if rule['visible_when_condition_true'] else 'not('+expression+')'


def dependencies(condition):
 if condition['op'] in ['and','or']:
  return sorted({key for child in condition['children'] for key in dependencies(child)})
 return [] if condition['op']=='true' else [condition['field']]

def manifest(source_records):
 sources={x['name'].upper():x for x in source_records}
 result={}
 for obj,rule in RULES.items():
  src=sources[(obj+'FormatTrigger').upper()]
  result[obj]={**rule,'function':src['name'],'source_offset':src['physical_offset'],'source_sha256':src['source_sha256'],'source_sql':src['source'],'dependencies':[{'field':x,'scope':SCOPES[x],'type':TYPES[x]} for x in dependencies(rule['condition'])],'xpath':xpath(obj),'native_tag':'<?if:'+xpath(obj)+'?>','oracle_xdo_executed':False}
 return {'source':'RGIOEXOEIOD2012_SO_1 1.rdf','trigger_count':len(result),'rules':result,'parameter_defaults':PARAMETER_DEFAULTS,'parameter_evidence':{'P_FLAG':{'physical_offset':412484,'column_object_id':2276,'default_attribute_index':10,'default_raw_text':'1','datatype_attribute_index':13,'datatype_raw':1,'datatype':'NUMBER'},'P_ORG_ID':{'physical_offset':177680,'column_object_id':561,'default_attribute_index':10,'default_raw_text':'','datatype_attribute_index':13,'datatype_raw':1,'datatype':'NUMBER'}},'comparison_notes':['IF enters THEN only on TRUE; UNKNOWN follows ELSE/default branch.','Oracle emptystring is NULL; whitespace-only VARCHAR2 is not NULL.','String comparisons are case-sensitive and use binary character order; nondefault linguistic NLS collation is not known.','P_ORG_ID is an explicit optional parameter withNULL default; never inferredfrom per-invoiceORG_ID.','P_FLAG omitted => source default1; explicitNULL/empty override staysNULL.','INTERFACE_HEADER_ATTRIBUTE15 is VARCHAR2, so <\'2\' is lexical; P_FLAG is NUMBER, so =\'1\' is numeric.','Native XPath1.0 NUMBER comparisons use doubles, unlike local Decimal; highprecision values near thresholds requireOracle execution.'], 'legacy_declarative_conditions':[{'expression':"ORG_ID='2434'",'related_explicit_trigger_objects':['F_11','F_12'],'remaining':'Explicit hide exists on customer name/number fields; independent font/style effects not automatically discarded.'},{'expression':"ORG_ID!='2434'",'related_explicit_trigger_objects':['F_11','F_12'],'remaining':'Complement of verified hide condition; does not prove every declarative formatting owner/action.'},{'expression':"SALES_NUMBER='-3'",'related_explicit_trigger_objects':[],'remaining':'No direct FormatTrigger references SALES_NUMBER; preserve declarative style metadata and do not inventhide.'},{'expression':"CS_WAR='0'",'related_explicit_trigger_objects':['B_14','F_8'],'remaining':'Verified direct hide for these two objects.'},{'expression':"CUSTOMER_TYPE='PERSON'",'related_explicit_trigger_objects':['B_34','F_31'],'remaining':'Same condition appears in direct hides for organization/phonetic field objects; this does not establish identity with the older CUSTOMER_NAME style exception.'}]}

if __name__=='__main__':
 source=Path(__file__).resolve().parents[2]/'comparison/logic/new/source-records.json'
 output=Path(__file__).parent/'format-triggers.json'
 output.write_text(json.dumps(manifest(json.loads(source.read_text())),ensure_ascii=False,indent=2))
 print('Wrote',output,'with',len(RULES),'source-derived trigger rules')
