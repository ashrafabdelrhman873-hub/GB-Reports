# Source FormatTrigger visibility conversion

`visibility.py` implements all27 direct FormatTrigger functions recovered from
`RGIOEXOEIOD2012_SO_1 1.rdf`. `format-triggers.json` records each function's
source SQL, physical offset, SHA256, dependencies, boolean rule, and native BI
Publisher `if` predicate. Callback-owner evidence was independently resolved by
the layout agent: all27 function prefixes match their current ownerobject names.

## API

```python
from visibility import visibility, xpath, has_trigger

# Hiding a WARRANTY line is display-only; do not recompute invoice totals from
# only visible lines. Preserve the original computed values in the XML.
visible = visibility('R_2', header=header, row=line, params=params, root=root)
code = '<?if:' + xpath('R_2') + '?>'
```

`visibility()` and `xpath()` raise KeyError for objects without a direct trigger;
use `has_trigger()` before applying them to every layout object. Untriggered
objects follow the normal layout/default visibility, not an invented rule.
Input mapping keys are case-insensitive, but source string values are compared
case-sensitively without trimming. Root values may be supplied separately or as
copied keys in `header`; explicit `root` keys take precedence.

Default native references are relative header/row columns, absolute report-root
paths for `CF_REC_COUNT`, `CP_CAR`, and `CP_ORDER_CATOGERY`, and `$P_ORG_ID` /
`$P_FLAG` for parameters. Pass `refs={field: xpath}` to `xpath()` when embedding
a header condition in another context.

## Source semantics preserved

- PL/SQL IF enters THEN only for TRUE. NULL/UNKNOWN follows ELSE/default logic;
  for many hide rules NULL therefore makes the object visible.
- Empty string is OracleNULL; whitespace-only VARCHAR2 is not NULL.
- P_ORG_ID has an empty/NULL default. It is never inferred from per-invoice
  ORG_ID: new AfterPForm preserves a LOW/HIGH range and derives the parameter
  from LOW, so an invoice-level substitution can change source behavior.
- P_FLAG is NUMBER and has a recovered source default of1. Omitted parameter
  uses1; an explicit None or empty-string override remains NULL. Numeric
  comparison means P_FLAG='01' compares equal to source literal'1'.
- INTERFACE_HEADER_ATTRIBUTE15 is a VARCHAR2 database column. Its comparison
  with literal'2' is lexical: '10' is less than'2'. XPath1.0 `<` would instead
  coerce to numbers, so B25 uses a tested binary-order first-character predicate.
  It covers all XML-valid ASCII characters (including TAB/LF/CR/space), rather
  than assuming the value is a single digit.
- F32's apparent conditions are inside a comment; its active code is alwaysTRUE.
- Source arithmetic fields remain data inputs. Visibility does not change their
  totals or lookup-derived outputs.

P_FLAG evidence: class0x16 column object2276, physicaloffset412484 (also183108),
attribute10 defaulttext'1', attribute13 datatype1(NUMBER). Datatype1 matches
CF_NET_AMOUNT/CS_WAR/TAX_AMOUNT; type0 matches explicit CHAR formulas and type2
matches dates. INTERFACE_HEADER_ATTRIBUTE15 has database datatype7/length150 and
its source SQL selects APPS.RA_CUSTOMER_TRX_ALL.INTERFACE_HEADER_ATTRIBUTE15.

## Validation

`python3 -m unittest discover -s report-conversion/v4/conditions -p 'test_*.py' -v`

39 test methods pass, covering every source object, independently specified
true/false/NULL cases, boundaries149999.99/150000/150000.01, parameter defaults,
actual XML base branches, and parity with native XPath. B25 additionally checks
all294 first-character/suffix combinations from XML-valid ASCII characters.

These are Python and standard XPath tests, not Oracle XDO execution. Source
NUMBER values are expected to be valid finite Oracle numbers; invalid values
raise a local validation error. Python uses Decimal; XPath1.0 uses doubles, so
arbitrarily high precision near thresholds still needs Oracle-engine validation.
String ordering assumes Oracle's ordinary binary comparison, not an unspecified
nondefault linguistic NLS collation.

## Declarative formatting

The original five declarative conditions are documented in the JSON manifest.
Direct triggers resolve some corresponding visibility behavior (ORG2434,
CS_WAR0, PERSON), but do not prove that every font/style exception is redundant.
In particular SALES_NUMBER=-3 has no corresponding direct trigger; do not invent
an additional hide rule from its presence in declarative style metadata.
