#!/usr/bin/env python3
"""Screenshot-guided native BI Publisher RTF template and database-free previews.
The DOCX is an intermediate layout only. Native tags are injected into the RTF
AFTER the only LibreOffice save, so ffhelptext metadata is never round-tripped.
"""
from pathlib import Path
import json,sys,subprocess,tempfile,re
from decimal import Decimal
from docx import Document
from docx.shared import Inches,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_ROW_HEIGHT_RULE,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parent

W=6.65
AR='Traditional Arabic';EN='Courier New'


def prop(parent,name,**attrs):
    child=parent.find(qn('w:'+name))
    if child is None:child=OxmlElement('w:'+name);parent.append(child)
    for k,v in attrs.items():child.set(qn('w:'+k),str(v))
    return child

def fmt(run,size=10.5,bold=False,arabic=True):
    run.font.name=AR if arabic else EN;run.font.size=Pt(size);run.bold=bold
    rpr=run._element.get_or_add_rPr()
    prop(rpr,'rFonts',ascii=AR if arabic else EN,hAnsi=AR if arabic else EN,cs=AR)
    prop(rpr,'szCs',val=round(size*2));prop(rpr,'lang',val='ar-EG' if arabic else 'en-US',bidi='ar-EG' if arabic else 'en-US')
    prop(rpr,'rtl',val=1 if arabic else 0)
    if bold:prop(rpr,'bCs',val=1)
    return run

def paragraph(cell=None,size=10.5,align='right',rtl=True):
    p=cell.paragraphs[0] if cell is not None else None
    if p is None:raise ValueError('paragraph container needed')
    p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(0)
    p.paragraph_format.line_spacing=1.0
    p.alignment={'right':WD_ALIGN_PARAGRAPH.RIGHT,'left':WD_ALIGN_PARAGRAPH.LEFT,'center':WD_ALIGN_PARAGRAPH.CENTER}[align]
    prop(p._p.get_or_add_pPr(),'bidi',val=1 if rtl else 0)
    return p


def table(container,widths,rows=1,borders=False,align='center',height=None):
    try:t=container.add_table(rows=rows,cols=len(widths))
    except TypeError:t=container.add_table(rows=rows,cols=len(widths),width=Inches(sum(widths)))
    t.autofit=False;t.alignment={'left':WD_TABLE_ALIGNMENT.LEFT,'right':WD_TABLE_ALIGNMENT.RIGHT,'center':WD_TABLE_ALIGNMENT.CENTER}[align]
    pr=t._tbl.tblPr;prop(pr,'tblW',w=round(sum(widths)*1440),type='dxa')
    prop(pr,'tblLayout',type='fixed')
    margins=prop(pr,'tblCellMar')
    for side in ['top','bottom']:prop(margins,side,w=0,type='dxa')
    for side in ['left','right']:prop(margins,side,w=22,type='dxa')
    edges=prop(pr,'tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        prop(edges,side,val='single' if borders else 'nil',sz=5,color='000000')
    for column,width in zip(t.columns,widths):column.width=Inches(width)
    for row in t.rows:
        if height:row.height=Inches(height);row.height_rule=WD_ROW_HEIGHT_RULE.AT_LEAST
        for cell,width in zip(row.cells,widths):
            cell.width=Inches(width);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if borders:
                cb=prop(cell._tc.get_or_add_tcPr(),'tcBorders')
                for side in ['top','left','bottom','right']:prop(cb,side,val='single',sz=5,color='000000')
            paragraph(cell)
    return t


def gap(container,inches):
    # Exact-height empty table rows survive nested RTF serialization reliably.
    t=table(container,[W-.08],height=max(inches,.005))
    t.rows[0].height_rule=WD_ROW_HEIGHT_RULE.EXACTLY
    p=t.cell(0,0).paragraphs[0];p.paragraph_format.line_spacing=Pt(1)
    return p


