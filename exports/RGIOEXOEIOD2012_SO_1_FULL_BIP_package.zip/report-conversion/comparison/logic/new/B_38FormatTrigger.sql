function B_38FormatTrigger return boolean is
begin
  IF (:CF_REC_COUNT > 0 ) 
  	THEN 
  return (TRUE);
  ELSE 
  	RETURN (FALSE) ; 
  	END IF ; 
end;