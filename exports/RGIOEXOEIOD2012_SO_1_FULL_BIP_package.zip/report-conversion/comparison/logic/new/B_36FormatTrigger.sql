function B_36FormatTrigger return boolean is
BEGIN 
  IF (:CF_REC_COUNT > 0 ) 
  	THEN 
  return (TRUE);
  ELSE 
  	RETURN (FALSE) ; 
  	END IF ; 
end;