FUNCTION Translate_number (wval number )RETURN varchar2 IS
BEGIN

  declare
          	Miliar_str		varchar2(36);
          	Milion_str	varchar2(36);
          	Thous_str	varchar2(36);
          	Handr_str	varchar2(51);
          	Pound_str	varchar2(36);
          	Miliar		number := 0;
          	Milion		number := 0;
          	Thous		number := 0;
          	Handr		number := 0;	
          	Pound		number := 0;
          	all_str		varchar2(30);	       
        
        	FUNCTION GET_DESC(
        	  wstr IN VARCHAR2 ,
        	  wint IN INTEGER )
        		RETURN VARCHAR2 is
        BEGIN
          declare
           	type  array   is table of   varchar2(10)  index by binary_integer;  
          	arr1	array;
          	arr2	array;
          	arr3	array;
          	arr4	array;
          	arr5	array;
          	arr6	array;
          	units	number :=0;
          	tens	number :=0;
          	cents	number :=0;
          	unit_str	varchar2(12);
          	ten_str		varchar2(12);
          	cent_str	varchar2(12);
          	nox		number := 0;
          	h		number := 0;
          begin
             begin
        
        --			<<<	Arabic Text in arrays....       >>>
        
          	arr1(1) := 'واحد';
          	arr1(2) := 'اثنان';
          	arr1(3) := 'ثلاثة';
          	arr1(4) := 'اربعة';
          	arr1(5) := 'خمسة';
          	arr1(6) := 'ستة';
          	arr1(7) := 'سبعة';
          	arr1(8) := 'ثمانية';
          	arr1(9) := 'تسعة';
          	arr2(1) := 'عشرة';
          	arr2(2) := 'عشرون';
          	arr2(3) := 'ثلاثون';
          	arr2(4) := 'اربعون';
          	arr2(5) := 'خمسون';
          	arr2(6) := 'ستون';
          	arr2(7) := 'سبعون';
          	arr2(8) := 'ثمانون';
          	arr2(9) := 'تسعون';
          	arr3(1) := 'مائة';
          	arr3(2) := 'مائتان';
          	arr3(3) := 'ثلاثمائة';
          	arr3(4) := 'اربعمائة';
          	arr3(5) := 'خمسمائة';
          	arr3(6) := 'ستمائة';
          	arr3(7) := 'سبعمائة';
          	arr3(8) := 'ثمانمائة';
          	arr3(9) := 'تسعمائة';
          	arr5(1) := 'احد';
          	arr5(2) := 'اثنى';
          	arr5(3) := 'ثلاث';
          	arr5(4) := 'اربعة';
          	arr5(5) := 'خمس ';
          	arr5(6) := 'سـت';
          	arr5(7) := 'سبع';
          	arr5(8) := 'ثمان';
          	arr5(9) := 'تسع';
          	arr5(10):= 'عشر';
          	arr4(1) := 'جنيهات';
          	arr4(2) := 'مائة';
          	arr4(3) := 'آلاف';
          	arr4(4) := 'ملايين';
          	arr4(5) := 'مليارات';
          	arr6(1) :=' ';
          	arr6(2) := 'مائة';
          	arr6(3) := 'الفا';
          	arr6(4) := 'مليون';
          	arr6(5) := 'مليار';
        
        --			<<<	Division of the 3 digit number....       >>>  
        
          	nox   := to_number(wstr);	
          	cents := to_number(substr(wstr,1,1));
          	tens  := to_number(substr(wstr,2,1));
          	units := to_number(substr(wstr,3,1));
          	if cents = 0 and tens = 0 and units = 0 then
          		return ' ';
          	end if;
        
        --			<<<	Checking units , tens , cents....       >>>
          	if wint > 0 and units > 0 and tens = 0 and cents = 0 then
          		if units < 3 then
          			if units = 1 and wint = 1 then
          				unit_str := 'الف';
          			end if;
          			if units = 2 and wint = 1 then
          				unit_str := 'الفان';
          			end if;
          			if units = 1 and wint = 2 then
          				unit_str := 'مليون';
          			end if;
          			if units = 2 and wint = 2 then
          				unit_str := 'مليونان';
          			end if;
          			if units = 1 and wint = 3 then
          				unit_str := 'مليار';
          			end if;
          			if units = 2 and wint = 3 then
          				unit_str := 'ملياران';
          			end if;
          			return unit_str;
        		end if;
          	end if;
          	if cents > 0 then
          		cent_str := arr3(cents);
          		if tens > 0 or units > 0 then
          			cent_str := cent_str||' و ';
          		else
          			cent_str := cent_str||' ';
          		end if;
          	end if;
          	if tens > 0 then
          		if tens = 1 then
          			ten_str := arr5(10)||' ';
          		else
          			ten_str := arr2(tens)||' ';
          		end if;
          	end if;
          	if units > 0 then 
          		if tens = 1 then
          			unit_str := arr5(units)||' ';
          		else
          			unit_str := arr1(units);
          			if tens = 0 then
          				unit_str := unit_str||' ';
          			else
          				unit_str := unit_str||' و ';
          			end if;
          		end if;
          	end if;
        
        --			<<<	Returning Translation for the 3 digits....       >>>
        
          	h := 1;
          	if wint > 0 then
          		h := wint+2;
          	end if;
            if nox <= 10 and nox >= 3 then
         		return nvl(cent_str||unit_str||ten_str||arr4(h),' ');				
          	else
          		return nvl(cent_str||unit_str||ten_str||arr6(h),' ');				
          	end if;
        		exception
        		when no_data_found then
        			return ' ';
              end;
        
          end;
        END GET_DESC;
        
          begin
        
        --			<<<	Dividing the number into 3 digit numbers....       >>>
        
          	all_str := replace(to_char(wval,'99999999999.99'),' ','0');
          	Miliar := to_number(substr(all_str,1,3));
          	Milion := to_number(substr(all_str,4,3));
          	Thous := to_number(substr(all_str,7,3));
          	Handr := to_number(substr(all_str,10,3));
          	Pound := to_number(substr(all_str,14,2));
        
        
        --			<<<	checking all parts of the number....       >>>
        --			<<<	      and getting it's desctiption....            >>>  
        
          	if Miliar > 0 then
          		Miliar_str := Get_desc(substr(all_str,1,3),3);
          		if Milion > 0 or Thous > 0 or Handr > 0  then
          			Miliar_str := Miliar_str||' و ';
          		else 
          			Miliar_str := Miliar_str||' ';			
          		end if;
          	else
          		Miliar_str := '';
          	end if;
          	if Milion > 0 then
          		Milion_str := Get_desc(substr(all_str,4,3),2);
          		if Thous > 0 or Handr > 0  then
          			Milion_str := Milion_str||' و ';
          		else 
          			Milion_str := Milion_str||' ';			
          		end if;
          	else
          		Milion_str := '';
          	end if;
          	if Thous > 0 then
          		Thous_str := Get_desc(substr(all_str,7,3),1);
          		if Handr > 0  then
          			Thous_str := Thous_str||' و ';
          		else 
          			Thous_str := Thous_str||' ';			
          		end if;
          	else
          		Thous_str := '';
          	end if;
          	if Handr > 0 then
          		Handr_str := Get_desc(substr(all_str,10,3),0);
          	elsif Miliar > 0 or Milion > 0 or Thous > 0  then
          		Handr_str := '  '	;
          	end if;
          	if Pound > 0 then
          		if Miliar > 0 or Milion > 0 or Thous > 0 or Handr > 0  then		
          			Pound_str := ' و '||'0.'||to_char(Pound);
          			--Pound_str := ' و ' ||to_char(Pound);			
          		else
          			Pound_str := ' '||to_char(Pound);
          		end if;
          	else
          		Pound_str := ' ';
          	end if;	
        
        --			<<<	Returning Arabic Eltabei....       >>>
  return 'فقط '||Miliar_str||Milion_str||Thous_str||Handr_str||Pound_str;
          
          end;
   
       
END ;
