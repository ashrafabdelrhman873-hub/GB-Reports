function F_32FormatTrigger return boolean is
begin
 
  -- Automatically Generated from Report Builder.
 /* if ((:CF_5 > '1') or
      (:CF_3 = '0')) 
  then
    return (FALSE);
  end if;*/
 null ; 
  return (TRUE);
end;