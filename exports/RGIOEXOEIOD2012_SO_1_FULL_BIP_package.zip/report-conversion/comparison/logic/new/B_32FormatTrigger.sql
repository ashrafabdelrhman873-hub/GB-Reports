function B_32FormatTrigger return boolean is
begin
  --if :CUSTOMER_NUMBER<>:CUSTOMER_NUMBER2 then
  	if :CUSTOMER_NUMBER='254890' then
  return (TRUE);
  else   return (false);
  	end if;
end;

