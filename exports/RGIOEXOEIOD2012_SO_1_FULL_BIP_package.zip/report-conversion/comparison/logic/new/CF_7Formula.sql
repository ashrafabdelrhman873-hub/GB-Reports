function CF_7Formula return Char is
begin

  return apps.RGI_GET_EMP_CREATED_INVOICE(:applied_CUSTOMER_TRX_ID);
  
end;