function CF_FAQATFormula return VARCHAR2 is
begin
  return (translate_number(NVL(abs(round(:CF_TOTAL_CEIL,0)),0)) || ' ' || :cf_currency  );
end;