function CF_4Formula return Char is
v_copy  varchar2(1000);
begin
  select INTERFACE_HEADER_ATTRIBUTE15
   into v_copy
   from RA_CUSTOMER_TRX_ALL
   where CT_REFERENCE = :P_ORDER_NUMBER_LOW ;--
   return v_copy;
exception
	when others 
	then return 0;
end;