SELECT 
IL.CUSTOMER_TRX_ID,
TL.DESCRIPTION TAX_CODE,
sum(tax_amt) TAX_AMOUNT
FROM APPS.RA_CUSTOMER_TRX_LINES_ALL IL, 
apps.zx_lines ZL , zx_rates_tl tl
WHERE 
IL.CUSTOMER_TRX_ID =:customer_trx_id
and TRX_LINE_ID =IL.CUSTOMER_TRX_LINE_ID
and tl.lANGUAGE = 'US'
and zl.tax_RATE_id = tl.tax_RATE_id
and nvl(tax_amt,0) != 0
AND TAX_RATE_CODE <> 'TAX10'
GROUP BY
CUSTOMER_TRX_ID ,
TL.DESCRIPTION

UNION ALL

SELECT 
IL.CUSTOMER_TRX_ID,
'ضريبة ضمان' TAX_CODE,
sum(tax_amt) TAX_AMOUNT
FROM APPS.RA_CUSTOMER_TRX_LINES_ALL IL, 
apps.zx_lines ZL , zx_rates_tl tl
WHERE 
IL.CUSTOMER_TRX_ID =:customer_trx_id
and TRX_LINE_ID =IL.CUSTOMER_TRX_LINE_ID
and tl.lANGUAGE = 'US'
and zl.tax_RATE_id = tl.tax_RATE_id
and nvl(tax_amt,0) != 0
AND TAX_RATE_CODE = 'TAX10'
GROUP BY
CUSTOMER_TRX_ID
UNION ALL
SELECT   Rtl.Customer_trx_id,
			  'ضريبة مضافة',
			  SUM (Rtl.Quantity_invoiced * Rtl.Unit_selling_price)
	 FROM   Ra_customer_trx_lines_all Rtl
	WHERE   Rtl.Customer_trx_id = :Customer_trx_id
			  AND Rtl.Inventory_item_id IN
						  (SELECT	Inventory_item_id
							  FROM	Mtl_item_categories_view Mic
							 WHERE		 Mic.Organization_id = 2716
										AND Mic.Category_id = 24021
										AND Mic.Category_set_id = 1100000026)
GROUP BY   Rtl.Customer_trx_id

ORDER BY 3 DESC