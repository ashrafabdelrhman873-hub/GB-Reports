function AfterPForm return boolean is
 cursor orgs is
	  SELECT  org_id 
	  FROM ONT.oe_order_headers_all
	  WHERE order_number = :p_order_number_low;
begin
  
  /*open orgs;
  fetch orgs into :p_org_id ;
  return (true);
  close orgs;*/
  
 
  SELECT  distinct org_id INTO :p_org_id
  FROM ONT.oe_order_headers_all
  WHERE order_number = :p_order_number_low
  AND TO_DATE(CREATION_DATE)> '1-JUL-2012';
  return (TRUE);
	EXCEPTION WHEN NO_DATA_FOUND THEN
	RETURN NULL;
end;