function R_3FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  if (:TAX_AMOUNT = '0')
  then
    return (FALSE);
  end if;

  return (TRUE);
end;