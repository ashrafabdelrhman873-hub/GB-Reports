function F_28FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  ---if (:ORG_ID = '2434')  then
  ----return (FALSE);
  
  ---if :CUSTOMER_NUMBER<>:CUSTOMER_NUMBER2 then
  		if :CUSTOMER_NUMBER='254890' then
  return (TRUE);
  else   return (false);
  	end if;
end;









