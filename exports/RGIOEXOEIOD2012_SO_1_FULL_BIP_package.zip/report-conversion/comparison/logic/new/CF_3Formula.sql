function CF_3Formula return Number is
V_COUNT NUMBER;
begin
SELECT   COUNT('XX')
INTO V_COUNT
    FROM ar_receivable_applications_all raa,
         ar_cash_receipts_all cra,
         ar.ar_receipt_methods arm
   WHERE raa.status = 'APP'
     AND cra.cash_receipt_id = raa.cash_receipt_id
     AND cra.receipt_method_id = arm.receipt_method_id
AND raa.applied_customer_trx_id IN (SELECT AC.CUSTOMER_TRX_ID
                                      FROM AR.RA_CUSTOMER_TRX_ALL AC
                                      WHERE    1=1
                                         AND AC.CT_REFERENCE = :P_ORDER_NUMBER_HIGH );
RETURN V_COUNT;
EXCEPTION
	WHEN OTHERS
	THEN RETURN 0;
  
end;