function CF_CURRENCYFormula return Char is
curr_translation varchar2(80);
cursor GET_TRANSLATION is
	select name
	from fnd_currencies_tl
	where currency_code = :INVOICE_currency_CODE
	and language = 'AR';
begin
  open get_translation;
  fetch get_translation into curr_translation;
  close get_translation;
    return (curr_translation); 
  
end;