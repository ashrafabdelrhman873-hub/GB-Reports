function CF_NAMEFormula return Char is
begin
  IF :NAME LIKE '%Check%' OR :NAME LIKE '%Chck%' THEN
  	RETURN 'شيك';
  ELSIF :NAME LIKE '%Visa%' OR :NAME LIKE '%VISA%' THEN
  	RETURN 'فيزا';
  ELSE
  	RETURN 'نقدى';
  END IF;
  
end;