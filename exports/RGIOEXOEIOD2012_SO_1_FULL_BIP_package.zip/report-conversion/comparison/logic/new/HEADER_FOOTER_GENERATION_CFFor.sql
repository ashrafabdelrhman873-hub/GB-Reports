/*This function selects the Company name (English and Arabic) as well as company address from the Location Field
of the Partent Legal entity for the Organization ID (Operating Unit) from which the order was generated*/

function HEADER_FOOTER_GENERATION_CFFor return Char is
cursor get_location_addresses is
select hl.address_line_1, hl.address_line_2, hl.address_line_3,
	TELEPHONE_NUMBER_1,TELEPHONE_NUMBER_2,POSTAL_CODE, NVL(ECE_TP_LOCATION_CODE,LOC_INFORMATION13),LOC_INFORMATION15
	from hr_locations hl, hr.hr_organization_information hoi , xle_entity_profiles haou ,    xle_registrations xlr
	where hoi.org_information_context = 'Operating Unit Information'
	and hoi.organization_id = :p_org_id
	and xlr.source_id = haou.legal_entity_id
    AND haou.legal_entity_id = hoi.org_information2
	and xlr.location_id = hl.location_id;

	
	

v_address1 varchar2(500);
v_address2 varchar2(500);
v_address3 varchar2(2000);
v_Tel		   varchar2(500);
v_Tel2		 varchar2(500);
v_Post   	 varchar2(500);
v_Tax			 varchar2(500);
V_REG      varchar2(1000);

DashIndex  number;


begin
  /*open get_location_addresses;
  fetch get_location_addresses into v_address1, v_address2, v_address3,v_Tel,v_Tel2,v_Post,v_Tax;
  close get_location_addresses;
  
  
  
  
 	DashIndex := instr(v_address1,'-',1,1);
	:CP_English_Short_Name:=substr(v_address1,0,DashIndex-1);
	:CP_English_Full_Name:=substr(v_address1,DashIndex+1,length(v_address1)-DashIndex);
	
	DashIndex := instr(v_address2,'-',1,1);
	:CP_Arabic_Short_Name:=substr(v_address2,0,DashIndex-1);
	:CP_Arabic_Full_Name:=substr(v_address2,DashIndex+1,length(v_address2)-DashIndex);
	
	
	:CP_ADD:=v_address3;
	
	:CP_Tel:=v_Tel;
	
	:CP_Fax:=v_Tel2;
	
	:CP_Post:=v_Post;
	
	
	DashIndex := instr(v_Tax,'-',1,1);
	:CP_Commercial_Record:=substr(v_Tax,0,DashIndex-1);
	:CP_Tax:=substr(v_Tax,DashIndex+1,length(v_Tax)-DashIndex);
	
	*/
	
	
	/*
  :company_address_cp := v_address3;
  
  :company_arabic_cp := rtrim(replace(substr(v_address1,1,instr(v_address1,'-')),'-'));
  :company_english_cp := ltrim(replace(substr(v_address2,1,instr(v_address2,'-')),'-'));
  :comp_desc_ar_cp := rtrim(replace(substr(v_address1,instr(v_address1,'-')),'-'));
  :comp_desc_us_cp := ltrim(replace(substr(v_address2,instr(v_address2,'-')),'-'));
  */
  return '';  
end;