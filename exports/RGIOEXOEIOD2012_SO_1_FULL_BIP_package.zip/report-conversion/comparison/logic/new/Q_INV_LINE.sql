SELECT  DISTINCT
      Ra_customer_trx_lines_all.Customer_trx_id,
      L.Header_id,
      ' ' Line_null,
      Ra_customer_trx_lines_all.Line_number,
      Ra_customer_trx_lines_all.Inventory_item_id,
      
      --ABS(Ar.Ra_customer_trx_lines_all.Unit_selling_price) * ABS(NVL (Wdd.Shipped_quantity, Wdd.Requested_quantity)) Amount,
      Ar.Ra_customer_trx_lines_all.Unit_selling_price  Amount,
      
      Ra_customer_trx_lines_all.Customer_trx_line_id,
      
      DECODE (L.Line_category_code, 'RETURN',
                                     ABS (NVL (Wdd.Shipped_quantity, Wdd.Requested_quantity)) * -1,
                                     ABS (NVL (Wdd.Shipped_quantity, Wdd.Requested_quantity))
             ) Quantity_invoiced,
      
      --NVL (Wdd.Shipped_quantity, Wdd.Requested_quantity) Quantity_invoiced,     
             
      --DECODE(LENGTH(wdd.LOT_NUMBER),17,SUBSTR(wdd.LOT_NUMBER,12),wdd.LOT_NUMBER) LOT_NUMBER ,
    Wdd.Lot_number,
      --nvl(wdd.SERIAL_NUMBER,wsn.fm_serial_number) SERIAL_NUMBER,
      NVL (
        DECODE (LENGTH (Wdd.Serial_number),
              12, SUBSTR (Wdd.Serial_number, 1),
              Wdd.Serial_number),
        DECODE (LENGTH (Wsn.Fm_serial_number),
              12, SUBSTR (Wsn.Fm_serial_number,1),
              Wsn.Fm_serial_number)
      )
        Serial_number,
      B.Attribute6 Fuel,
      B.Attribute4 Model,
      L.Attribute3 Delivery_l,
      B.Attribute3 Color,
      B.Attribute9 Country_origin 
  FROM  Ar.Ra_customer_trx_lines_all,
      Ont.Oe_order_lines_all L,
      Wsh.Wsh_delivery_details Wdd,
      Wsh_serial_numbers Wsn,
      Inv.Mtl_system_items_b B
 WHERE  Link_to_cust_trx_line_id IS NULL
      AND L.Flow_status_code != 'CANCELLED'

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------fahmy



     -------------------------------------------------------------------- AND TO_CHAR (NVL (Split_from_line_id, L.Line_id)) =                                  ----old 26_march_2014
       -----------------------------------------------------------------------   Ra_customer_trx_lines_all.Interface_line_attribute6

  AND TO_CHAR (NVL (L.Line_id, Split_from_line_id)) =
          Ra_customer_trx_lines_all.Interface_line_attribute6



-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------fahmy


      AND Wdd.Source_header_id = L.Header_id
      AND Wdd.Source_line_id = L.Line_id
      AND Wdd.Delivery_detail_id = Wsn.Delivery_detail_id(+)
      AND L.Inventory_item_id = B.Inventory_item_id
--and   B.DESCRIPTION  <>  'WARRANTY'
             AND L.Inventory_item_id NOT IN
                          (SELECT    Inventory_item_id
                              FROM    Mtl_item_categories_view Mic
                             WHERE         Mic.Organization_id = 2716
                                        AND Mic.Category_id = 24021
                                        AND Mic.Category_set_id = 1100000026)
      AND B.Organization_id = 2716

AND nvl(wdd.SERIAL_NUMBER,wsn.fm_serial_number) IS NOT NULL

UNION

SELECT    DISTINCT
            Ra_customer_trx_lines_all.Customer_trx_id,
            L.Header_id,
            ' ' Line_null,
            Ra_customer_trx_lines_all.Line_number,
            Ra_customer_trx_lines_all.Inventory_item_id,
            
            --ABS (L.Unit_selling_price) *  ABS (nvl (LN.Transaction_quantity,ordered_quantity)) Amount,
            --L.Unit_selling_price  Amount,
            Ar.Ra_customer_trx_lines_all.Unit_selling_price AMOUNT,
            Ra_customer_trx_lines_all.Customer_trx_line_id,
            
            DECODE (L.Line_category_code,'RETURN', 
                                         ABS (nvl (LN.Transaction_quantity,ordered_quantity)) * -1,
                                         ABS (nvl (LN.Transaction_quantity,ordered_quantity))) Quantity_invoiced,
            
            --nvl (LN.Transaction_quantity, ordered_quantity) Quantity_invoiced,                       
            
            --DECODE(LENGTH(ln.LOT_NUMBER),17,SUBSTR(ln.LOT_NUMBER,12),ln.LOT_NUMBER) LOT_NUMBER ,
LN.Lot_number,
            --sn.SERIAL_NUMBER,
            DECODE (LENGTH (Sn.Serial_number),
                      12, SUBSTR (Sn.Serial_number, 1),
                      Sn.Serial_number)
                Serial_number,
            B.Attribute6 Fuel,
            B.Attribute4 Model,
            L.Attribute3 Delivery_l,
            B.Attribute3 Color,
            B.Attribute9 Country_origin
  FROM    Ar.Ra_customer_trx_lines_all,
            Ont.Oe_order_lines_all L,
            Inv.Mtl_material_transactions,
            Inv.Mtl_transaction_lot_numbers LN,
            Inv.Mtl_unit_transactions Sn,
            Apps.Rcv_transactions,
            Inv.Mtl_system_items_b B
 WHERE    Link_to_cust_trx_line_id IS NULL
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------fahmy
     --------       AND TO_CHAR (NVL (L.Split_from_line_id, L.Line_id)) =
          -------------          Ra_customer_trx_lines_all.Interface_line_attribute6

 AND TO_CHAR (NVL (L.Line_id, L.Split_from_line_id)) =
          Ra_customer_trx_lines_all.Interface_line_attribute6

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------fahmy
            AND Inv.Mtl_material_transactions.Transaction_type_id = 15
            AND L.Line_id = Rcv_transactions.Oe_order_line_id
            AND Rcv_transactions.Transaction_id =
                    Inv.Mtl_material_transactions.Source_line_id
            AND Inv.Mtl_material_transactions.Transaction_id =
                    LN.Transaction_id(+)
            AND Inv.Mtl_material_transactions.Organization_id =
                    LN.Organization_id(+)
            AND LN.Serial_transaction_id = Sn.Transaction_id(+)
            AND LN.Organization_id = Sn.Organization_id(+)
            AND L.Inventory_item_id = B.Inventory_item_id
--and   B.DESCRIPTION  <>  'WARRANTY'
             AND L.Inventory_item_id NOT IN
                          (SELECT    Inventory_item_id
                              FROM    Mtl_item_categories_view Mic
                             WHERE         Mic.Organization_id = 2716
                                        AND Mic.Category_id = 24021
                                        AND Mic.Category_set_id = 1100000026)
            AND B.Organization_id = 2716
and Sn.Serial_number  is NOT  null 

/*UNION

SELECT  DISTINCT
      Ra_customer_trx_lines_all.Customer_trx_id,
      L.Header_id,
      ' ' Line_null,
      Ar.Ra_customer_trx_lines_all.Line_number,
      Ar.Ra_customer_trx_lines_all.Inventory_item_id,
      
      --ABS (Ra_customer_trx_lines_all.Unit_selling_price) * ABS(NVL (Ra_customer_trx_lines_all.Quantity_invoiced, Ra_customer_trx_lines_all.Quantity_credited)) Amount,
      (Ra_customer_trx_lines_all.Unit_selling_price) Amount , --* (NVL (Ra_customer_trx_lines_all.Quantity_invoiced, Ra_customer_trx_lines_all.Quantity_credited)) Amount,
      
      Ra_customer_trx_lines_all.Customer_trx_line_id,
      
      
      DECODE (L.Line_category_code, 'RETURN', 
                                    ABS (L.Ordered_quantity) * -1,
                                    ABS (L.Ordered_quantity))Ordered_quantity,
      
      
      --L.Ordered_quantity  Ordered_quantity,
      
      NULL,
      NULL,
      B.Attribute6 Fuel,
      B.Attribute4 Model,
      L.Attribute3 Delivery_l,
      B.Attribute3 Color,
      B.Attribute9 Country_origin
  FROM  Ar.Ra_customer_trx_lines_all,
        Ont.Oe_order_lines_all L,
        Inv.Mtl_system_items_b,
        Inv.Mtl_system_items_b B
 WHERE  Link_to_cust_trx_line_id IS NULL
      AND Inv.Mtl_system_items_b.Inventory_item_id =
          Ra_customer_trx_lines_all.Inventory_item_id
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------fahmy
     ---------------------------- AND TO_CHAR (NVL (L.Split_from_line_id, L.Line_id)) =
       ---------------------------------   Ra_customer_trx_lines_all.Interface_line_attribute6



 AND TO_CHAR (NVL (L.Line_id, L.Split_from_line_id)) =
          Ra_customer_trx_lines_all.Interface_line_attribute6
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------fahmy
      AND Inv.Mtl_system_items_b.Inventory_item_flag = 'N'
      AND B.Inventory_item_flag = 'N'
--and   B.DESCRIPTION  <>  'WARRANTY'
      AND L.Inventory_item_id = B.Inventory_item_id
            AND L.Inventory_item_id NOT IN
                          (SELECT    Inventory_item_id
                              FROM    Mtl_item_categories_view Mic
                             WHERE         Mic.Organization_id = 2716
                                        AND Mic.Category_id = 24021
                                        AND Mic.Category_set_id = 1100000026)
      AND B.Organization_id = 2716 */

ORDER BY   1, 2