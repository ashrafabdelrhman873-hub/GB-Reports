function CF_5Formula return Number is
v_copy_rec  number;
begin
  
SELECT NVL(INTERFACE_HEADER_ATTRIBUTE15,0)
INTO v_copy_rec
 FROM AR.RA_CUSTOMER_TRX_ALL
 WHERE CT_REFERENCE = :P_ORDER_NUMBER_LOW;


return v_copy_rec;
exception
	when others
	then return 0;
end;