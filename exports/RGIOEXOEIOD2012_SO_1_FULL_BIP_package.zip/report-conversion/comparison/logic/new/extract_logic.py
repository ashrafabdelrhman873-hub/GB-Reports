#!/usr/bin/env python3
"""Extract length-delimited Oracle Reports PL/SQL, retaining byte provenance.
No PL/SQL is executed. Physical block headers are omitted only at 4096 boundaries.
"""
from pathlib import Path
import hashlib,json,re
SOURCE=Path('/workspace/report-conversion/comparison/new/RGIOEXOEIOD2012_SO_1 1.rdf')
OUTPUT=Path(__file__).resolve().parent
b=SOURCE.read_bytes()
def logical_bytes(offset,length):
 out=bytearray();chunks=[]
 while len(out)<length:
  if offset%4096<16:
   offset+=(16-offset%4096)
  n=min(length-len(out),4096-offset%4096)
  out.extend(b[offset:offset+n]);chunks.append([offset,n]);offset+=n
 return bytes(out),chunks
records=[]
for m in re.finditer(rb'([A-Z][A-Z0-9_]{2,60})',b):
 e=m.end();n=int.from_bytes(b[e:e+4],'big')
 if not (40<n<15000):continue
 if not b[e+4:e+24].lstrip().lower().startswith((b'function',b'/*')):continue
 raw,chunks=logical_bytes(e+4,n)
 # Named compiler object headers and length-prefixed sources are independently
 # distinguishable from duplicated editor text. Preserve all valid records.
 text=raw.decode('cp1256')
 if any(ord(c)<9 or (13<ord(c)<32) for c in text):continue
 no_comments=re.sub(r'/\*.*?\*/|--[^\n]*','',text,flags=re.S)
 funcs=re.findall(r'(?i)\bfunction\s+([a-z_][a-z_0-9]*)',no_comments)
 if not funcs:continue
 name=funcs[0]
 no_comments=re.sub(r'/\*.*?\*/|--[^\n]*','',text,flags=re.S)
 deps=sorted(set(x.upper() for x in re.findall(r':\s*([a-z_][a-z_0-9]*)',no_comments,re.I)))
 records.append({'name':name,'compiler_object':m.group().decode(),'physical_offset':e+4,'byte_length':n,'chunks':chunks,'encoding':'cp1256','source':text,'field_dependencies':deps,'uses_database':bool(re.search(r'(?i)\bselect\b|\bapps\.',no_comments)),'source_sha256':hashlib.sha256(raw).hexdigest()})
byname={}
for r in records:
 key=r['name'].upper()
 byname.setdefault(key,[]).append(r)
for key,rs in byname.items():
 # Most recent genuine compiler source, not an editor/cache copy.
 r=rs[-1]
 (OUTPUT/(r['name']+'.sql')).write_text(r['source'],encoding='utf-8')
exceptions=[]
for m in re.finditer(rb'\(:([A-Z_][A-Z0-9_]*)\s*(=|!=)\s*\x27([^\x27\x00]*)\x27\)',b):
 exceptions.append({'expression':m.group().decode('cp1256'),'field':m.group(1).decode(),'operator':m.group(2).decode(),'value':m.group(3).decode('cp1256'),'physical_offset':m.start(),'record_hex':b[max(0,b.rfind(b'\xff\xff\xff\xff',0,m.start())):b.find(b'\xff\xff\xff\xff',m.end())].hex()})
(OUTPUT/'source-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
(OUTPUT/'declarative-format-exceptions.json').write_text(json.dumps(exceptions,ensure_ascii=False,indent=2))
summary={'source_sha256':hashlib.sha256(b).hexdigest(),'top_level_functions':len(byname),'source_records':len(records),'all_named_functions':list(byname),'nested_functions':['GET_DESC (inside Translate_number)'],'direct_format_trigger_count':len([k for k in byname if 'FORMATTRIGGER' in k]),'declarative_format_exception_records':len(exceptions),'distinct_declarative_conditions':sorted(set(r['expression'] for r in exceptions)),'structural_limit':'Length-delimited PL/SQL records recovered; active layout ownership and declarative style payload require object graph parsing. No Oracle compilation/execution performed.'}
(OUTPUT/'inventory.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
