from pathlib import Path
import json
b=Path('/workspace/report-conversion/comparison/new/RGIOEXOEIOD2012_SO_1 1.rdf').read_bytes()
rr=[]
for p in range(4,len(b)-20):
 for endian in ['big','little']:
  n=int.from_bytes(b[p:p+2],endian);typ=b[p+2];count=b[p+3]
  if typ not in range(0x01,0x30) or count<3 or count>150 or n<count*2+6 or n>4096 or p+2+n>len(b):continue
  desc=[int.from_bytes(b[x:x+2],endian) for x in range(p+4,p+6+count*2,2)];ofs=[d&0x7ff for d in desc]
  if sorted(ofs)!=ofs or ofs[0]<2+(count+1)*2 or ofs[-1]>n or desc[-1]>>11!=0:continue
  attrs=[]
  for i,d in enumerate(desc[:-1]):
   s=p+2+ofs[i];e=p+2+ofs[i+1];raw=b[s:e]
   attrs.append({'i':i,'type':d>>11,'hex':raw.hex(),'int':int.from_bytes(raw,endian) if len(raw)<=8 else None,'string':raw.split(b'\0')[0].decode('cp1256','replace')})
  rr.append({'offset':p-4,'length':n,'class':typ,'endian':endian,'attrs':attrs})
  break
Path('/workspace/report-conversion/comparison/logic/new/all-records.json').write_text(json.dumps(rr,ensure_ascii=False,indent=2))
from collections import Counter
print(Counter(r['class'] for r in rr))
for r in rr:
 if r['class'] in [0x18,0x1e,0x1c,0x20]:print(r['offset'],hex(r['class']),[(a['i'],a['string']) for a in r['attrs'][:3]])
