function B_34FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  if (:CUSTOMER_TYPE = 'PERSON')
  then
    return (FALSE);
  end if;

  return (TRUE);
end;