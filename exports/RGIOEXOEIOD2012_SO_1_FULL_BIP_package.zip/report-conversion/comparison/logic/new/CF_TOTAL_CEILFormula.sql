function CF_TOTAL_CEILFormula return Number is
begin
  --RETURN round(NVL(:CF_INV_TOTAL,0),0);
  
  RETURN nvl(:CS_AMOUNT,0) + nvl(:CS_TAX,0) ;--+ :CS_WAR ;
  
end;