function CF_FIELD_NAMEFormula return Char is
begin
  IF :CUSTOMER_TYPE = 'PERSON'
  	THEN
  	 RETURN 'الرقم القومي';
  ELSIF :CUSTOMER_TYPE = 'ORGANIZATION'
  	THEN
  	RETURN 'رقم التسجيل الضريبى' ;
  END IF;
  
end;