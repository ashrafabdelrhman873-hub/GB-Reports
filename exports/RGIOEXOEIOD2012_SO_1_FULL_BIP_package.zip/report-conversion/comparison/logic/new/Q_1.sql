SELECT raa.applied_customer_trx_id,
         TO_CHAR (cra.doc_sequence_value) doc_sequence_value,
         ROUND (amount_applied, 2) rec_amount,
         cra.receipt_date,
         cra.attribute5 check_no,
         cra.attribute6 bank_name,
         cra.attribute7 branch,
         cra.attribute10 check_date,
         arm.attribute1 type  , 
         cra.ATTRIBUTE9 ,
         cra.RECEIPT_NUMBER , 
         
         arm.NAME,
         APPS.RGI_GET_EMP_CREATED_INVOICE (raa.applied_customer_trx_id)
            LAST_NAME
        /*, (SELECT trx_number
            FROM AR.RA_CUSTOMER_TRX_ALL AC
           WHERE 1 = 1 AND AC.CT_REFERENCE = :P_ORDER_NUMBER_HIGH)
            trx_number*/
    FROM ar_receivable_applications_all raa,
         ar_cash_receipts_all cra,
         ar.ar_receipt_methods arm
   WHERE     raa.status = 'APP'
         AND cra.cash_receipt_id = raa.cash_receipt_id
         --and nvl(to_number(cra.ATTRIBUTE11),0) = 0
         AND cra.receipt_method_id = arm.receipt_method_id
         AND raa.applied_customer_trx_id IN
                (SELECT AC.CUSTOMER_TRX_ID
                   FROM AR.RA_CUSTOMER_TRX_ALL AC
                  WHERE 1 = 1 AND AC.CT_REFERENCE = :P_ORDER_NUMBER_HIGH)
ORDER BY 4;