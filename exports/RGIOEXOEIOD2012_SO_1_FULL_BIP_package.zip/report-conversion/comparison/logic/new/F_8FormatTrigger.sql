function F_8FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  if (:CS_WAR = '0')
  then
    return (FALSE);
  end if;

  return (TRUE);
end;