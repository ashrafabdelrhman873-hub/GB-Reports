function B_25FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  if ((:INTERFACE_HEADER_ATTRIBUTE15 < '2') and
      (:P_FLAG = '1')) 
  then
    return (FALSE);
  end if;

  return (TRUE);
end;