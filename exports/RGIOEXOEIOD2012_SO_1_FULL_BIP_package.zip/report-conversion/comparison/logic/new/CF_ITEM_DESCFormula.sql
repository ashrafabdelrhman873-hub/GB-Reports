function CF_ITEM_DESCFormula return varchar2 is
ITEM_DESC VARCHAR2(1000);
begin
	SELECT DISTINCT DESCRIPTION
  INTO ITEM_DESC
  FROM INV.MTL_SYSTEM_ITEMS_B
  WHERE INVENTORY_ITEM_ID = :INVENTORY_ITEM_ID 
  and organization_id=2716;
	RETURN ITEM_DESC ;
  
  exception when others then return null;
end;