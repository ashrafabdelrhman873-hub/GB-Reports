function R_2FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  if (:CF_ITEM_DESC = 'WARRANTY')
  then
    return (FALSE);
  end if;

  return (TRUE);
end;