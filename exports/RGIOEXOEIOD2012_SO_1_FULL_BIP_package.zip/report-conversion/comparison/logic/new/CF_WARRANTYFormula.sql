function CF_WARRANTYFormula return Number is
begin
  IF NVL(:CF_ITEM_DESC,'N')  = 'WARRANTY' THEN
  	RETURN nvl(:CF_NET_AMOUNT,0) ;
  ELSE
  	RETURN 0;
  END IF;
  
end;