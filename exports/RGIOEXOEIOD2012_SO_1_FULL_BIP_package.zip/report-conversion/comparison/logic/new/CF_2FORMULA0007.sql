function CF_2FORMULA0007 return Char is
P_TRX_TYPE VARCHAR2(200);
v_type varchar2(50); 
begin
  SELECT A.NAME ,decode(o.ORDER_CATEGORY_CODE,'RETURN','مرتجع')
  INTO P_TRX_TYPE,v_type
  from AR.RA_CUST_TRX_TYPES_ALL A,ONT.OE_TRANSACTION_TYPES_ALL O
where A.CUST_TRX_TYPE_ID=O.CUST_TRX_TYPE_ID
AND A.ORG_ID=O.ORG_ID
AND O.TRANSACTION_TYPE_ID=:ORDER_TYPE_ID;
IF SUBSTR(UPPER(P_TRX_TYPE),INSTR(P_TRX_TYPE,'Cr'),2) ='CR' THEN
RETURN 'آجل'||' '||v_type;
ELSIF SUBSTR(UPPER(P_TRX_TYPE),INSTR(P_TRX_TYPE,'Ca'),2) ='CA' THEN
RETURN 'نقدى'||' '||v_type;
else return null;
END IF;  

exception when others then
	return null;
end;