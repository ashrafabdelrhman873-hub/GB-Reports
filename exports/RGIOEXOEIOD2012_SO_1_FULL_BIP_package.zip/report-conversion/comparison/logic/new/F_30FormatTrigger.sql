function F_30FormatTrigger return boolean is
begin
       if (:CF_TOTAL_CEIL < 150000 AND  :INVOICE_currency_CODE = 'EGP')
  then
    return (FALSE);
  end if;

  return (TRUE);
end;