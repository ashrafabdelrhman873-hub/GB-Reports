function CF_REC_COUNTFormula return Number is
NUMMM NUMBER(10) := 0 ; 
begin
  SELECT COUNT(raa.applied_customer_trx_id) INTO NUMMM
    FROM ar_receivable_applications_all raa,
         ar_cash_receipts_all cra,
         ar.ar_receipt_methods arm
   WHERE     raa.status = 'APP'
         AND cra.cash_receipt_id = raa.cash_receipt_id
         --and nvl(to_number(cra.ATTRIBUTE11),0) = 0
         AND cra.receipt_method_id = arm.receipt_method_id
         AND raa.applied_customer_trx_id IN
                (SELECT AC.CUSTOMER_TRX_ID
                   FROM AR.RA_CUSTOMER_TRX_ALL AC
                  WHERE 1 = 1 AND AC.CT_REFERENCE = :P_ORDER_NUMBER_HIGH) ; 

RETURN NUMMM ; 
end;