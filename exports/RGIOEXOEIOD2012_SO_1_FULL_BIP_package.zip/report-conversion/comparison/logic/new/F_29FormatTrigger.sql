function F_29FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
     if (:CF_TOTAL_CEIL < 150000 AND  :INVOICE_currency_CODE = 'EGP')
  then
    return (FALSE);
  end if;


  return (TRUE);
end;