function B_6FormatTrigger return boolean is
begin
  if :cat  in ('PC Sales Discount Items')  
  	then 
  return (FALSE);
 else return (TRUE);
  	end if ;

end;