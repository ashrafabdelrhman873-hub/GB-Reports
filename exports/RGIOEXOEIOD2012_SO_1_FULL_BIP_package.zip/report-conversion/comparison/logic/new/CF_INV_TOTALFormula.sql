function CF_INV_TOTALFormula return Number is
begin
	IF :CF_CATEGORY_H='RETURN' THEN
		
  RETURN (NVL(:CS_AMOUNT,0)) *-1;-- /*+ NVL(:CS_WAR,0) */+ NVL(:CS_TAX , 0))*-1 ;
	ELSE
		RETURN NVL(:CS_AMOUNT,0) + NVL(:CS_TAX , 0)/* + NVL(:CS_WAR,0) */;
		END IF;
end;