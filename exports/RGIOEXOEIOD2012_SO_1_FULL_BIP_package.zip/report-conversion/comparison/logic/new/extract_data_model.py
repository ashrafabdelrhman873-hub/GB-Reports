#!/usr/bin/env python3
"""Extract exact Oracle Reports SQL and source group/column metadata, without executing SQL.

Uses previously validated ROS property records; type-width decoding omits unused
padding. Large source strings follow their source-record overflow page pointers.
Only 16-byte physical page headers are skipped. Original SQL bytes are retained
as provenance hashes; UTF-8 .sql output changes encoding only.
"""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/report-conversion')
SOURCE=Path('/workspace/report-conversion/comparison/new/RGIOEXOEIOD2012_SO_1 1.rdf')
raw=SOURCE.read_bytes()
records=json.loads((ROOT/'all-records.json').read_text())
def number(a,endian='big'):
 data=bytes.fromhex(a['hex']);width={3:1,4:2,5:4,6:1,7:2,8:4,19:4}.get(a['type'],len(data))
 return int.from_bytes(data[:width],endian)
def logical_bytes(start,length):
 out=bytearray();chunks=[]
 while len(out)<length:
  if start%4096<16:start+=16-start%4096
  n=min(length-len(out),4096-start%4096)
  out.extend(raw[start:start+n]);chunks.append([start,n]);start+=n
 return bytes(out),chunks
by_source={};queries={};groups={};cols={}
for r in records:
 a=r['attrs'];endian=r['endian']
 if r['class']==5:
  by_source[number(a[0],endian)]=r
 if r['class']==20:
  queries[number(a[0],endian)]={'name':a[1]['string'],'query_object_id':number(a[0],endian),'source_string_id':number(a[4],endian),'physical_offset':r['offset']}
 if r['class']==21:
  groups[number(a[0],endian)]={'name':a[1]['string'],'object_id':number(a[0],endian),'query_object_id':number(a[5],endian),'physical_offset':r['offset']}
 if r['class']==22:
  cols[number(a[0],endian)]={'name':a[1]['string'],'object_id':number(a[0],endian),'group_object_id':number(a[4],endian),'source_kind_raw':number(a[5],endian),'physical_offset':r['offset']}

def active_sql(s):
 # Remove comments and quoted literals before finding binds, preserving newlines.
 return re.sub(r"--[^\n]*|/\*.*?\*/|'(?:''|[^'])*'",lambda m:'\n'*m.group().count('\n'),s,flags=re.S)
output=[]
for query in queries.values():
 r=by_source[query['source_string_id']];a=r['attrs'];endian=r['endian'];length=number(a[1],endian)
 data=bytes.fromhex(a[4]['hex']);chunks=[]
 if number(a[3],endian)==8 and len(data)==8:
  first_page=int.from_bytes(data[:4],endian);last_page=int.from_bytes(data[4:],endian)
  data,chunks=logical_bytes(first_page+16,length)
  assert chunks[-1][0]//4096==last_page//4096
 else:
  assert len(data)>=length
  data=data[:length]
 text=data.decode('cp1256')
 assert re.match(r'\s*SELECT\b',text,re.I)
 assert all(ord(c)>=32 or c in '\n\r\t' for c in text)
 (ROOT/(query['name']+'.sql')).write_text(text,encoding='utf-8')
 query.update({'sql_file':query['name']+'.sql','byte_length':length,'source_encoding':'cp1256','source_bytes_sha256':hashlib.sha256(data).hexdigest(),'source_record_offset':r['offset'],'overflow_chunks':chunks,'binds':sorted(set(x.upper() for x in re.findall(r':\s*([A-Za-z_][A-Za-z_0-9]*)',active_sql(text)))),'source_groups':[g['name'] for g in groups.values() if g['query_object_id']==query['query_object_id']],'database_required_to_execute':True,'executed':False})
 output.append(query)
links={}
for r in records:
 if r['class']!=23:continue
 a=r['attrs'];e=r['endian'];oid=number(a[0],e)
 source_group,target_group=number(a[3],e),number(a[5],e)
 source_column,target_column=number(a[4],e),number(a[6],e)
 if source_group not in groups or target_group not in groups or source_column not in cols or target_column not in cols:continue
 links[oid]={'object_id':oid,'physical_offset':r['offset'],'source_group':groups[source_group]['name'],'source_column':cols[source_column]['name'],'target_group':groups[target_group]['name'],'target_column':cols[target_column]['name'],'operator_raw':number(a[7],e),'condition_kind_raw':number(a[8],e)}
(ROOT/'data-links.json').write_text(json.dumps(list(links.values()),ensure_ascii=False,indent=2))
for g in groups.values():
 g['query_name']=queries.get(g['query_object_id'],{}).get('name')
 g['columns']=[c for c in cols.values() if c['group_object_id']==g['object_id']]
(rootcols:=ROOT/'root-and-parameter-columns.json').write_text(json.dumps([c for c in cols.values() if c['group_object_id'] not in groups],ensure_ascii=False,indent=2))
(ROOT/'queries.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
(ROOT/'groups.json').write_text(json.dumps(list(groups.values()),ensure_ascii=False,indent=2))
summary={'source':str(SOURCE),'source_sha256':hashlib.sha256(raw).hexdigest(),'query_count':len(output),'group_count':len(groups),'column_count':len(cols),'data_link_count':len(links),'source_file_unchanged':SOURCE.read_bytes()==raw,'sql_executed':False,'notes':['SQL is byte-preserving except cp1256-to-UTF8 output encoding. Original byte hashes and source offsets retained.','Group nesting is not established by column membership; keep source query/group names and explicit links.','Q_2 invokes RGI_GET_LONG_RAW and may have database side effects. It has not been executed.','Query syntax/semantics against Oracle schemas is untested; comments and original SQL remain unchanged.']}
(ROOT/'extraction-validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,indent=2))
print(json.dumps([{k:q[k] for k in ['name','byte_length','binds','source_groups']} for q in output],indent=2))
