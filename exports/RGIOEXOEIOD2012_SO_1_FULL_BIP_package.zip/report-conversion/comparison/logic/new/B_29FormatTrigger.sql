function B_29FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  if (:INVOICE2 IS NULL)
  then
    return (FALSE);
  end if;

  return (TRUE);
end;