function F_17FormatTrigger return boolean is
begin
  if :cat  in ('PC Sales Discount Items')
  	then 
  return (TRUE);
  else return (false);
  	end if ;
end;