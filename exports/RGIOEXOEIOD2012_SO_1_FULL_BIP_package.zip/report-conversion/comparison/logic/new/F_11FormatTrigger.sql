function F_11FormatTrigger return boolean is
begin

  -- Automatically Generated from Report Builder.
  if (:ORG_ID = '2434')
  then
    return (FALSE);
  end if;

  return (TRUE);
end;