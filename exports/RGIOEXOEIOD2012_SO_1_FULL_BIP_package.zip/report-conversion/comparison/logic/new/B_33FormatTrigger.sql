function B_33FormatTrigger return boolean is
begin
  if :p_org_id = 3361 -- Egypt Auto Mall OP
  	then
    return (TRUE);
  else
  	return (FALSE);
  END IF;
end;