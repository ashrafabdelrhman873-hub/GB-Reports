function CF_1Formula return Char is
Ret_Val	varchar2(500);
begin
  Ret_Val:=HEADER_FOOTER_GENERATION_CFFor();
  return '' ;
end;